        function initMoving(elementID, position, topLimit, leftLimit) {
            if (!elementID)
                return false;
            var obj = elementID;
            obj.initTop = position;
            obj.topLimit = topLimit;
            obj.style.position = "absolute";
            obj.top = obj.initTop;
            obj.left = leftLimit;

            if (typeof (window.pageYOffset) == "number") {
                obj.getTop = function () {
                    return window.pageYOffset;
                }
            } else if (typeof (document.documentElement.scrollTop) == "number") {
                obj.getTop = function () {
                    return document.documentElement.scrollTop;
                }
            } else {
                obj.getTop = function () {
                    return 0;
                }
            }

            if (self.innerHeight) {
                obj.getHeight = function () {
                    return self.innerHeight;
                }
            } else if (document.documentElement.clientHeight) {
                obj.getHeight = function () {
                    return document.documentElement.clientHeight;
                }
            } else {
                obj.getHeight = function () {
                    return 500;
                }
            }

            obj.move = setInterval(function () {
                if (obj.initTop > 0) {
                    pos = obj.getTop() + obj.initTop-260;
                } else {
                    pos = obj.getTop() + obj.getHeight() + obj.initTop;
                    //pos = obj.getTop() + obj.getHeight() / 2 - 15;
                }

                if (pos > obj.bottomLimit)
                    pos = obj.bottomLimit;
                if (pos < obj.topLimit)
                    pos = obj.topLimit;

                interval = obj.top - pos;
                obj.top = obj.top - interval / 3;
                obj.style.top = obj.top + "px";
            }, 30)
        }
        initMoving(document.getElementById("right_skyWingBanner"), 5, 0, 900);