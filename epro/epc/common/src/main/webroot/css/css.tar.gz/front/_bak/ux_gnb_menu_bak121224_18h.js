var gnb_str = "<div class='UxGnb' id='ixGnbId'>"
+"<div class='depth'>"
+"				<div class='foodContain'>"
+"					<div class='depth1Contain'>"
+"						<div class='quick-links'>"
+"							<ul>"
+"								<li class='thema-v1'><a href='/category/categoryList.do?CategoryID=C00200010032&SITELOC=LH001'>친환경식품</a></li>"
+"								<li class='thema-v2'><a href='/category/categoryList.do?CategoryID=C00200010035&SITELOC=LH002'>간편조리식품</a></li>"
+"								<li class='thema-v3'><a href='/category/categoryList.do?CategoryID=C00200010073&SITELOC=LH003'>지역특산물</a></li>"
+"								<li class='thema-v4'><a href='/category/categoryList.do?CategoryID=C00200010095&SITELOC=LH004'>커피전문관</a></li>"
+"							</ul>"
+"						</div>"
+"					</div>"
+"					<div class='depth2Contain'>"
+"						<div class='scroll_up'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/scroll_arrow_up.png' alt='위쪽' /></div>"
+"						<div class='scroll_down'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/scroll_arrow_down.png' alt='아래쪽' /></div>"
+"					</div>"
+"					<div class='depth3Contain'>"
+"						<div class='scroll_up'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/scroll_arrow_dep3_up.png' alt='위쪽' /></div>"
+"						<div class='scroll_down'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/scroll_arrow_dep3_down.png' alt='아래쪽' /></div>"
+"					</div>"
+"					<div class='extra'>"
+"						<ul class='banner'>"
+"							<li><a href='javascript:goCategoryList(\"C00600260039&SITELOC=LH005\");'><img src='http://image.lottemart.com/images/contentimg/main/201212/gnb_C00600260039_234_57.jpg' alt='온가족이 즐기는 크리스마스 먹거리 '></a></li>"
+"							<li><a href='javascript:goCategoryList(\"C00600260031&SITELOC=LH006\");'><img src='http://image.lottemart.com/images/contentimg/main/201212/gnb_C00600260031_234_57.jpg' alt='CJ, 동원, 사조해표 행사상품 3만원이상 구매시 핸드카트증정'></a></li>"
+"							<li><a href='javascript:goCategoryList(\"C00600260044&SITELOC=LH007\");'><img src='http://image.lottemart.com/images/contentimg/main/201212/gnb_C00600260044_234_57.jpg' alt='우리 가족 건강지킴이 겨울 인기 두유 '></a></li>"
+"						</ul>"
+"						<div class='pb'>"
+"							<p><a href='/category/categoryList.do?CategoryID=C004&SITELOC=LH008'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/title_lottermart_pb.gif' alt='롯데마트 PB - 합리적인 가격과 우수한 품질을 제공하는 롯데마트 자체브랜드 입니다.'></a></p>"
+"							<ul class=''>"
+"								<li><a href='/category/categoryList.do?CategoryID=C00400080001&SITELOC=LH008'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/txt_lottermart_pb_v3.gif' alt='바이로L'></a></li>"
+"								<li><a href='/category/categoryList.do?CategoryID=C00400020001&SITELOC=LH008'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/txt_lottermart_pb_v2.gif' alt='프라임L'></a></li>"
+"								<li class='diss-bg'><a href='/category/categoryList.do?CategoryID=C00400010001&SITELOC=LH008'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/txt_lottermart_pb_v1.gif' alt='초이스L'></a></li>"
+"								<li><a href='/category/categoryList.do?CategoryID=C00600010045&SITELOC=LH008'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/txt_lottermart_pb_v5.gif' alt='통큰/손큰'></a></li>"
+"								<li class='diss-bg'><a href='/category/categoryList.do?CategoryID=C00400060001&SITELOC=LH008'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/txt_lottermart_pb_v4.gif' alt='롯데마트랑'></a></li>"
+"							</ul>"
+"						</div>"
+"					</div>"
+"				</div>"
+"				<div class='lifeContain'>"
+"					<div class='depth1Contain'>"
+"						<div class='quick-links'>"
+"							<ul>"
+"								<li class='thema-v5'><a href='/category/categoryList.do?CategoryID=C00200010066&SITELOC=LI001'>맘스맘</a></li>"
+"								<li class='thema-v6'><a href='/category/categoryList.do?CategoryID=C00200010051&SITELOC=LI002'>주방용품브랜드</a></li>"
+"								<li class='thema-v7'><a href='/category/categoryList.do?CategoryID=C00200010102&SITELOC=LI003'>아웃도어관</a></li>"
+"								<li class='thema-v8'><a href='/category/categoryList.do?CategoryID=C00200010111&SITELOC=LI004'>언더워어관</a></li>"
+"							</ul>"
+"						</div>"
+"					</div>"
+"					<div class='depth2Contain'>"
+"						<div class='scroll_up'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/scroll_arrow_up.png' alt='위쪽' /></div>"
+"						<div class='scroll_down'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/scroll_arrow_down.png' alt='아래쪽' /></div>"
+"					</div>"
+"					<div class='depth3Contain'>"
+"						<div class='scroll_up'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/scroll_arrow_dep3_up.png' alt='위쪽' /></div>"
+"						<div class='scroll_down'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/scroll_arrow_dep3_down.png' alt='아래쪽' /></div>"
+"					</div>"
+"					<div class='extra'>"
+"						<ul class='banner'>"
+"							<li><a href='javascript:goCategoryList(\"C00600050116&SITELOC=LI005\");'><img src='http://image.lottemart.com/images/contentimg/main/201212/gnb_C00600050116_234_57.jpg' alt='아동내의 9,800원부터~ 누구도 따라올 수 없는 가격'></a></li>"
+"							<li><a href='javascript:goCategoryList(\"C00600310001&SITELOC=LI006\");'><img src='http://image.lottemart.com/images/contentimg/main/201212/gnb_C00600310001_234_57.jpg' alt='나이키&아디다스 패딩전'></a></li>"
+"							<li><a href='javascript:goCategoryList(\"C00600050115&SITELOC=LI007\");'><img src='http://image.lottemart.com/images/contentimg/main/201212/gnb_C00600050115_234_57.jpg' alt='더페이스샵 10% 마일리지적립+구매금액대별사은품'></a></li>"
+"							<li><a href='javascript:goCategoryList(\"C00600050085&SITELOC=LI008\");'><img src='http://image.lottemart.com/images/contentimg/main/201211/gnb_C00600050085_234_57.jpg' alt='보드복/보드용품 특가전!!'></a></li>"
+"						</ul>"
+"						<div class='pb'>"
+"							<p><a href='/category/categoryList.do?CategoryID=C004&SITELOC=LI009'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/title_lottermart_pb.gif' alt='롯데마트 PB - 합리적인 가격과 우수한 품질을 제공하는 롯데마트 자체브랜드 입니다.'></a></p>"
+"							<ul class=''>"
+"								<li><a href='/category/categoryList.do?CategoryID=C00400050001&SITELOC=LI009'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/txt_lottermart_pb_v6.gif' alt='세이브L'></a></li>"
+"								<li><a href='/category/categoryList.do?CategoryID=C00400030001&SITELOC=LI009'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/txt_lottermart_pb_v7.gif' alt='리빙L'></a></li>"
+"								<li class='diss-bg'><a href='/category/categoryList.do?CategoryID=C00400010001&SITELOC=LI009'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/txt_lottermart_pb_v1.gif' alt='초이스L'></a></li>"
+"								<li><a href='/category/categoryList.do?CategoryID=C00400090001&SITELOC=LI009'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/txt_lottermart_pb_v9.gif' alt='스포츠550'></a></li>"
+"								<li class='diss-bg'><a href='/category/categoryList.do?CategoryID=C00400040001&SITELOC=LI009'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/txt_lottermart_pb_v8.gif' alt='베이직아이콘'></a></li>"
+"							</ul>"
+"						</div>"
+"					</div>"
+"				</div>"
+"			</div>"
+"			<ul class='menu'>"
+"				<li><a><img src='http://image.lottemart.com/images/contentimg/main/uxindex/gnb_menu01.png' alt='푸드'></a></li>"
+"				<li><a><img src='http://image.lottemart.com/images/contentimg/main/uxindex/gnb_menu02.png' alt='라이프'></a></li>"
+"				<li><a><img src='http://image.lottemart.com/images/contentimg/main/uxindex/gnb_menu03.png' alt='전문몰'></a></li>"
+"				<li><a href='/category/categoryList.do?CategoryID=C002&SITELOC=LA021'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/gnb_menu04.png' alt='테마몰'></a></li>"
+"				<li><a href='/category/categoryList.do?CategoryID=C006&SITELOC=LA022'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/gnb_menu05.png' alt='기획전'></a></li>"
+"				<li><a href='/category/categoryList.do?CategoryID=C00600010045&SITELOC=LA023'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/gnb_menu06.png' alt='통큰/손큰'></a></li>"
+"				<li><a href='/category/categoryList.do?CategoryID=C004&SITELOC=LA024'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/gnb_menu07.png' alt='PB상품'></a></li>"
+"				<li><a href='/event/alive.do?SITELOC=LA025'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/gnb_menu08.png' alt='이벤트'></a></li>"
+"				<li class='coupon'><a href='/event/coupon.do?SITELOC=LA026'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/gnb_menu09.png' alt='쿠폰존'></a></li>"
+"			</ul>"
+"			<div class='uxOther'>"
+"				<ul>"
+"					<li class='first'>"
+"						<div class='details'>"
+"							<h3><a href='/indexDig.do?SITELOC=LJ001'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/DP_titlemore.gif' alt='디지털파크 더보기'></a></h3>"
+"							<p>"
+"								<a href='/product/ProductDetail.do?CategoryID=C021000200090001&ProductCD=L000000054672&SITELOC=LJ001'>넥서스7판매실시</a><br />"
+"								<a href='javascript:goCategorySpecList(\"C00600090003&SITELOC=LJ001\");'>TV 최저가 도전!</a><br />"
+"								<a href='javascript:goCategorySpecList(\"C00600090062&SITELOC=LJ001\");'>LG전자 김치냉장고</a>"
+"							</p>"
+"						</div>"
+"						<div class='img'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/DP_img.jpg' alt=''></div>"
+"					</li>"
+"					<li>"
+"						<div class='details'>"
+"							<h3><a href='/indexToy.do?SITELOC=LJ002'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/TP_titlemore.gif' alt='토이파크 더보기'></a></h3>"
+"							<p>"
+"								<a href='javascript:goCategorySpecList(\"C00600100002&SITELOC=LJ002\");'>토팍 power sale</a><br />"
+"								<a href='javascript:goCategorySpecList(\"C00600100001&SITELOC=LJ002\");'>완구 최대10%할인</a><br />"
+"								<a href='javascript:goCategorySpecList(\"C00600100054&SITELOC=LJ002\");'>토팍 선물 모음전</a>"
+"							</p>"
+"						</div>"
+"						<div class='img'><img src='http://image.lottemart.com/images/contentimg/main/201210/TP_img_1025.jpg' alt=''></div>"
+"					</li>"
+"					<li>"
+"						<div class='details'>"
+"							<h3><a href='/indexPet.do?SITELOC=LJ003'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/PE_titlemore.gif' alt='펫가든 더보기'></a></h3>"
+"							<p>"
+"								<a href='javascript:goCategorySpecList(\"C00600170073&SITELOC=LJ003\");'>애견간식딩고20%</a><br />"
+"								<a href='javascript:goCategorySpecList(\"C00600170074&SITELOC=LJ003\");'>고양이간식 증정</a><br />"
+"								<a href='javascript:goCategorySpecList(\"C00600170075&SITELOC=LJ003\");'>고양이놀이공간30%</a>"
+"							</p>"
+"						</div>"
+"						<div class='img'><img src='http://image.lottemart.com/images/contentimg/main/uxindex/PE_img.jpg' alt=''></div>"
+"					</li>"
+"				</ul>"
+"			</div>"
+"		</div>";
document.write(gnb_str);

		var foodData = [
			{
				title: '쌀', url: 'javascript:goCategoryList(&quot;C0010011&SITELOC=LK001&quot;);', target: '_self',	
				subMenu: [
					{
						title: '쌀 중량별', url: 'javascript:goCategoryList(&quot;C00100110001&SITELOC=LK002&quot;);', target: '_self',
						subMenu: [
							{title: '20Kg', url: 'javascript:goCategoryList(&quot;C001001100010001&quot;);', target: '_self'},
							{title: '10Kg', url: 'javascript:goCategoryList(&quot;C001001100010002&quot;);', target: '_self'},
							{title: '10Kg 이하/소포장', url: 'javascript:goCategoryList(&quot;C001001100010003&quot;);', target: '_self'}
						]
					},
					{
						title: '즉석 도정미', url: 'javascript:goCategoryList(&quot;C00100110002&SITELOC=LK003&quot;);', target: '_self',
						subMenu: [
							{title: '10Kg이상', url: 'javascript:goCategoryList(&quot;C001001100020001&quot;);', target: '_self'},
							{title: '10Kg이하/소포장', url: 'javascript:goCategoryList(&quot;C001001100020002&quot;);', target: '_self'}
						]
					},
					{
						title: '친환경 양곡', url: 'javascript:goCategoryList(&quot;C00100110003&SITELOC=LK004&quot;);', target: '_self',
						subMenu: [
							{title: '10Kg이상', url: 'javascript:goCategoryList(&quot;C001001100030001&quot;);', target: '_self'},
							{title: ' 10Kg이하/소포장', url: 'javascript:goCategoryList(&quot;C001001100030002&quot;);', target: '_self'}
						]
					},
					{
						title: '산지무료배송', url: 'javascript:goCategoryList(&quot;C00100110004&SITELOC=LK005&quot;);', target: '_self',
						subMenu: [
							{title: '20Kg', url: 'javascript:goCategoryList(&quot;C001001100040001&quot;);', target: '_self'},
							{title: '10Kg', url: 'javascript:goCategoryList(&quot;C001001100040002&quot;);', target: '_self'},
							{title: '10Kg 이하/소포장', url: 'javascript:goCategoryList(&quot;C001001100040003&quot;);', target: '_self'}
						]
					},
					{
						title: '찹쌀/현미/흑미', url: 'javascript:goCategoryList(&quot;C00100110005&SITELOC=LK006&quot;);', target: '_self',
						subMenu: [
							{title: '찹쌀', url: 'javascript:goCategoryList(&quot;C001001100050001&quot;);', target: '_self'},
							{title: '현미', url: 'javascript:goCategoryList(&quot;C001001100050002&quot;);', target: '_self'},
							{title: '흑미', url: 'javascript:goCategoryList(&quot;C001001100050003&quot;);', target: '_self'}
						]
					},
					{
						title: '보리/콩/팥', url: 'javascript:goCategoryList(&quot;C00100110006&SITELOC=LK007&quot;);', target: '_self',
						subMenu: [
							{title: '보리', url: 'javascript:goCategoryList(&quot;C001001100060001&quot;);', target: '_self'},
							{title: '콩/팥', url: 'javascript:goCategoryList(&quot;C001001100060002&quot;);', target: '_self'}
						]
					},
					{
						title: '혼합곡/기타', url: 'javascript:goCategoryList(&quot;C00100110007&SITELOC=LK008&quot;);', target: '_self',
						subMenu: [
							{title: '혼합곡', url: 'javascript:goCategoryList(&quot;C001001100070001&quot;);', target: '_self'},
							{title: '녹두/율무', url: 'javascript:goCategoryList(&quot;C001001100070002&quot;);', target: '_self'},
							{title: '참깨/들깨', url: 'javascript:goCategoryList(&quot;C001001100070003&quot;);', target: '_self'}
						]
					},
					{
						title: '잡곡류', url: 'javascript:goCategoryList(&quot;C00100110008&SITELOC=LK009&quot;);', target: '_self',
						subMenu: [
							{title: '콩/서리태', url: 'javascript:goCategoryList(&quot;C001001100080001&quot;);', target: '_self'},
							{title: '보리/기타', url: 'javascript:goCategoryList(&quot;C001001100080002&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '채소', url: 'javascript:goCategoryList(&quot;C0010012&SITELOC=LK010&quot;);', target: '_self',	
				subMenu: [
					{
						title: '두부/콩나물', url: 'javascript:goCategoryList(&quot;C00100110009&SITELOC=LK011&quot;);', target: '_self',
						subMenu: [
							{title: '찌게용두부', url: 'javascript:goCategoryList(&quot;C001001100090001&quot;);', target: '_self'},
							{title: '부침용 두부', url: 'javascript:goCategoryList(&quot;C001001100090002&quot;);', target: '_self'},
							{title: '혼합/기능성 두부', url: 'javascript:goCategoryList(&quot;C001001100090003&quot;);', target: '_self'},
							{title: '순두부/연두부', url: 'javascript:goCategoryList(&quot;C001001100090004&quot;);', target: '_self'},
							{title: '묵', url: 'javascript:goCategoryList(&quot;C001001100090005&quot;);', target: '_self'},
							{title: '콩나물/숙주나물', url: 'javascript:goCategoryList(&quot;C001001100090006&quot;);', target: '_self'}
						]
					},
					{
						title: '고구마/감자', url: 'javascript:goCategoryList(&quot;C00100120001&SITELOC=LK012&quot;);', target: '_self',
						subMenu: [
							{title: '고구마', url: 'javascript:goCategoryList(&quot;C001001200010001&quot;);', target: '_self'},
							{title: '감자', url: 'javascript:goCategoryList(&quot;C001001200010002&quot;);', target: '_self'}
						]
					},
					{
						title: '당근/뿌리채소', url: 'javascript:goCategoryList(&quot;C00100120002&SITELOC=LK013&quot;);', target: '_self',
						subMenu: [
							{title: '당근', url: 'javascript:goCategoryList(&quot;C001001200020001&quot;);', target: '_self'},
							{title: '마/야콘', url: 'javascript:goCategoryList(&quot;C001001200020002&quot;);', target: '_self'},
							{title: '우엉/연근', url: 'javascript:goCategoryList(&quot;C001001200020003&quot;);', target: '_self'},
							{title: '더덕/기타', url: 'javascript:goCategoryList(&quot;C001001200020004&quot;);', target: '_self'},
							{title: '약초', url: 'javascript:goCategoryList(&quot;C001001200020005&quot;);', target: '_self'}
						]
					},
					{
						title: '오이/호박/가지/옥수수', url: 'javascript:goCategoryList(&quot;C00100120003&SITELOC=LK014&quot;);', target: '_self',
						subMenu: [
							{title: '오이/가지', url: 'javascript:goCategoryList(&quot;C001001200030001&quot;);', target: '_self'},
							{title: '애호박/호박', url: 'javascript:goCategoryList(&quot;C001001200030002&quot;);', target: '_self'},
							{title: '옥수수', url: 'javascript:goCategoryList(&quot;C001001200030003&quot;);', target: '_self'}
						]
					},
					{
						title: '파프리카/고추/열매채소', url: 'javascript:goCategoryList(&quot;C00100120004&SITELOC=LK015&quot;);', target: '_self',
						subMenu: [
							{title: '파프리카/피망', url: 'javascript:goCategoryList(&quot;C001001200040001&quot;);', target: '_self'},
							{title: '고추/건고추', url: 'javascript:goCategoryList(&quot;C001001200040002&quot;);', target: '_self'}
						]
					},
					{
						title: '양배추/배추/무/김장채소', url: 'javascript:goCategoryList(&quot;C00100120005&SITELOC=LK016&quot;);', target: '_self',
						subMenu: [
							{title: '양배추/배추/무', url: 'javascript:goCategoryList(&quot;C001001200050001&quot;);', target: '_self'},
							{title: '부추/열무/알타리/갓', url: 'javascript:goCategoryList(&quot;C001001200050002&quot;);', target: '_self'}
						]
					},
					{
						title: '양파/마늘/생강/파', url: 'javascript:goCategoryList(&quot;C00100120006&SITELOC=LK017&quot;);', target: '_self',
						subMenu: [
							{title: '양파', url: 'javascript:goCategoryList(&quot;C001001200060001&quot;);', target: '_self'},
							{title: '마늘/생강', url: 'javascript:goCategoryList(&quot;C001001200060002&quot;);', target: '_self'},
							{title: '대파/쪽파', url: 'javascript:goCategoryList(&quot;C001001200060003&quot;);', target: '_self'},
							{title: '간편양념/채소', url: 'javascript:goCategoryList(&quot;C001001200060004&quot;);', target: '_self'}
						]
					},
					{
						title: '나물/시금치/잎줄기채소', url: 'javascript:goCategoryList(&quot;C00100120007&SITELOC=LK018&quot;);', target: '_self',
						subMenu: [
							{title: '시금치/미나리/쑥갓', url: 'javascript:goCategoryList(&quot;C001001200070001&quot;);', target: '_self'},
							{title: '잎줄기 채소', url: 'javascript:goCategoryList(&quot;C001001200070002&quot;);', target: '_self'},
							{title: '건나물/기타나물', url: 'javascript:goCategoryList(&quot;C001001200070003&quot;);', target: '_self'}
						]
					},
					{
						title: '상추/깻잎/쌈채소', url: 'javascript:goCategoryList(&quot;C00100120008&SITELOC=LK019&quot;);', target: '_self',
						subMenu: [
							{title: '상추/깻잎', url: 'javascript:goCategoryList(&quot;C001001200080001&quot;);', target: '_self'},
							{title: '쌈채소', url: 'javascript:goCategoryList(&quot;C001001200080002&quot;);', target: '_self'}
						]
					},
					{
						title: '브로콜리/양상추/샐러드', url: 'javascript:goCategoryList(&quot;C00100120009&SITELOC=LK020&quot;);', target: '_self',
						subMenu: [
							{title: '브로콜리/양상추', url: 'javascript:goCategoryList(&quot;C001001200090001&quot;);', target: '_self'},
							{title: '샐러드', url: 'javascript:goCategoryList(&quot;C001001200090002&quot;);', target: '_self'}
						]
					},
					{
						title: '새송이/느타리/버섯류', url: 'javascript:goCategoryList(&quot;C00100120010&SITELOC=LK021&quot;);', target: '_self',
						subMenu: [
							{title: '새송이/느타리', url: 'javascript:goCategoryList(&quot;C001001200100001&quot;);', target: '_self'},
							{title: '양송이/표고/팽이', url: 'javascript:goCategoryList(&quot;C001001200100002&quot;);', target: '_self'},
							{title: '건버섯', url: 'javascript:goCategoryList(&quot;C001001200100003&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '과일', url: 'javascript:goCategoryList(&quot;C0010013&SITELOC=LK022&quot;);', target: '_self',	
				subMenu: [
					{
						title: '사과/배', url: 'javascript:goCategoryList(&quot;C00100130001&SITELOC=LK023&quot;);', target: '_self',
						subMenu: [
							{title: '사과', url: 'javascript:goCategoryList(&quot;C001001300010001&quot;);', target: '_self'},
							{title: '배', url: 'javascript:goCategoryList(&quot;C001001300010002&quot;);', target: '_self'},
							{title: '사과/배 혼합', url: 'javascript:goCategoryList(&quot;C001001300010003&quot;);', target: '_self'}
						]
					},
					{
						title: '감귤/한라봉', url: 'javascript:goCategoryList(&quot;C00100130002&SITELOC=LK024&quot;);', target: '_self',
						subMenu: [
							{title: '감귤/한라봉', url: 'javascript:goCategoryList(&quot;C001001300020001&quot;);', target: '_self'},
							{title: '천혜향/레드향/기타', url: 'javascript:goCategoryList(&quot;C001001300020002&quot;);', target: '_self'}
						]
					},
					{
						title: '감/곶감', url: 'javascript:goCategoryList(&quot;C00100130003&SITELOC=LK025&quot;);', target: '_self',
						subMenu: [
							{title: '감', url: 'javascript:goCategoryList(&quot;C001001300030001&quot;);', target: '_self'},
							{title: '곶감', url: 'javascript:goCategoryList(&quot;C001001300030002&quot;);', target: '_self'},
							{title: '감말랭이/홍시', url: 'javascript:goCategoryList(&quot;C001001300030003&quot;);', target: '_self'}
						]
					},
					{
						title: '키위', url: 'javascript:goCategoryList(&quot;C00100130004&SITELOC=LK026&quot;);', target: '_self',
						subMenu: [
							{title: '골드키위', url: 'javascript:goCategoryList(&quot;C001001300040001&quot;);', target: '_self'},
							{title: '그린키위', url: 'javascript:goCategoryList(&quot;C001001300040002&quot;);', target: '_self'},
							{title: '레드키위', url: 'javascript:goCategoryList(&quot;C001001300040004&quot;);', target: '_self'}
						]
					},
					{
						title: '토마토/복숭아/포도', url: 'javascript:goCategoryList(&quot;C00100130005&SITELOC=LK027&quot;);', target: '_self',
						subMenu: [
							{title: '토마토', url: 'javascript:goCategoryList(&quot;C001001300050001&quot;);', target: '_self'},
							{title: '복숭아', url: 'javascript:goCategoryList(&quot;C001001300050003&quot;);', target: '_self'},
							{title: '포도', url: 'javascript:goCategoryList(&quot;C001001300050004&quot;);', target: '_self'}
						]
					},
					{
						title: '수박/메론/참외', url: 'javascript:goCategoryList(&quot;C00100130006&SITELOC=LK028&quot;);', target: '_self',
						subMenu: [
							{title: '수박', url: 'javascript:goCategoryList(&quot;C001001300060001&quot;);', target: '_self'},
							{title: '메론', url: 'javascript:goCategoryList(&quot;C001001300060002&quot;);', target: '_self'},
							{title: '참외', url: 'javascript:goCategoryList(&quot;C001001300060003&quot;);', target: '_self'}
						]
					},
					{
						title: '딸기/블루베리/매실/기타', url: 'javascript:goCategoryList(&quot;C00100130007&SITELOC=LK029&quot;);', target: '_self',
						subMenu: [
							{title: '딸기', url: 'javascript:goCategoryList(&quot;C001001300070001&quot;);', target: '_self'},
							{title: '블루베리', url: 'javascript:goCategoryList(&quot;C001001300070002&quot;);', target: '_self'},
							{title: '매실', url: 'javascript:goCategoryList(&quot;C001001300070003&quot;);', target: '_self'},
							{title: '기타과일', url: 'javascript:goCategoryList(&quot;C001001300070004&quot;);', target: '_self'}
						]
					},
					{
						title: '바나나/오렌지/외국과일', url: 'javascript:goCategoryList(&quot;C00100130008&SITELOC=LK030&quot;);', target: '_self',
						subMenu: [
							{title: '바나나', url: 'javascript:goCategoryList(&quot;C001001300080001&quot;);', target: '_self'},
							{title: '오렌지', url: 'javascript:goCategoryList(&quot;C001001300080002&quot;);', target: '_self'},
							{title: '파인애플', url: 'javascript:goCategoryList(&quot;C001001300080003&quot;);', target: '_self'},
							{title: '자몽/레몬/석류', url: 'javascript:goCategoryList(&quot;C001001300080004&quot;);', target: '_self'},
							{title: '망고/체리/기타', url: 'javascript:goCategoryList(&quot;C001001300080005&quot;);', target: '_self'}
						]
					},
					{
						title: '땅콩/대추/건과/견과류', url: 'javascript:goCategoryList(&quot;C00100130009&SITELOC=LK031&quot;);', target: '_self',
						subMenu: [
							{title: '건포도/건대추/건과일', url: 'javascript:goCategoryList(&quot;C001001300090001&quot;);', target: '_self'},
							{title: '밤/땅콩/호두/기타', url: 'javascript:goCategoryList(&quot;C001001300090002&quot;);', target: '_self'},
							{title: '아몬드/캐슈넛/피스타치오/기타', url: 'javascript:goCategoryList(&quot;C001001300090003&quot;);', target: '_self'},
							{title: '혼합견과', url: 'javascript:goCategoryList(&quot;C001001300090004&quot;);', target: '_self'}
						]
					},
					{
						title: '냉동/간편과일', url: 'javascript:goCategoryList(&quot;C00100130010&SITELOC=LK032&quot;);', target: '_self',
						subMenu: [
							{title: '냉동과일', url: 'javascript:goCategoryList(&quot;C001001300100001&quot;);', target: '_self'},
							{title: '간편과일', url: 'javascript:goCategoryList(&quot;C001001300100002&quot;);', target: '_self'}
						]
					},
					{
						title: '과일세트', url: 'javascript:goCategoryList(&quot;C00100130011&SITELOC=LK033&quot;);', target: '_self',
						subMenu: [
							{title: '과일바구니', url: 'javascript:goCategoryList(&quot;C001001300110001&quot;);', target: '_self'},
							{title: '사과', url: 'javascript:goCategoryList(&quot;C001001300110002&quot;);', target: '_self'},
							{title: '배', url: 'javascript:goCategoryList(&quot;C001001300110003&quot;);', target: '_self'},
							{title: '사과/배 혼합', url: 'javascript:goCategoryList(&quot;C001001300110004&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '정육/계란', url: 'javascript:goCategoryList(&quot;C0010014&SITELOC=LK034&quot;);', target: '_self',	
				subMenu: [
					{
						title: '한우', url: 'javascript:goCategoryList(&quot;C00100140001&SITELOC=LK035&quot;);', target: '_self',
						subMenu: [
							{title: '등심/안심/구이', url: 'javascript:goCategoryList(&quot;C001001400010001&quot;);', target: '_self'},
							{title: '갈비/찜', url: 'javascript:goCategoryList(&quot;C001001400010002&quot;);', target: '_self'},
							{title: '한우국거리/기타', url: 'javascript:goCategoryList(&quot;C001001400010003&quot;);', target: '_self'},
							{title: '사골/꼬리/우족', url: 'javascript:goCategoryList(&quot;C001001400010004&quot;);', target: '_self'},
							{title: '불고기/산적/장조림', url: 'javascript:goCategoryList(&quot;C001001400010005&quot;);', target: '_self'}
						]
					},
					{
						title: '브랜드 한우', url: 'javascript:goCategoryList(&quot;C00100140002&SITELOC=LK036&quot;);', target: '_self',
						subMenu: [
							{title: '진심한우', url: 'javascript:goCategoryList(&quot;C001001400020005&quot;);', target: '_self'},
							{title: '횡성한우', url: 'javascript:goCategoryList(&quot;C001001400020001&quot;);', target: '_self'},
							{title: '영주축협한우', url: 'javascript:goCategoryList(&quot;C001001400020002&quot;);', target: '_self'},
							{title: '자연채 한우', url: 'javascript:goCategoryList(&quot;C001001400020003&quot;);', target: '_self'},
							{title: '단심육한우', url: 'javascript:goCategoryList(&quot;C001001400020004&quot;);', target: '_self'}
						]
					},
					{
						title: '수입육', url: 'javascript:goCategoryList(&quot;C00100140003&SITELOC=LK037&quot;);', target: '_self',
						subMenu: [
							{title: '호주산', url: 'javascript:goCategoryList(&quot;C001001400030001&quot;);', target: '_self'},
							{title: '미국산', url: 'javascript:goCategoryList(&quot;C001001400030002&quot;);', target: '_self'}
						]
					},
					{
						title: '돼지고기', url: 'javascript:goCategoryList(&quot;C00100140004&SITELOC=LK038&quot;);', target: '_self',
						subMenu: [
							{title: '삼겹살/목심/구이', url: 'javascript:goCategoryList(&quot;C001001400040001&quot;);', target: '_self'},
							{title: '불고기/찌개/다짐육', url: 'javascript:goCategoryList(&quot;C001001400040002&quot;);', target: '_self'},
							{title: '갈비/찜/바비큐', url: 'javascript:goCategoryList(&quot;C001001400040003&quot;);', target: '_self'},
							{title: '장조림/돈까스/카레', url: 'javascript:goCategoryList(&quot;C001001400040004&quot;);', target: '_self'},
							{title: '소포장', url: 'javascript:goCategoryList(&quot;C001001400040005&quot;);', target: '_self'}
						]
					},
					{
						title: '양념육/가공육', url: 'javascript:goCategoryList(&quot;C00100140005&SITELOC=LK039&quot;);', target: '_self',
						subMenu: [
							{title: '소고기', url: 'javascript:goCategoryList(&quot;C001001400050001&quot;);', target: '_self'},
							{title: '돼지고기', url: 'javascript:goCategoryList(&quot;C001001400050002&quot;);', target: '_self'},
							{title: '닭/오리고기', url: 'javascript:goCategoryList(&quot;C001001400050003&quot;);', target: '_self'}
						]
					},
					{
						title: '닭/오리고기', url: 'javascript:goCategoryList(&quot;C00100140006&SITELOC=LK040&quot;);', target: '_self',
						subMenu: [
							{title: '백숙용 닭고기', url: 'javascript:goCategoryList(&quot;C001001400060001&quot;);', target: '_self'},
							{title: '볶음탕용 닭고기', url: 'javascript:goCategoryList(&quot;C001001400060002&quot;);', target: '_self'},
							{title: '닭가슴살/안심', url: 'javascript:goCategoryList(&quot;C001001400060003&quot;);', target: '_self'},
							{title: '닭다리/날개/윙봉', url: 'javascript:goCategoryList(&quot;C001001400060004&quot;);', target: '_self'},
							{title: '오리', url: 'javascript:goCategoryList(&quot;C001001400060005&quot;);', target: '_self'},
							{title: '닭/오리훈제', url: 'javascript:goCategoryList(&quot;C001001400060006&quot;);', target: '_self'}
						]
					},
					{
						title: '계란', url: 'javascript:goCategoryList(&quot;C00100140007&SITELOC=LK041&quot;);', target: '_self',
						subMenu: [
							{title: '계란 10구이하', url: 'javascript:goCategoryList(&quot;C001001400070001&quot;);', target: '_self'},
							{title: '계란 15구이상', url: 'javascript:goCategoryList(&quot;C001001400070002&quot;);', target: '_self'},
							{title: '계란 30구', url: 'javascript:goCategoryList(&quot;C001001400070003&quot;);', target: '_self'},
							{title: '메추리알/기타', url: 'javascript:goCategoryList(&quot;C001001400070004&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '생선/건해산물', url: 'javascript:goCategoryList(&quot;C0010015&SITELOC=LK042&quot;);', target: '_self',	
				subMenu: [
					{
						title: '고등어/갈치/삼치/꽁치', url: 'javascript:goCategoryList(&quot;C00100150001&SITELOC=LK043&quot;);', target: '_self',
						subMenu: [
							{title: '고등어', url: 'javascript:goCategoryList(&quot;C001001500010001&quot;);', target: '_self'},
							{title: '갈치', url: 'javascript:goCategoryList(&quot;C001001500010002&quot;);', target: '_self'},
							{title: '삼치', url: 'javascript:goCategoryList(&quot;C001001500010003&quot;);', target: '_self'},
							{title: '꽁치', url: 'javascript:goCategoryList(&quot;C001001500010004&quot;);', target: '_self'}
						]
					},
					{
						title: '굴비/조기/옥돔/명태/기타', url: 'javascript:goCategoryList(&quot;C00100150002&SITELOC=LK044&quot;);', target: '_self',
						subMenu: [
							{title: '굴비/참조기', url: 'javascript:goCategoryList(&quot;C001001500020001&quot;);', target: '_self'},
							{title: '옥돔', url: 'javascript:goCategoryList(&quot;C001001500020002&quot;);', target: '_self'},
							{title: '명태류', url: 'javascript:goCategoryList(&quot;C001001500020003&quot;);', target: '_self'},
							{title: '대구/가자미', url: 'javascript:goCategoryList(&quot;C001001500020004&quot;);', target: '_self'},
							{title: '열빙어/전어', url: 'javascript:goCategoryList(&quot;C001001500020005&quot;);', target: '_self'},
							{title: '참치/연어', url: 'javascript:goCategoryList(&quot;C001001500020006&quot;);', target: '_self'},
							{title: '임연수', url: 'javascript:goCategoryList(&quot;C001001500020007&quot;);', target: '_self'},
							{title: '기타생선', url: 'javascript:goCategoryList(&quot;C001001500020008&quot;);', target: '_self'},
							{title: '냉동간편포장', url: 'javascript:goCategoryList(&quot;C001001500020009&quot;);', target: '_self'}
						]
					},
					{
						title: '오징어/낙지', url: 'javascript:goCategoryList(&quot;C00100150003&SITELOC=LK045&quot;);', target: '_self',
						subMenu: [
							{title: '오징어', url: 'javascript:goCategoryList(&quot;C001001500030001&quot;);', target: '_self'},
							{title: '낙지/쭈꾸미', url: 'javascript:goCategoryList(&quot;C001001500030002&quot;);', target: '_self'}
						]
					},
					{
						title: '해산물/새우/게/장어', url: 'javascript:goCategoryList(&quot;C00100150004&SITELOC=LK046&quot;);', target: '_self',
						subMenu: [
							{title: '소라/골뱅이', url: 'javascript:goCategoryList(&quot;C001001500040001&quot;);', target: '_self'},
							{title: '장어/과메기', url: 'javascript:goCategoryList(&quot;C001001500040002&quot;);', target: '_self'},
							{title: '날치알/성게알/알류', url: 'javascript:goCategoryList(&quot;C001001500040003&quot;);', target: '_self'},
							{title: '굴/바지락살/새우살/기타', url: 'javascript:goCategoryList(&quot;C001001500040005&quot;);', target: '_self'},
							{title: '새우', url: 'javascript:goCategoryList(&quot;C001001500040006&quot;);', target: '_self'},
							{title: '꽃게/대게/붉은대게', url: 'javascript:goCategoryList(&quot;C001001500040007&quot;);', target: '_self'}
						]
					},
					{
						title: '전복/조개류', url: 'javascript:goCategoryList(&quot;C00100150005&SITELOC=LK047&quot;);', target: '_self',
						subMenu: [
							{title: '전복', url: 'javascript:goCategoryList(&quot;C001001500050001&quot;);', target: '_self'},
							{title: '조개류', url: 'javascript:goCategoryList(&quot;C001001500050002&quot;);', target: '_self'},
							{title: '꼬막/바지락/홍합', url: 'javascript:goCategoryList(&quot;C001001500050003&quot;);', target: '_self'}
						]
					},
					{
						title: '회', url: 'javascript:goCategoryList(&quot;C00100150006&SITELOC=LK048&quot;);', target: '_self',
						subMenu: [
							{title: '회', url: 'javascript:goCategoryList(&quot;C001001500060001&quot;);', target: '_self'}
						]
					},
					{
						title: '멸치/건새우', url: 'javascript:goCategoryList(&quot;C00100150007&SITELOC=LK049&quot;);', target: '_self',
						subMenu: [
							{title: '멸치', url: 'javascript:goCategoryList(&quot;C001001500070001&quot;);', target: '_self'},
							{title: '건새우', url: 'javascript:goCategoryList(&quot;C001001500070002&quot;);', target: '_self'},
							{title: '다시티백/분말류', url: 'javascript:goCategoryList(&quot;C001001500070003&quot;);', target: '_self'}
						]
					},
					{
						title: '조미김/생김', url: 'javascript:goCategoryList(&quot;C00100150008&SITELOC=LK050&quot;);', target: '_self',
						subMenu: [
							{title: '구운김/조미김', url: 'javascript:goCategoryList(&quot;C001001500080001&quot;);', target: '_self'},
							{title: '생김/파래김', url: 'javascript:goCategoryList(&quot;C001001500080002&quot;);', target: '_self'},
							{title: '도시락/김밥용김', url: 'javascript:goCategoryList(&quot;C001001500080003&quot;);', target: '_self'},
							{title: '김자반', url: 'javascript:goCategoryList(&quot;C001001500080004&quot;);', target: '_self'}
						]
					},
					{
						title: '미역/다시마', url: 'javascript:goCategoryList(&quot;C00100150009&SITELOC=LK051&quot;);', target: '_self',
						subMenu: [
							{title: '미역', url: 'javascript:goCategoryList(&quot;C001001500090001&quot;);', target: '_self'},
							{title: '다시마', url: 'javascript:goCategoryList(&quot;C001001500090002&quot;);', target: '_self'}
						]
					},
					{
						title: '건오징어/어포/육포', url: 'javascript:goCategoryList(&quot;C00100150010&SITELOC=LK052&quot;);', target: '_self',
						subMenu: [
							{title: '건오징어', url: 'javascript:goCategoryList(&quot;C001001500100001&quot;);', target: '_self'},
							{title: '진미채', url: 'javascript:goCategoryList(&quot;C001001500100002&quot;);', target: '_self'},
							{title: '어포/쥐포', url: 'javascript:goCategoryList(&quot;C001001500100003&quot;);', target: '_self'},
							{title: '육포', url: 'javascript:goCategoryList(&quot;C001001500100004&quot;);', target: '_self'},
							{title: '황태/북어', url: 'javascript:goCategoryList(&quot;C001001500100005&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '냉장/냉동', url: 'javascript:goCategoryList(&quot;C0010016&SITELOC=LK053&quot;);', target: '_self',	
				subMenu: [
					{
						title: '소시지/햄/베이컨', url: 'javascript:goCategoryList(&quot;C00100160001&SITELOC=LK054&quot;);', target: '_self',
						subMenu: [
							{title: '후랑크,비엔나', url: 'javascript:goCategoryList(&quot;C001001600010001&quot;);', target: '_self'},
							{title: '슬라이스햄/분절햄', url: 'javascript:goCategoryList(&quot;C001001600010002&quot;);', target: '_self'},
							{title: '라운드햄/소시지', url: 'javascript:goCategoryList(&quot;C001001600010003&quot;);', target: '_self'},
							{title: '베이컨', url: 'javascript:goCategoryList(&quot;C001001600010004&quot;);', target: '_self'},
							{title: '어린이 소시지', url: 'javascript:goCategoryList(&quot;C001001600010005&quot;);', target: '_self'}
						]
					},
					{
						title: '맛살/어묵/단무지', url: 'javascript:goCategoryList(&quot;C00100160002&SITELOC=LK055&quot;);', target: '_self',
						subMenu: [
							{title: '맛살', url: 'javascript:goCategoryList(&quot;C001001600020001&quot;);', target: '_self'},
							{title: '어묵', url: 'javascript:goCategoryList(&quot;C001001600020002&quot;);', target: '_self'},
							{title: '유부', url: 'javascript:goCategoryList(&quot;C001001600020003&quot;);', target: '_self'},
							{title: '곤약', url: 'javascript:goCategoryList(&quot;C001001600020004&quot;);', target: '_self'},
							{title: '단무지/쌈무', url: 'javascript:goCategoryList(&quot;C001001600020005&quot;);', target: '_self'},
							{title: '절임/피클', url: 'javascript:goCategoryList(&quot;C001001600020006&quot;);', target: '_self'}
						]
					},
					{
						title: '냉장면/냉장떡', url: 'javascript:goCategoryList(&quot;C00100160003&SITELOC=LK056&quot;);', target: '_self',
						subMenu: [
							{title: '우동/메밀/중화면', url: 'javascript:goCategoryList(&quot;C001001600030003&quot;);', target: '_self'},
							{title: '스파게티', url: 'javascript:goCategoryList(&quot;C001001600030002&quot;);', target: '_self'},
							{title: '칼국수/쫄면 외', url: 'javascript:goCategoryList(&quot;C001001600030004&quot;);', target: '_self'},
							{title: '떡/떡볶이', url: 'javascript:goCategoryList(&quot;C001001600030005&quot;);', target: '_self'},
							{title: '냉면', url: 'javascript:goCategoryList(&quot;C001001600030001&quot;);', target: '_self'}
						]
					},
					{
						title: '냉장반찬/포장김치', url: 'javascript:goCategoryList(&quot;C00100160004&SITELOC=LK057&quot;);', target: '_self',
						subMenu: [
							{title: '포장젓갈', url: 'javascript:goCategoryList(&quot;C001001600040001&quot;);', target: '_self'},
							{title: '무침/조림/절임/볶음 반찬류', url: 'javascript:goCategoryList(&quot;C001001600040002&quot;);', target: '_self'},
							{title: '게장/벌크젓갈', url: 'javascript:goCategoryList(&quot;C001001600040003&quot;);', target: '_self'},
							{title: '냉장장류', url: 'javascript:goCategoryList(&quot;C001001600040004&quot;);', target: '_self'},
							{title: '포기김치', url: 'javascript:goCategoryList(&quot;C001001600040005&quot;);', target: '_self'},
							{title: '맛김치/여행용김치', url: 'javascript:goCategoryList(&quot;C001001600040006&quot;);', target: '_self'},
							{title: '무/기타김치', url: 'javascript:goCategoryList(&quot;C001001600040007&quot;);', target: '_self'}
						]
					},
					{
						title: '아이스크림', url: 'javascript:goCategoryList(&quot;C00100160005&SITELOC=LK058&quot;);', target: '_self',
						subMenu: [
							{title: '바/콘 아이스크림', url: 'javascript:goCategoryList(&quot;C001001600050001&quot;);', target: '_self'},
							{title: '홈 아이스크림', url: 'javascript:goCategoryList(&quot;C001001600050002&quot;);', target: '_self'},
							{title: '구슬아이스크림', url: 'javascript:goCategoryList(&quot;C001001600050003&quot;);', target: '_self'}
						]
					},
					{
						title: '만두/만두피', url: 'javascript:goCategoryList(&quot;C00100160006&SITELOC=LK059&quot;);', target: '_self',
						subMenu: [
							{title: '군만두', url: 'javascript:goCategoryList(&quot;C001001600060001&quot;);', target: '_self'},
							{title: '물만두', url: 'javascript:goCategoryList(&quot;C001001600060002&quot;);', target: '_self'},
							{title: '손/찜만두', url: 'javascript:goCategoryList(&quot;C001001600060003&quot;);', target: '_self'},
							{title: '교자만두', url: 'javascript:goCategoryList(&quot;C001001600060004&quot;);', target: '_self'},
							{title: '만두피', url: 'javascript:goCategoryList(&quot;C001001600060005&quot;);', target: '_self'}
						]
					},
					{
						title: '냉동간식/반찬', url: 'javascript:goCategoryList(&quot;C00100160007&SITELOC=LK060&quot;);', target: '_self',
						subMenu: [
							{title: '떡갈비/완자', url: 'javascript:goCategoryList(&quot;C001001600070001&quot;);', target: '_self'},
							{title: '동그랑땡', url: 'javascript:goCategoryList(&quot;C001001600070002&quot;);', target: '_self'},
							{title: '스테이크/패티', url: 'javascript:goCategoryList(&quot;C001001600070003&quot;);', target: '_self'},
							{title: '가스류 (돈/생선/치킨..)', url: 'javascript:goCategoryList(&quot;C001001600070004&quot;);', target: '_self'},
							{title: '너겟/치킨/윙', url: 'javascript:goCategoryList(&quot;C001001600070005&quot;);', target: '_self'},
							{title: '감자/오징어/기타튀김', url: 'javascript:goCategoryList(&quot;C001001600070006&quot;);', target: '_self'},
							{title: '기타 (냉동떡/춘권피/꽃빵/낫또..)', url: 'javascript:goCategoryList(&quot;C001001600070007&quot;);', target: '_self'}
						]
					},
					{
						title: '간편 조리식품', url: 'javascript:goCategoryList(&quot;C00100160008&SITELOC=LK061&quot;);', target: '_self',
						subMenu: [
							{title: '냉동 탕/국/찌개', url: 'javascript:goCategoryList(&quot;C001001600080001&quot;);', target: '_self'},
							{title: '냉동 밥/면류', url: 'javascript:goCategoryList(&quot;C001001600080002&quot;);', target: '_self'},
							{title: '냉장 간편식 (밥/죽/반찬..)', url: 'javascript:goCategoryList(&quot;C001001600080006&quot;);', target: '_self'},
							{title: '피자/핫도그/냉동케익 간식류', url: 'javascript:goCategoryList(&quot;C001001600080003&quot;);', target: '_self'},
							{title: '냉동반찬/야식/안주', url: 'javascript:goCategoryList(&quot;C001001600080004&quot;);', target: '_self'}
						]
					},
					{
						title: '우유/요구르트', url: 'javascript:goCategoryList(&quot;C00100160009&SITELOC=LK062&quot;);', target: '_self',
						subMenu: [
							{title: '흰우유', url: 'javascript:goCategoryList(&quot;C001001600090001&quot;);', target: '_self'},
							{title: '기능성 흰우유', url: 'javascript:goCategoryList(&quot;C001001600090002&quot;);', target: '_self'},
							{title: '바나나/커피 가공우유', url: 'javascript:goCategoryList(&quot;C001001600090003&quot;);', target: '_self'},
							{title: '떠먹는 요구르트', url: 'javascript:goCategoryList(&quot;C001001600090004&quot;);', target: '_self'},
							{title: '마시는 요구르트', url: 'javascript:goCategoryList(&quot;C001001600090005&quot;);', target: '_self'}
						]
					},
					{
						title: '치즈/버터/디저트', url: 'javascript:goCategoryList(&quot;C00100160010&SITELOC=LK063&quot;);', target: '_self',
						subMenu: [
							{title: '슬라이스 치즈', url: 'javascript:goCategoryList(&quot;C001001600100001&quot;);', target: '_self'},
							{title: '자연/피자치즈', url: 'javascript:goCategoryList(&quot;C001001600100002&quot;);', target: '_self'},
							{title: '크림치즈', url: 'javascript:goCategoryList(&quot;C001001600100007&quot;);', target: '_self'},
							{title: '어린이용 치즈', url: 'javascript:goCategoryList(&quot;C001001600100003&quot;);', target: '_self'},
							{title: '버터/마가린', url: 'javascript:goCategoryList(&quot;C001001600100004&quot;);', target: '_self'},
							{title: '생크림/연유', url: 'javascript:goCategoryList(&quot;C001001600100005&quot;);', target: '_self'},
							{title: '냉장 디저트', url: 'javascript:goCategoryList(&quot;C001001600100006&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '가공식품', url: 'javascript:goCategoryList(&quot;C0010017&SITELOC=LK064&quot;);', target: '_self',	
				subMenu: [
					{
						title: '라면/면류', url: 'javascript:goCategoryList(&quot;C00100170001&SITELOC=LK065&quot;);', target: '_self',
						subMenu: [
							{title: '낱개 봉지라면', url: 'javascript:goCategoryList(&quot;C001001700010001&quot;);', target: '_self'},
							{title: '박스 봉지라면', url: 'javascript:goCategoryList(&quot;C001001700010002&quot;);', target: '_self'},
							{title: '낱개 컵라면', url: 'javascript:goCategoryList(&quot;C001001700010003&quot;);', target: '_self'},
							{title: '박스 컵라면', url: 'javascript:goCategoryList(&quot;C001001700010004&quot;);', target: '_self'},
							{title: '국수', url: 'javascript:goCategoryList(&quot;C001001700010005&quot;);', target: '_self'},
							{title: '당면/건냉면', url: 'javascript:goCategoryList(&quot;C001001700010006&quot;);', target: '_self'},
							{title: '생면(우동/스파게티류)', url: 'javascript:goCategoryList(&quot;C001001700010007&quot;);', target: '_self'},
							{title: '스파게티/파스타류', url: 'javascript:goCategoryList(&quot;C001001700010008&quot;);', target: '_self'},
							{title: '수입면/쌈', url: 'javascript:goCategoryList(&quot;C001001700010009&quot;);', target: '_self'}
						]
					},
					{
						title: '즉석밥/죽/반찬', url: 'javascript:goCategoryList(&quot;C00100170002&SITELOC=LK066&quot;);', target: '_self',
						subMenu: [
							{title: '즉석밥/덮밥/국밥/누룽지', url: 'javascript:goCategoryList(&quot;C001001700020001&quot;);', target: '_self'},
							{title: '즉석/분말 죽', url: 'javascript:goCategoryList(&quot;C001001700020002&quot;);', target: '_self'},
							{title: '즉석/분말 스프', url: 'javascript:goCategoryList(&quot;C001001700020003&quot;);', target: '_self'},
							{title: '즉석 국/반찬', url: 'javascript:goCategoryList(&quot;C001001700020004&quot;);', target: '_self'},
							{title: '덮밥 소스/밥 양념', url: 'javascript:goCategoryList(&quot;C001001700020005&quot;);', target: '_self'},
							{title: '카레/짜장', url: 'javascript:goCategoryList(&quot;C001001700020006&quot;);', target: '_self'}
						]
					},
					{
						title: '통조림', url: 'javascript:goCategoryList(&quot;C00100170003&SITELOC=LK067&quot;);', target: '_self',
						subMenu: [
							{title: '참치 통조림', url: 'javascript:goCategoryList(&quot;C001001700030001&quot;);', target: '_self'},
							{title: '고등어/꽁치/골뱅이', url: 'javascript:goCategoryList(&quot;C001001700030002&quot;);', target: '_self'},
							{title: '옥수수/반찬 통조림', url: 'javascript:goCategoryList(&quot;C001001700030003&quot;);', target: '_self'},
							{title: '과일 통조림', url: 'javascript:goCategoryList(&quot;C001001700030004&quot;);', target: '_self'},
							{title: '스팸/햄 통조림', url: 'javascript:goCategoryList(&quot;C001001700030005&quot;);', target: '_self'},
							{title: '닭가슴살 통조림', url: 'javascript:goCategoryList(&quot;C001001700030006&quot;);', target: '_self'}
						]
					},
					{
						title: '가루/믹스류', url: 'javascript:goCategoryList(&quot;C00100170004&SITELOC=LK068&quot;);', target: '_self',
						subMenu: [
							{title: '밀가루', url: 'javascript:goCategoryList(&quot;C001001700040001&quot;);', target: '_self'},
							{title: '곡물가루/엿기름', url: 'javascript:goCategoryList(&quot;C001001700040002&quot;);', target: '_self'},
							{title: '부침/튀김가루', url: 'javascript:goCategoryList(&quot;C001001700040003&quot;);', target: '_self'},
							{title: '미숫가루/선식', url: 'javascript:goCategoryList(&quot;C001001700040004&quot;);', target: '_self'},
							{title: '홈메이드믹스', url: 'javascript:goCategoryList(&quot;C001001700040005&quot;);', target: '_self'},
							{title: '제빵재료', url: 'javascript:goCategoryList(&quot;C001001700040006&quot;);', target: '_self'}
						]
					},
					{
						title: '장류/간장', url: 'javascript:goCategoryList(&quot;C00100170005&SITELOC=LK069&quot;);', target: '_self',
						subMenu: [
							{title: '고추장', url: 'javascript:goCategoryList(&quot;C001001700050001&quot;);', target: '_self'},
							{title: '된장/춘장', url: 'javascript:goCategoryList(&quot;C001001700050002&quot;);', target: '_self'},
							{title: '초고추장/쌈장', url: 'javascript:goCategoryList(&quot;C001001700050003&quot;);', target: '_self'},
							{title: '진/혼합간장', url: 'javascript:goCategoryList(&quot;C001001700050004&quot;);', target: '_self'},
							{title: '양조/한식간장', url: 'javascript:goCategoryList(&quot;C001001700050005&quot;);', target: '_self'}
						]
					},
					{
						title: '소스류/케찹/마요네즈', url: 'javascript:goCategoryList(&quot;C00100170006&SITELOC=LK070&quot;);', target: '_self',
						subMenu: [
							{title: '케찹', url: 'javascript:goCategoryList(&quot;C001001700060001&quot;);', target: '_self'},
							{title: '마요네즈', url: 'javascript:goCategoryList(&quot;C001001700060002&quot;);', target: '_self'},
							{title: '드레싱', url: 'javascript:goCategoryList(&quot;C001001700060003&quot;);', target: '_self'},
							{title: '국물/양념소스', url: 'javascript:goCategoryList(&quot;C001001700060004&quot;);', target: '_self'},
							{title: '돼지/불고기/찜닭 양념', url: 'javascript:goCategoryList(&quot;C001001700060009&quot;);', target: '_self'},
							{title: '중식/양식/파스타 소스', url: 'javascript:goCategoryList(&quot;C001001700060005&quot;);', target: '_self'},
							{title: '수입소스 전용', url: 'javascript:goCategoryList(&quot;C001001700060006&quot;);', target: '_self'},
							{title: '식초', url: 'javascript:goCategoryList(&quot;C001001700060007&quot;);', target: '_self'},
							{title: '음용식초', url: 'javascript:goCategoryList(&quot;C001001700060008&quot;);', target: '_self'}
						]
					},
					{
						title: '조미료/설탕/소금', url: 'javascript:goCategoryList(&quot;C00100170007&SITELOC=LK071&quot;);', target: '_self',
						subMenu: [
							{title: '참깨', url: 'javascript:goCategoryList(&quot;C001001700070001&quot;);', target: '_self'},
							{title: '고춧가루', url: 'javascript:goCategoryList(&quot;C001001700070002&quot;);', target: '_self'},
							{title: '가공조미료', url: 'javascript:goCategoryList(&quot;C001001700070003&quot;);', target: '_self'},
							{title: '후추/향신료', url: 'javascript:goCategoryList(&quot;C001001700070004&quot;);', target: '_self'},
							{title: '액젓', url: 'javascript:goCategoryList(&quot;C001001700070005&quot;);', target: '_self'},
							{title: '설탕', url: 'javascript:goCategoryList(&quot;C001001700070006&quot;);', target: '_self'},
							{title: '물엿/올리고당', url: 'javascript:goCategoryList(&quot;C001001700070007&quot;);', target: '_self'},
							{title: '소금', url: 'javascript:goCategoryList(&quot;C001001700070008&quot;);', target: '_self'}
						]
					},
					{
						title: '유지류', url: 'javascript:goCategoryList(&quot;C00100170008&SITELOC=LK072&quot;);', target: '_self',
						subMenu: [
							{title: '식용유', url: 'javascript:goCategoryList(&quot;C001001700080001&quot;);', target: '_self'},
							{title: '참기름/들기름', url: 'javascript:goCategoryList(&quot;C001001700080002&quot;);', target: '_self'},
							{title: '올리브유', url: 'javascript:goCategoryList(&quot;C001001700080003&quot;);', target: '_self'},
							{title: '포도씨유', url: 'javascript:goCategoryList(&quot;C001001700080004&quot;);', target: '_self'},
							{title: '카놀라유/기타유', url: 'javascript:goCategoryList(&quot;C001001700080005&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '건강식품/친환경', url: 'javascript:goCategoryList(&quot;C0010018&SITELOC=LK073&quot;);', target: '_self',	
				subMenu: [
					{
						title: '건강/다이어트 식품', url: 'javascript:goCategoryList(&quot;C00100180001&SITELOC=LK074&quot;);', target: '_self',
						subMenu: [
							{title: '홍삼/인삼', url: 'javascript:goCategoryList(&quot;C001001800010001&quot;);', target: '_self'},
							{title: '즙류(포도,석류 등)', url: 'javascript:goCategoryList(&quot;C001001800010002&quot;);', target: '_self'},
							{title: '꿀/조청', url: 'javascript:goCategoryList(&quot;C001001800010003&quot;);', target: '_self'},
							{title: '기타 건강식품', url: 'javascript:goCategoryList(&quot;C001001800010004&quot;);', target: '_self'},
							{title: '건강선물세트', url: 'javascript:goCategoryList(&quot;C001001800010005&quot;);', target: '_self'},
							{title: '다이어트 식품', url: 'javascript:goCategoryList(&quot;C001001800010007&quot;);', target: '_self'},
							{title: '비타민류', url: 'javascript:goCategoryList(&quot;C001001800010008&quot;);', target: '_self'}
						]
					},
					{
						title: '건강식품 브랜드', url: 'javascript:goCategoryList(&quot;C00100180002&SITELOC=LK075&quot;);', target: '_self',
						subMenu: [
							{title: '정관장-뿌리삼', url: 'javascript:goCategoryList(&quot;C001001800020001&quot;);', target: '_self'},
							{title: '정관장-농축액류', url: 'javascript:goCategoryList(&quot;C001001800020002&quot;);', target: '_self'},
							{title: '정관장-우리아이용', url: 'javascript:goCategoryList(&quot;C001001800020003&quot;);', target: '_self'},
							{title: '롯데 헬스원', url: 'javascript:goCategoryList(&quot;C001001800020006&quot;);', target: '_self'},
							{title: '종근당', url: 'javascript:goCategoryList(&quot;C001001800020008&quot;);', target: '_self'},
							{title: '세노비스', url: 'javascript:goCategoryList(&quot;C001001800020009&quot;);', target: '_self'},
							{title: 'CJ 건강', url: 'javascript:goCategoryList(&quot;C001001800020010&quot;);', target: '_self'}
						]
					},
					{
						title: '친환경신선식품', url: 'javascript:goCategoryList(&quot;C00100180003&SITELOC=LK076&quot;);', target: '_self',
						subMenu: [
							{title: '쌀/잡곡', url: 'javascript:goCategoryList(&quot;C001001800030001&quot;);', target: '_self'},
							{title: '과일/견과류', url: 'javascript:goCategoryList(&quot;C001001800030002&quot;);', target: '_self'},
							{title: '채소', url: 'javascript:goCategoryList(&quot;C001001800030003&quot;);', target: '_self'},
							{title: '정육/계란', url: 'javascript:goCategoryList(&quot;C001001800030004&quot;);', target: '_self'}
						]
					},
					{
						title: '친환경가공식품', url: 'javascript:goCategoryList(&quot;C00100180004&SITELOC=LK077&quot;);', target: '_self',
						subMenu: [
							{title: '냉장냉동', url: 'javascript:goCategoryList(&quot;C001001800040001&quot;);', target: '_self'},
							{title: '통조림/쨈', url: 'javascript:goCategoryList(&quot;C001001800040002&quot;);', target: '_self'},
							{title: '커피/차', url: 'javascript:goCategoryList(&quot;C001001800040003&quot;);', target: '_self'},
							{title: '과자', url: 'javascript:goCategoryList(&quot;C001001800040004&quot;);', target: '_self'},
							{title: '면/대용식', url: 'javascript:goCategoryList(&quot;C001001800040006&quot;);', target: '_self'},
							{title: '음료/건강식품', url: 'javascript:goCategoryList(&quot;C001001800040007&quot;);', target: '_self'},
							{title: '장류/소스류', url: 'javascript:goCategoryList(&quot;C001001800040008&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '커피/차/음료', url: 'javascript:goCategoryList(&quot;C0010019&SITELOC=LK078&quot;);', target: '_self',	
				subMenu: [
					{
						title: '커피', url: 'javascript:goCategoryList(&quot;C00100190001&SITELOC=LK079&quot;);', target: '_self',
						subMenu: [
							{title: '일반커피믹스', url: 'javascript:goCategoryList(&quot;C001001900010001&quot;);', target: '_self'},
							{title: '블랙/향커피믹스', url: 'javascript:goCategoryList(&quot;C001001900010002&quot;);', target: '_self'},
							{title: '리필/용기커피', url: 'javascript:goCategoryList(&quot;C001001900010003&quot;);', target: '_self'},
							{title: '아이스커피', url: 'javascript:goCategoryList(&quot;C001001900010004&quot;);', target: '_self'},
							{title: '티백원두커피', url: 'javascript:goCategoryList(&quot;C001001900010005&quot;);', target: '_self'},
							{title: '홀빈원두커피', url: 'javascript:goCategoryList(&quot;C001001900010006&quot;);', target: '_self'},
							{title: '분쇄원두커피', url: 'javascript:goCategoryList(&quot;C001001900010007&quot;);', target: '_self'},
							{title: '캡슐커피', url: 'javascript:goCategoryList(&quot;C001001900010008&quot;);', target: '_self'},
							{title: '커피크림', url: 'javascript:goCategoryList(&quot;C001001900010009&quot;);', target: '_self'},
							{title: '시럽/데코파우더', url: 'javascript:goCategoryList(&quot;C001001900010010&quot;);', target: '_self'}
						]
					},
					{
						title: '차', url: 'javascript:goCategoryList(&quot;C00100190002&SITELOC=LK080&quot;);', target: '_self',
						subMenu: [
							{title: '녹차/냉녹차', url: 'javascript:goCategoryList(&quot;C001001900020002&quot;);', target: '_self'},
							{title: '현미/기타 녹차', url: 'javascript:goCategoryList(&quot;C001001900020003&quot;);', target: '_self'},
							{title: '보리/옥수수차 (식수용 포함)', url: 'javascript:goCategoryList(&quot;C001001900020004&quot;);', target: '_self'},
							{title: '둥글레/메밀/결명/다이어트차', url: 'javascript:goCategoryList(&quot;C001001900020005&quot;);', target: '_self'},
							{title: '허브차/홍차/보이차', url: 'javascript:goCategoryList(&quot;C001001900020006&quot;);', target: '_self'},
							{title: '유자/모과/액상차', url: 'javascript:goCategoryList(&quot;C001001900020007&quot;);', target: '_self'},
							{title: '코코아', url: 'javascript:goCategoryList(&quot;C001001900020008&quot;);', target: '_self'},
							{title: '국산차 (인삼/홍삼/생강..)', url: 'javascript:goCategoryList(&quot;C001001900020010&quot;);', target: '_self'},
							{title: '분말곡물차(율무/땅콩/한방)', url: 'javascript:goCategoryList(&quot;C001001900020009&quot;);', target: '_self'},
							{title: '아이스티', url: 'javascript:goCategoryList(&quot;C001001900020001&quot;);', target: '_self'}
						]
					},
					{
						title: '생수/탄산/이온/차음료/무알콜', url: 'javascript:goCategoryList(&quot;C00100190003&SITELOC=LK081&quot;);', target: '_self',
						subMenu: [
							{title: '600Ml 이하 생수', url: 'javascript:goCategoryList(&quot;C001001900030001&quot;);', target: '_self'},
							{title: '600ML 초과 생수', url: 'javascript:goCategoryList(&quot;C001001900030002&quot;);', target: '_self'},
							{title: '수입생수/탄산수', url: 'javascript:goCategoryList(&quot;C001001900030003&quot;);', target: '_self'},
							{title: '사이다/콜라 외 캔 탄산', url: 'javascript:goCategoryList(&quot;C001001900030004&quot;);', target: '_self'},
							{title: '사이다/콜라 외 Pet 탄산', url: 'javascript:goCategoryList(&quot;C001001900030005&quot;);', target: '_self'},
							{title: '비타민음료', url: 'javascript:goCategoryList(&quot;C001001900030006&quot;);', target: '_self'},
							{title: '이온/에너지음료', url: 'javascript:goCategoryList(&quot;C001001900030007&quot;);', target: '_self'},
							{title: '커피음료', url: 'javascript:goCategoryList(&quot;C001001900030008&quot;);', target: '_self'},
							{title: '냉장 커피음료', url: 'javascript:goCategoryList(&quot;C001001900030009&quot;);', target: '_self'},
							{title: '차음료', url: 'javascript:goCategoryList(&quot;C001001900030010&quot;);', target: '_self'},
							{title: '무알콜 맥주', url: 'javascript:goCategoryList(&quot;C001001900030011&quot;);', target: '_self'}
						]
					},
					{
						title: '과즙음료', url: 'javascript:goCategoryList(&quot;C00100190004&SITELOC=LK082&quot;);', target: '_self',
						subMenu: [
							{title: '오렌지주스', url: 'javascript:goCategoryList(&quot;C001001900040001&quot;);', target: '_self'},
							{title: '포도주스', url: 'javascript:goCategoryList(&quot;C001001900040002&quot;);', target: '_self'},
							{title: '기타/야채주스', url: 'javascript:goCategoryList(&quot;C001001900040003&quot;);', target: '_self'},
							{title: '친환경음료', url: 'javascript:goCategoryList(&quot;C001001900040004&quot;);', target: '_self'},
							{title: '어린이음료', url: 'javascript:goCategoryList(&quot;C001001900040005&quot;);', target: '_self'},
							{title: '전통음료', url: 'javascript:goCategoryList(&quot;C001001900040006&quot;);', target: '_self'},
							{title: '음료 선물세트', url: 'javascript:goCategoryList(&quot;C001001900040007&quot;);', target: '_self'},
							{title: '수입음료', url: 'javascript:goCategoryList(&quot;C001001900040008&quot;);', target: '_self'},
							{title: '냉장 과즙음료', url: 'javascript:goCategoryList(&quot;C001001900040009&quot;);', target: '_self'}
						]
					},
					{
						title: '두유', url: 'javascript:goCategoryList(&quot;C00100190005&SITELOC=LK083&quot;);', target: '_self',
						subMenu: [
							{title: '일반두유', url: 'javascript:goCategoryList(&quot;C001001900050001&quot;);', target: '_self'},
							{title: '기능성/혼합두유', url: 'javascript:goCategoryList(&quot;C001001900050002&quot;);', target: '_self'},
							{title: '영유아두유', url: 'javascript:goCategoryList(&quot;C001001900050003&quot;);', target: '_self'},
							{title: '냉장 두유', url: 'javascript:goCategoryList(&quot;C001001900050004&quot;);', target: '_self'}
						]
					},
					{
						title: '기능성/숙취해소음료', url: 'javascript:goCategoryList(&quot;C00100190006&SITELOC=LK084&quot;);', target: '_self',
						subMenu: [
							{title: '숙취해소 음료', url: 'javascript:goCategoryList(&quot;C001001900060001&quot;);', target: '_self'},
							{title: '드링크제', url: 'javascript:goCategoryList(&quot;C001001900060002&quot;);', target: '_self'},
							{title: '기타 건강기능성 음료', url: 'javascript:goCategoryList(&quot;C001001900060003&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '과자', url: 'javascript:goCategoryList(&quot;C0010020&SITELOC=LK085&quot;);', target: '_self',	
				subMenu: [
					{
						title: '스낵/시리얼', url: 'javascript:goCategoryList(&quot;C00100200001&SITELOC=LK086&quot;);', target: '_self',
						subMenu: [
							{title: '일반스낵', url: 'javascript:goCategoryList(&quot;C001002000010001&quot;);', target: '_self'},
							{title: '감자/고구마스낵', url: 'javascript:goCategoryList(&quot;C001002000010002&quot;);', target: '_self'},
							{title: '쌀과자', url: 'javascript:goCategoryList(&quot;C001002000010003&quot;);', target: '_self'},
							{title: '옥수수스낵', url: 'javascript:goCategoryList(&quot;C001002000010004&quot;);', target: '_self'},
							{title: '팝콘/나초', url: 'javascript:goCategoryList(&quot;C001002000010005&quot;);', target: '_self'},
							{title: '어린이용 시리얼', url: 'javascript:goCategoryList(&quot;C001002000010006&quot;);', target: '_self'},
							{title: '성인/패밀리용 시리얼', url: 'javascript:goCategoryList(&quot;C001002000010007&quot;);', target: '_self'},
							{title: '수입 시리얼', url: 'javascript:goCategoryList(&quot;C001002000010008&quot;);', target: '_self'},
							{title: '안주류', url: 'javascript:goCategoryList(&quot;C001002000010009&quot;);', target: '_self'}
						]
					},
					{
						title: '쿠키/비스킷/파이', url: 'javascript:goCategoryList(&quot;C00100200002&SITELOC=LK087&quot;);', target: '_self',
						subMenu: [
							{title: '하드쿠키', url: 'javascript:goCategoryList(&quot;C001002000020001&quot;);', target: '_self'},
							{title: '소프트쿠키', url: 'javascript:goCategoryList(&quot;C001002000020002&quot;);', target: '_self'},
							{title: '비스킷/크래커', url: 'javascript:goCategoryList(&quot;C001002000020003&quot;);', target: '_self'},
							{title: '샌드', url: 'javascript:goCategoryList(&quot;C001002000020004&quot;);', target: '_self'},
							{title: '웨하스/와플', url: 'javascript:goCategoryList(&quot;C001002000020005&quot;);', target: '_self'},
							{title: '화과자/양갱/전통과자', url: 'javascript:goCategoryList(&quot;C001002000020006&quot;);', target: '_self'},
							{title: '맛밤류', url: 'javascript:goCategoryList(&quot;C001002000020010&quot;);', target: '_self'},
							{title: '초코쿠키/초코과자', url: 'javascript:goCategoryList(&quot;C001002000020007&quot;);', target: '_self'},
							{title: '파이/초코파이', url: 'javascript:goCategoryList(&quot;C001002000020008&quot;);', target: '_self'},
							{title: '카스타드/소프트케익류', url: 'javascript:goCategoryList(&quot;C001002000020009&quot;);', target: '_self'}
						]
					},
					{
						title: '사탕/캬라멜/껌/쨈', url: 'javascript:goCategoryList(&quot;C00100200003&SITELOC=LK088&quot;);', target: '_self',
						subMenu: [
							{title: '하드 캔디', url: 'javascript:goCategoryList(&quot;C001002000030002&quot;);', target: '_self'},
							{title: '스틱/막대 캔디', url: 'javascript:goCategoryList(&quot;C001002000030003&quot;);', target: '_self'},
							{title: '캬라멜', url: 'javascript:goCategoryList(&quot;C001002000030005&quot;);', target: '_self'},
							{title: '젤리', url: 'javascript:goCategoryList(&quot;C001002000030006&quot;);', target: '_self'},
							{title: '껌', url: 'javascript:goCategoryList(&quot;C001002000030007&quot;);', target: '_self'},
							{title: '쨈', url: 'javascript:goCategoryList(&quot;C001002000030008&quot;);', target: '_self'}
						]
					},
					{
						title: '초콜릿/빼빼로', url: 'javascript:goCategoryList(&quot;C00100200004&SITELOC=LK089&quot;);', target: '_self',
						subMenu: [
							{title: '판 초콜릿 (가나 외)', url: 'javascript:goCategoryList(&quot;C001002000040001&quot;);', target: '_self'},
							{title: '쉘 초콜릿 (ABC 외)', url: 'javascript:goCategoryList(&quot;C001002000040002&quot;);', target: '_self'},
							{title: '바 초콜릿 (스니커즈 외)', url: 'javascript:goCategoryList(&quot;C001002000040003&quot;);', target: '_self'},
							{title: '빼빼로/가공초콜릿', url: 'javascript:goCategoryList(&quot;C001002000040004&quot;);', target: '_self'},
							{title: '수입초콜릿/캔디', url: 'javascript:goCategoryList(&quot;C001002000040005&quot;);', target: '_self'}
						]
					},
					{
						title: '떡/빵/베이커리', url: 'javascript:goCategoryList(&quot;C00100200005&SITELOC=LK090&quot;);', target: '_self',
						subMenu: [
							{title: '손큰피자', url: 'javascript:goCategoryList(&quot;C001002000050001&quot;);', target: '_self'},
							{title: '떡류', url: 'javascript:goCategoryList(&quot;C001002000050002&quot;);', target: '_self'},
							{title: '빵/찐빵/호두과자', url: 'javascript:goCategoryList(&quot;C001002000050003&quot;);', target: '_self'},
							{title: '식빵', url: 'javascript:goCategoryList(&quot;C001002000050006&quot;);', target: '_self'},
							{title: '냉동생지/냉동빵', url: 'javascript:goCategoryList(&quot;C001002000050004&quot;);', target: '_self'},
							{title: '선물용 배달 케익', url: 'javascript:goCategoryList(&quot;C001002000050005&quot;);', target: '_self'}
						]
					}
				]
			}
		];
		var lifeData = [
			{
				title: '유아/출산용품', url: 'javascript:goCategoryList(&quot;C0010021&SITELOC=LL001&quot;);', target: '_self',
				subMenu: [
					{
						title: '분유/유아식', url: 'javascript:goCategoryList(&quot;C00100210001&SITELOC=LL002&quot;);', target: '_self',
						subMenu: [
							{title: '남양분유', url: 'javascript:goCategoryList(&quot;C001002100010001&quot;);', target: '_self'},
							{title: '매일분유', url: 'javascript:goCategoryList(&quot;C001002100010002&quot;);', target: '_self'},
							{title: '일동분유', url: 'javascript:goCategoryList(&quot;C001002100010003&quot;);', target: '_self'},
							{title: '파스퇴르분유', url: 'javascript:goCategoryList(&quot;C001002100010004&quot;);', target: '_self'},
							{title: '기타 분유', url: 'javascript:goCategoryList(&quot;C001002100010005&quot;);', target: '_self'},
							{title: '이유식', url: 'javascript:goCategoryList(&quot;C001002100010006&quot;);', target: '_self'},
							{title: '유아간식/음료', url: 'javascript:goCategoryList(&quot;C001002100010007&quot;);', target: '_self'},
							{title: '영유아 두유', url: 'javascript:goCategoryList(&quot;C001002100010008&quot;);', target: '_self'}
						]
					},
					{
						title: '기저귀', url: 'javascript:goCategoryList(&quot;C00100210002&SITELOC=LL003&quot;);', target: '_self',
						subMenu: [
							{title: '하기스', url: 'javascript:goCategoryList(&quot;C001002100020001&quot;);', target: '_self'},
							{title: '보솜이', url: 'javascript:goCategoryList(&quot;C001002100020002&quot;);', target: '_self'},
							{title: '마미포코/토디앙', url: 'javascript:goCategoryList(&quot;C001002100020003&quot;);', target: '_self'},
							{title: '군기저귀', url: 'javascript:goCategoryList(&quot;C001002100020004&quot;);', target: '_self'},
							{title: '수입기저귀', url: 'javascript:goCategoryList(&quot;C001002100020005&quot;);', target: '_self'},
							{title: '일자형기저귀', url: 'javascript:goCategoryList(&quot;C001002100020006&quot;);', target: '_self'},
							{title: '테이프형기저귀', url: 'javascript:goCategoryList(&quot;C001002100020007&quot;);', target: '_self'},
							{title: '팬티형기저귀', url: 'javascript:goCategoryList(&quot;C001002100020008&quot;);', target: '_self'},
							{title: '유아물티슈', url: 'javascript:goCategoryList(&quot;C001002100020009&quot;);', target: '_self'},
							{title: '성인용기저귀', url: 'javascript:goCategoryList(&quot;C001002100020010&quot;);', target: '_self'}
						]
					},
					{
						title: '목욕/세제/스킨케어/안전용품', url: 'javascript:goCategoryList(&quot;C00100210003&SITELOC=LL004&quot;);', target: '_self',
						subMenu: [
							{title: '유아욕조/목욕용품', url: 'javascript:goCategoryList(&quot;C001002100030001&quot;);', target: '_self'},
							{title: '유아비누/샴푸/바스', url: 'javascript:goCategoryList(&quot;C001002100030002&quot;);', target: '_self'},
							{title: '유아로션/크림/밤', url: 'javascript:goCategoryList(&quot;C001002100030003&quot;);', target: '_self'},
							{title: '유아썬크림', url: 'javascript:goCategoryList(&quot;C001002100030004&quot;);', target: '_self'},
							{title: '유아파우더/오일', url: 'javascript:goCategoryList(&quot;C001002100030005&quot;);', target: '_self'},
							{title: '유아세정/세제류', url: 'javascript:goCategoryList(&quot;C001002100030006&quot;);', target: '_self'},
							{title: '유아치약/칫솔', url: 'javascript:goCategoryList(&quot;C001002100030007&quot;);', target: '_self'},
							{title: '유아변기', url: 'javascript:goCategoryList(&quot;C001002100030008&quot;);', target: '_self'},
							{title: '체온계/흡입기', url: 'javascript:goCategoryList(&quot;C001002100030009&quot;);', target: '_self'},
							{title: '의료/소독기/기타위생용품', url: 'javascript:goCategoryList(&quot;C001002100030010&quot;);', target: '_self'}
						]
					},
					{
						title: '수유/이유용품', url: 'javascript:goCategoryList(&quot;C00100210004&SITELOC=LL005&quot;);', target: '_self',
						subMenu: [
							{title: '젓병/젖꼭지', url: 'javascript:goCategoryList(&quot;C001002100040001&quot;);', target: '_self'},
							{title: '치발기/노리개/모빌', url: 'javascript:goCategoryList(&quot;C001002100040002&quot;);', target: '_self'},
							{title: '수유/보조용품', url: 'javascript:goCategoryList(&quot;C001002100040003&quot;);', target: '_self'},
							{title: '유아조리/식기', url: 'javascript:goCategoryList(&quot;C001002100040004&quot;);', target: '_self'},
							{title: '이유식컵/부속품', url: 'javascript:goCategoryList(&quot;C001002100040005&quot;);', target: '_self'},
							{title: '턱받이/기타출산용품', url: 'javascript:goCategoryList(&quot;C001002100040006&quot;);', target: '_self'}
						]
					},
					{
						title: '유모차/카시트/기구', url: 'javascript:goCategoryList(&quot;C00100210005&SITELOC=LL006&quot;);', target: '_self',
						subMenu: [
							{title: '유모차', url: 'javascript:goCategoryList(&quot;C001002100050001&quot;);', target: '_self'},
							{title: '카시트', url: 'javascript:goCategoryList(&quot;C001002100050002&quot;);', target: '_self'},
							{title: '아기띠/캐리어/포데기', url: 'javascript:goCategoryList(&quot;C001002100050003&quot;);', target: '_self'},
							{title: '보행기', url: 'javascript:goCategoryList(&quot;C001002100050004&quot;);', target: '_self'},
							{title: '바운서/침대', url: 'javascript:goCategoryList(&quot;C001002100050005&quot;);', target: '_self'},
							{title: '놀이방매트', url: 'javascript:goCategoryList(&quot;C001002100050006&quot;);', target: '_self'},
							{title: '유아식탁의자', url: 'javascript:goCategoryList(&quot;C001002100050007&quot;);', target: '_self'},
							{title: '유아의자/책상/유아쇼파', url: 'javascript:goCategoryList(&quot;C001002100050008&quot;);', target: '_self'},
							{title: '정리대/정리함', url: 'javascript:goCategoryList(&quot;C001002100050009&quot;);', target: '_self'},
							{title: '모빌/자전거/장난감', url: 'javascript:goCategoryList(&quot;C001002100050010&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '유아동패션/잡화', url: 'javascript:goCategoryList(&quot;C0010022&SITELOC=LL007&quot;);', target: '_self',
				subMenu: [
					{
						title: '유아동의류', url: 'javascript:goCategoryList(&quot;C00100220001&SITELOC=LL008&quot;);', target: '_self',
						subMenu: [
							{title: '유아의류', url: 'javascript:goCategoryList(&quot;C001002200010001&quot;);', target: '_self'},
							{title: '남아동자켓/점퍼', url: 'javascript:goCategoryList(&quot;C001002200010002&quot;);', target: '_self'},
							{title: '남아동티셔츠/후드', url: 'javascript:goCategoryList(&quot;C001002200010011&quot;);', target: '_self'},
							{title: '남아동셔츠', url: 'javascript:goCategoryList(&quot;C001002200010013&quot;);', target: '_self'},
							{title: '남아동바지', url: 'javascript:goCategoryList(&quot;C001002200010003&quot;);', target: '_self'},
							{title: '여아동자켓/점퍼', url: 'javascript:goCategoryList(&quot;C001002200010004&quot;);', target: '_self'},
							{title: '여아동티셔츠/후드', url: 'javascript:goCategoryList(&quot;C001002200010012&quot;);', target: '_self'},
							{title: '여아동셔츠', url: 'javascript:goCategoryList(&quot;C001002200010014&quot;);', target: '_self'},
							{title: '여아동원피스', url: 'javascript:goCategoryList(&quot;C001002200010005&quot;);', target: '_self'},
							{title: '여아동바지/스커트', url: 'javascript:goCategoryList(&quot;C001002200010006&quot;);', target: '_self'},
							{title: '남아동한복', url: 'javascript:goCategoryList(&quot;C001002200010007&quot;);', target: '_self'},
							{title: '여아동한복', url: 'javascript:goCategoryList(&quot;C001002200010008&quot;);', target: '_self'},
							{title: '남아동수영복', url: 'javascript:goCategoryList(&quot;C001002200010009&quot;);', target: '_self'},
							{title: '여아동수영복', url: 'javascript:goCategoryList(&quot;C001002200010010&quot;);', target: '_self'}
						]
					},
					{
						title: '유아동언더웨어/양말', url: 'javascript:goCategoryList(&quot;C00100220002&SITELOC=LL009&quot;);', target: '_self',
						subMenu: [
							{title: '남아동팬티', url: 'javascript:goCategoryList(&quot;C001002200020001&quot;);', target: '_self'},
							{title: '남아동런닝', url: 'javascript:goCategoryList(&quot;C001002200020002&quot;);', target: '_self'},
							{title: '남아동내의', url: 'javascript:goCategoryList(&quot;C001002200020006&quot;);', target: '_self'},
							{title: '여아동팬티', url: 'javascript:goCategoryList(&quot;C001002200020003&quot;);', target: '_self'},
							{title: '여아동런닝', url: 'javascript:goCategoryList(&quot;C001002200020004&quot;);', target: '_self'},
							{title: '여아동내의', url: 'javascript:goCategoryList(&quot;C001002200020007&quot;);', target: '_self'},
							{title: '여아동브라', url: 'javascript:goCategoryList(&quot;C001002200020008&quot;);', target: '_self'},
							{title: '유아동양말', url: 'javascript:goCategoryList(&quot;C001002200020005&quot;);', target: '_self'}
						]
					},
					{
						title: '유아동신발/가방/잡화', url: 'javascript:goCategoryList(&quot;C00100220003&SITELOC=LL0010&quot;);', target: '_self',
						subMenu: [
							{title: '유아신발', url: 'javascript:goCategoryList(&quot;C001002200030001&quot;);', target: '_self'},
							{title: '남아동신발', url: 'javascript:goCategoryList(&quot;C001002200030002&quot;);', target: '_self'},
							{title: '여아동신발', url: 'javascript:goCategoryList(&quot;C001002200030003&quot;);', target: '_self'},
							{title: '아동가방', url: 'javascript:goCategoryList(&quot;C001002200030004&quot;);', target: '_self'},
							{title: '아동모자/장갑', url: 'javascript:goCategoryList(&quot;C001002200030005&quot;);', target: '_self'},
							{title: '아동벨트/기타잡화', url: 'javascript:goCategoryList(&quot;C001002200030006&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '세제/위생', url: 'javascript:goCategoryList(&quot;C0010023&SITELOC=LL011&quot;);', target: '_self',
				subMenu: [
					{
						title: '세탁세제', url: 'javascript:goCategoryList(&quot;C00100230001&SITELOC=LL012&quot;);', target: '_self',
						subMenu: [
							{title: '가루세제-일반', url: 'javascript:goCategoryList(&quot;C001002300010001&quot;);', target: '_self'},
							{title: '가루세제-드럼', url: 'javascript:goCategoryList(&quot;C001002300010002&quot;);', target: '_self'},
							{title: '액체세제-일반', url: 'javascript:goCategoryList(&quot;C001002300010003&quot;);', target: '_self'},
							{title: '액체세제-드럼', url: 'javascript:goCategoryList(&quot;C001002300010004&quot;);', target: '_self'},
							{title: '섬유유연제-일반', url: 'javascript:goCategoryList(&quot;C001002300010005&quot;);', target: '_self'},
							{title: '섬유유연제-드럼', url: 'javascript:goCategoryList(&quot;C001002300010006&quot;);', target: '_self'},
							{title: '울샴푸', url: 'javascript:goCategoryList(&quot;C001002300010007&quot;);', target: '_self'},
							{title: '세탁비누', url: 'javascript:goCategoryList(&quot;C001002300010008&quot;);', target: '_self'},
							{title: '세탁보조제', url: 'javascript:goCategoryList(&quot;C001002300010009&quot;);', target: '_self'},
							{title: '표백제', url: 'javascript:goCategoryList(&quot;C001002300010010&quot;);', target: '_self'},
							{title: '유아용세제', url: 'javascript:goCategoryList(&quot;C001002300010011&quot;);', target: '_self'}
						]
					},
					{
						title: '청소세제', url: 'javascript:goCategoryList(&quot;C00100230002&SITELOC=LL013&quot;);', target: '_self',
						subMenu: [
							{title: '제습제', url: 'javascript:goCategoryList(&quot;C001002300020001&quot;);', target: '_self'},
							{title: '욕실청소세제', url: 'javascript:goCategoryList(&quot;C001002300020002&quot;);', target: '_self'},
							{title: '다용도세정제', url: 'javascript:goCategoryList(&quot;C001002300020007&quot;);', target: '_self'},
							{title: '주방청소세제', url: 'javascript:goCategoryList(&quot;C001002300020003&quot;);', target: '_self'},
							{title: '곰팡이제거제', url: 'javascript:goCategoryList(&quot;C001002300020006&quot;);', target: '_self'},
							{title: '변기세정제', url: 'javascript:goCategoryList(&quot;C001002300020004&quot;);', target: '_self'},
							{title: '락스', url: 'javascript:goCategoryList(&quot;C001002300020005&quot;);', target: '_self'}
						]
					},
					{
						title: '방향/탈취/살충', url: 'javascript:goCategoryList(&quot;C00100230003&SITELOC=LL014&quot;);', target: '_self',
						subMenu: [
							{title: '섬유탈취제', url: 'javascript:goCategoryList(&quot;C001002300030001&quot;);', target: '_self'},
							{title: '주거탈취제', url: 'javascript:goCategoryList(&quot;C001002300030002&quot;);', target: '_self'},
							{title: '공기탈취제', url: 'javascript:goCategoryList(&quot;C001002300030007&quot;);', target: '_self'},
							{title: '방향제', url: 'javascript:goCategoryList(&quot;C001002300030003&quot;);', target: '_self'},
							{title: '방충제', url: 'javascript:goCategoryList(&quot;C001002300030004&quot;);', target: '_self'},
							{title: '파리모기살충제', url: 'javascript:goCategoryList(&quot;C001002300030005&quot;);', target: '_self'},
							{title: '바퀴개미살충제', url: 'javascript:goCategoryList(&quot;C001002300030006&quot;);', target: '_self'}
						]
					},
					{
						title: '주방세제', url: 'javascript:goCategoryList(&quot;C00100230004&SITELOC=LL015&quot;);', target: '_self',
						subMenu: [
							{title: '일반주방세제', url: 'javascript:goCategoryList(&quot;C001002300040001&quot;);', target: '_self'},
							{title: '프리미엄 주방세제', url: 'javascript:goCategoryList(&quot;C001002300040002&quot;);', target: '_self'},
							{title: '식기세척기세제', url: 'javascript:goCategoryList(&quot;C001002300040003&quot;);', target: '_self'}
						]
					},
					{
						title: '화장지', url: 'javascript:goCategoryList(&quot;C00100230005&SITELOC=LL016&quot;);', target: '_self',
						subMenu: [
							{title: '2겹화장지', url: 'javascript:goCategoryList(&quot;C001002300050001&quot;);', target: '_self'},
							{title: '3겹화장지', url: 'javascript:goCategoryList(&quot;C001002300050002&quot;);', target: '_self'},
							{title: '미용티슈', url: 'javascript:goCategoryList(&quot;C001002300050003&quot;);', target: '_self'},
							{title: '여행용티슈', url: 'javascript:goCategoryList(&quot;C001002300050004&quot;);', target: '_self'},
							{title: '키친타올', url: 'javascript:goCategoryList(&quot;C001002300050005&quot;);', target: '_self'},
							{title: '아기물티슈', url: 'javascript:goCategoryList(&quot;C001002300050006&quot;);', target: '_self'},
							{title: '일반물티슈', url: 'javascript:goCategoryList(&quot;C001002300050007&quot;);', target: '_self'}
						]
					},
					{
						title: '생리대', url: 'javascript:goCategoryList(&quot;C00100230006&SITELOC=LL017&quot;);', target: '_self',
						subMenu: [
							{title: '소형', url: 'javascript:goCategoryList(&quot;C001002300060001&quot;);', target: '_self'},
							{title: '중형', url: 'javascript:goCategoryList(&quot;C001002300060002&quot;);', target: '_self'},
							{title: '대형', url: 'javascript:goCategoryList(&quot;C001002300060003&quot;);', target: '_self'},
							{title: '오버나이트', url: 'javascript:goCategoryList(&quot;C001002300060004&quot;);', target: '_self'},
							{title: '팬티라이너', url: 'javascript:goCategoryList(&quot;C001002300060008&quot;);', target: '_self'},
							{title: '생리대기획팩', url: 'javascript:goCategoryList(&quot;C001002300060005&quot;);', target: '_self'},
							{title: '삽입형 생리대', url: 'javascript:goCategoryList(&quot;C001002300060006&quot;);', target: '_self'},
							{title: '성인용기저귀', url: 'javascript:goCategoryList(&quot;C001002300060007&quot;);', target: '_self'}
						]
					},
					{
						title: '구강용품', url: 'javascript:goCategoryList(&quot;C00100230007&SITELOC=LL018&quot;);', target: '_self',
						subMenu: [
							{title: '치약', url: 'javascript:goCategoryList(&quot;C001002300070001&quot;);', target: '_self'},
							{title: '칫솔', url: 'javascript:goCategoryList(&quot;C001002300070002&quot;);', target: '_self'},
							{title: '유아용치약', url: 'javascript:goCategoryList(&quot;C001002300070003&quot;);', target: '_self'},
							{title: '유아용칫솔', url: 'javascript:goCategoryList(&quot;C001002300070004&quot;);', target: '_self'},
							{title: '가글용품', url: 'javascript:goCategoryList(&quot;C001002300070005&quot;);', target: '_self'},
							{title: '치간칫솔', url: 'javascript:goCategoryList(&quot;C001002300070006&quot;);', target: '_self'},
							{title: '여행용세트/기타', url: 'javascript:goCategoryList(&quot;C001002300070007&quot;);', target: '_self'}
						]
					},
					{
						title: '개인위생용품', url: 'javascript:goCategoryList(&quot;C00100230008&SITELOC=LL019&quot;);', target: '_self',
						subMenu: [
							{title: '밴드/마스크/의약외품', url: 'javascript:goCategoryList(&quot;C001002300080001&quot;);', target: '_self'},
							{title: '렌즈관리용품', url: 'javascript:goCategoryList(&quot;C001002300080002&quot;);', target: '_self'},
							{title: '면도기', url: 'javascript:goCategoryList(&quot;C001002300080003&quot;);', target: '_self'},
							{title: '면도용품/젤', url: 'javascript:goCategoryList(&quot;C001002300080004&quot;);', target: '_self'},
							{title: '면도날', url: 'javascript:goCategoryList(&quot;C001002300080005&quot;);', target: '_self'},
							{title: '여성용면도기', url: 'javascript:goCategoryList(&quot;C001002300080006&quot;);', target: '_self'},
							{title: '일회용면도기', url: 'javascript:goCategoryList(&quot;C001002300080007&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '헤어/바디/화장품', url: 'javascript:goCategoryList(&quot;C0010024&SITELOC=LL020&quot;);', target: '_self',
				subMenu: [
					{
						title: '헤어용품/악세서리', url: 'javascript:goCategoryList(&quot;C00100240001&SITELOC=LL021&quot;);', target: '_self',
						subMenu: [
							{title: '샴푸', url: 'javascript:goCategoryList(&quot;C001002400010001&quot;);', target: '_self'},
							{title: '모근강화샴푸', url: 'javascript:goCategoryList(&quot;C001002400010002&quot;);', target: '_self'},
							{title: '린스', url: 'javascript:goCategoryList(&quot;C001002400010003&quot;);', target: '_self'},
							{title: '모근강화린스', url: 'javascript:goCategoryList(&quot;C001002400010004&quot;);', target: '_self'},
							{title: '샴푸린스기획', url: 'javascript:goCategoryList(&quot;C001002400010005&quot;);', target: '_self'},
							{title: '모근강화샴푸기획', url: 'javascript:goCategoryList(&quot;C001002400010006&quot;);', target: '_self'},
							{title: '염색약', url: 'javascript:goCategoryList(&quot;C001002400010007&quot;);', target: '_self'},
							{title: '트리트먼트/헤어팩', url: 'javascript:goCategoryList(&quot;C001002400010008&quot;);', target: '_self'},
							{title: '헤어세럼/에센스', url: 'javascript:goCategoryList(&quot;C001002400010009&quot;);', target: '_self'},
							{title: '헤어스타일링', url: 'javascript:goCategoryList(&quot;C001002400010010&quot;);', target: '_self'},
							{title: '헤어핀/헤어밴드', url: 'javascript:goCategoryList(&quot;C001002400010011&quot;);', target: '_self'},
							{title: '헤어브러쉬/헤어롤', url: 'javascript:goCategoryList(&quot;C001002400010012&quot;);', target: '_self'}
						]
					},
					{
						title: '세안/바디/핸드/풋케어', url: 'javascript:goCategoryList(&quot;C00100240002&SITELOC=LL022&quot;);', target: '_self',
						subMenu: [
							{title: '비누', url: 'javascript:goCategoryList(&quot;C001002400020001&quot;);', target: '_self'},
							{title: '립/아이리무버', url: 'javascript:goCategoryList(&quot;C001002400020010&quot;);', target: '_self'},
							{title: '훼이셜클렌저/크림', url: 'javascript:goCategoryList(&quot;C001002400020002&quot;);', target: '_self'},
							{title: '바디클린져', url: 'javascript:goCategoryList(&quot;C001002400020003&quot;);', target: '_self'},
							{title: '바디로션', url: 'javascript:goCategoryList(&quot;C001002400020004&quot;);', target: '_self'},
							{title: '핸드워시', url: 'javascript:goCategoryList(&quot;C001002400020005&quot;);', target: '_self'},
							{title: '핸드풋크림/케어용품', url: 'javascript:goCategoryList(&quot;C001002400020008&quot;);', target: '_self'},
							{title: '데오드란트', url: 'javascript:goCategoryList(&quot;C001002400020006&quot;);', target: '_self'},
							{title: '제모제', url: 'javascript:goCategoryList(&quot;C001002400020007&quot;);', target: '_self'},
							{title: '바디/태닝오일', url: 'javascript:goCategoryList(&quot;C001002400020009&quot;);', target: '_self'},
							{title: '훼이셜/바디스크럽', url: 'javascript:goCategoryList(&quot;C001002400020011&quot;);', target: '_self'}
						]
					},
					{
						title: '화장품', url: 'javascript:goCategoryList(&quot;C00100240003&SITELOC=LL023&quot;);', target: '_self',
						subMenu: [
							{title: '스킨', url: 'javascript:goCategoryList(&quot;C001002400030001&quot;);', target: '_self'},
							{title: '로션', url: 'javascript:goCategoryList(&quot;C001002400030002&quot;);', target: '_self'},
							{title: '아이크림', url: 'javascript:goCategoryList(&quot;C001002400030003&quot;);', target: '_self'},
							{title: '세럼/엠플/에센스', url: 'javascript:goCategoryList(&quot;C001002400030004&quot;);', target: '_self'},
							{title: '크림', url: 'javascript:goCategoryList(&quot;C001002400030005&quot;);', target: '_self'},
							{title: '선크림/로션', url: 'javascript:goCategoryList(&quot;C001002400030006&quot;);', target: '_self'},
							{title: '마스크/팩/마사지크림', url: 'javascript:goCategoryList(&quot;C001002400030007&quot;);', target: '_self'},
							{title: '미스트', url: 'javascript:goCategoryList(&quot;C001002400030012&quot;);', target: '_self'},
							{title: '립케어', url: 'javascript:goCategoryList(&quot;C001002400030009&quot;);', target: '_self'},
							{title: '훼이셜오일', url: 'javascript:goCategoryList(&quot;C001002400030013&quot;);', target: '_self'},
							{title: '남성화장품', url: 'javascript:goCategoryList(&quot;C001002400030010&quot;);', target: '_self'},
							{title: '화장품세트', url: 'javascript:goCategoryList(&quot;C001002400030011&quot;);', target: '_self'}
						]
					},
					{
						title: '메이크업/화장솜/네일', url: 'javascript:goCategoryList(&quot;C00100240004&SITELOC=LL024&quot;);', target: '_self',
						subMenu: [
							{title: '베이스메이크업', url: 'javascript:goCategoryList(&quot;C001002400040001&quot;);', target: '_self'},
							{title: '색조메이크업', url: 'javascript:goCategoryList(&quot;C001002400040002&quot;);', target: '_self'},
							{title: '화장솜/면봉', url: 'javascript:goCategoryList(&quot;C001002400040003&quot;);', target: '_self'},
							{title: '네일용품', url: 'javascript:goCategoryList(&quot;C001002400040004&quot;);', target: '_self'},
							{title: '화장소품/이미용품', url: 'javascript:goCategoryList(&quot;C001002400040005&quot;);', target: '_self'}
						]
					},
					{
						title: '향수', url: 'javascript:goCategoryList(&quot;C00100240005&SITELOC=LL025&quot;);', target: '_self',
						subMenu: [
							{title: '여성향수', url: 'javascript:goCategoryList(&quot;C001002400050001&quot;);', target: '_self'},
							{title: '남성향수', url: 'javascript:goCategoryList(&quot;C001002400050002&quot;);', target: '_self'}
						]
					},
					{
						title: '브랜드별 화장품', url: 'javascript:goCategoryList(&quot;C00100240006&SITELOC=LL026&quot;);', target: '_self',
						subMenu: [
							{title: '과일나라', url: 'javascript:goCategoryList(&quot;C001002400060001&quot;);', target: '_self'},
							{title: '가스비', url: 'javascript:goCategoryList(&quot;C001002400060002&quot;);', target: '_self'},
							{title: '더마이', url: 'javascript:goCategoryList(&quot;C001002400060003&quot;);', target: '_self'},
							{title: '더페이스샵', url: 'javascript:goCategoryList(&quot;C001002400060027&quot;);', target: '_self'},
							{title: '라끄베르', url: 'javascript:goCategoryList(&quot;C001002400060004&quot;);', target: '_self'},
							{title: '라네즈', url: 'javascript:goCategoryList(&quot;C001002400060005&quot;);', target: '_self'},
							{title: '로레알', url: 'javascript:goCategoryList(&quot;C001002400060006&quot;);', target: '_self'},
							{title: '로베아', url: 'javascript:goCategoryList(&quot;C001002400060007&quot;);', target: '_self'},
							{title: '리스킨', url: 'javascript:goCategoryList(&quot;C001002400060008&quot;);', target: '_self'},
							{title: '마몽드', url: 'javascript:goCategoryList(&quot;C001002400060009&quot;);', target: '_self'},
							{title: '보닌', url: 'javascript:goCategoryList(&quot;C001002400060010&quot;);', target: '_self'},
							{title: '비오템', url: 'javascript:goCategoryList(&quot;C001002400060011&quot;);', target: '_self'},
							{title: '빅토리아 스웨덴', url: 'javascript:goCategoryList(&quot;C001002400060012&quot;);', target: '_self'},
							{title: '수려한', url: 'javascript:goCategoryList(&quot;C001002400060013&quot;);', target: '_self'},
							{title: '스킨푸드', url: 'javascript:goCategoryList(&quot;C001002400060014&quot;);', target: '_self'},
							{title: '아이오페', url: 'javascript:goCategoryList(&quot;C001002400060015&quot;);', target: '_self'},
							{title: '엘리자베스아덴', url: 'javascript:goCategoryList(&quot;C001002400060016&quot;);', target: '_self'},
							{title: '오딧세이/미래파', url: 'javascript:goCategoryList(&quot;C001002400060017&quot;);', target: '_self'},
							{title: '오르비스', url: 'javascript:goCategoryList(&quot;C001002400060018&quot;);', target: '_self'},
							{title: '오이보스', url: 'javascript:goCategoryList(&quot;C001002400060019&quot;);', target: '_self'},
							{title: '올레이', url: 'javascript:goCategoryList(&quot;C001002400060020&quot;);', target: '_self'},
							{title: '이자녹스', url: 'javascript:goCategoryList(&quot;C001002400060021&quot;);', target: '_self'},
							{title: '지아자', url: 'javascript:goCategoryList(&quot;C001002400060022&quot;);', target: '_self'},
							{title: '치크룸', url: 'javascript:goCategoryList(&quot;C001002400060023&quot;);', target: '_self'},
							{title: '한율', url: 'javascript:goCategoryList(&quot;C001002400060024&quot;);', target: '_self'},
							{title: '해피바스', url: 'javascript:goCategoryList(&quot;C001002400060025&quot;);', target: '_self'},
							{title: '기타브랜드', url: 'javascript:goCategoryList(&quot;C001002400060026&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '홈인테리어', url: 'javascript:goCategoryList(&quot;C0010025&SITELOC=LL027&quot;);', target: '_self',
				subMenu: [
					{
						title: '문풍지', url: 'javascript:goCategoryList(&quot;C00100250009&SITELOC=LL159&quot;);', target: '_self',
						subMenu: [
							{title: '문풍지', url: 'javascript:goCategoryList(&quot;C001002500090001&quot;);', target: '_self'}
						]
					},
					{
						title: '가구', url: 'javascript:goCategoryList(&quot;C00100250001&SITELOC=LL028&quot;);', target: '_self',
						subMenu: [
							{title: '침실가구', url: 'javascript:goCategoryList(&quot;C001002500010001&quot;);', target: '_self'},
							{title: '거실장/TV장', url: 'javascript:goCategoryList(&quot;C001002500010002&quot;);', target: '_self'},
							{title: '소파', url: 'javascript:goCategoryList(&quot;C001002500010003&quot;);', target: '_self'},
							{title: '식탁', url: 'javascript:goCategoryList(&quot;C001002500010004&quot;);', target: '_self'},
							{title: '주방수납장/렌지대', url: 'javascript:goCategoryList(&quot;C001002500010005&quot;);', target: '_self'},
							{title: '다용도상/교자상', url: 'javascript:goCategoryList(&quot;C001002500010006&quot;);', target: '_self'},
							{title: '다용도테이블', url: 'javascript:goCategoryList(&quot;C001002500010011&quot;);', target: '_self'},
							{title: '수납가구', url: 'javascript:goCategoryList(&quot;C001002500010007&quot;);', target: '_self'},
							{title: '책상', url: 'javascript:goCategoryList(&quot;C001002500010008&quot;);', target: '_self'},
							{title: '책장', url: 'javascript:goCategoryList(&quot;C001002500010010&quot;);', target: '_self'},
							{title: '의자', url: 'javascript:goCategoryList(&quot;C001002500010009&quot;);', target: '_self'}
						]
					},
					{
						title: '침구/커튼', url: 'javascript:goCategoryList(&quot;C00100250002&SITELOC=LL029&quot;);', target: '_self',
						subMenu: [
							{title: '침대커버세트', url: 'javascript:goCategoryList(&quot;C001002500020001&quot;);', target: '_self'},
							{title: '요/매트', url: 'javascript:goCategoryList(&quot;C001002500020002&quot;);', target: '_self'},
							{title: '차렵이불', url: 'javascript:goCategoryList(&quot;C001002500020003&quot;);', target: '_self'},
							{title: '유아동침구', url: 'javascript:goCategoryList(&quot;C001002500020012&quot;);', target: '_self'},
							{title: '베개', url: 'javascript:goCategoryList(&quot;C001002500020004&quot;);', target: '_self'},
							{title: '쿠션', url: 'javascript:goCategoryList(&quot;C001002500020005&quot;);', target: '_self'},
							{title: '패드', url: 'javascript:goCategoryList(&quot;C001002500020006&quot;);', target: '_self'},
							{title: '이불솜/속통', url: 'javascript:goCategoryList(&quot;C001002500020011&quot;);', target: '_self'},
							{title: '거실화/주거소품', url: 'javascript:goCategoryList(&quot;C001002500020007&quot;);', target: '_self'},
							{title: '커튼', url: 'javascript:goCategoryList(&quot;C001002500020008&quot;);', target: '_self'},
							{title: '커튼악세사리', url: 'javascript:goCategoryList(&quot;C001002500020009&quot;);', target: '_self'},
							{title: '시즌상품', url: 'javascript:goCategoryList(&quot;C001002500020010&quot;);', target: '_self'}
						]
					},
					{
						title: '수납용품', url: 'javascript:goCategoryList(&quot;C00100250003&SITELOC=LL030&quot;);', target: '_self',
						subMenu: [
							{title: '메탈랙', url: 'javascript:goCategoryList(&quot;C001002500030001&quot;);', target: '_self'},
							{title: '고정식행거', url: 'javascript:goCategoryList(&quot;C001002500030002&quot;);', target: '_self'},
							{title: '이동식행거', url: 'javascript:goCategoryList(&quot;C001002500030003&quot;);', target: '_self'},
							{title: '바구니', url: 'javascript:goCategoryList(&quot;C001002500030004&quot;);', target: '_self'},
							{title: '리빙박스', url: 'javascript:goCategoryList(&quot;C001002500030005&quot;);', target: '_self'},
							{title: '종이수납함', url: 'javascript:goCategoryList(&quot;C001002500030006&quot;);', target: '_self'},
							{title: '공간박스/수납소품', url: 'javascript:goCategoryList(&quot;C001002500030007&quot;);', target: '_self'},
							{title: '플라스틱 서랍장', url: 'javascript:goCategoryList(&quot;C001002500030008&quot;);', target: '_self'},
							{title: '압축팩/커버', url: 'javascript:goCategoryList(&quot;C001002500030009&quot;);', target: '_self'}
						]
					},
					{
						title: '인테리어소품', url: 'javascript:goCategoryList(&quot;C00100250004&SITELOC=LL031&quot;);', target: '_self',
						subMenu: [
							{title: '벽시계', url: 'javascript:goCategoryList(&quot;C001002500040001&quot;);', target: '_self'},
							{title: '탁상시계', url: 'javascript:goCategoryList(&quot;C001002500040002&quot;);', target: '_self'},
							{title: '액자', url: 'javascript:goCategoryList(&quot;C001002500040003&quot;);', target: '_self'},
							{title: '거울', url: 'javascript:goCategoryList(&quot;C001002500040004&quot;);', target: '_self'},
							{title: '일반시트지', url: 'javascript:goCategoryList(&quot;C001002500040005&quot;);', target: '_self'},
							{title: '데코시트지', url: 'javascript:goCategoryList(&quot;C001002500040006&quot;);', target: '_self'},
							{title: '페브릭', url: 'javascript:goCategoryList(&quot;C001002500040007&quot;);', target: '_self'},
							{title: '기타소품', url: 'javascript:goCategoryList(&quot;C001002500040008&quot;);', target: '_self'}
						]
					},
					{
						title: 'DIY/보수용품', url: 'javascript:goCategoryList(&quot;C00100250005&SITELOC=LL032&quot;);', target: '_self',
						subMenu: [
							{title: '페인트', url: 'javascript:goCategoryList(&quot;C001002500050001&quot;);', target: '_self'},
							{title: '안전용품', url: 'javascript:goCategoryList(&quot;C001002500050002&quot;);', target: '_self'},
							{title: '멀티탭(2~3구)', url: 'javascript:goCategoryList(&quot;C001002500050003&quot;);', target: '_self'},
							{title: '멀티탭(4~6구)', url: 'javascript:goCategoryList(&quot;C001002500050004&quot;);', target: '_self'},
							{title: '스위치/콘센트', url: 'javascript:goCategoryList(&quot;C001002500050005&quot;);', target: '_self'},
							{title: '전기선', url: 'javascript:goCategoryList(&quot;C001002500050006&quot;);', target: '_self'},
							{title: '기타보수용품', url: 'javascript:goCategoryList(&quot;C001002500050007&quot;);', target: '_self'},
							{title: '후크류', url: 'javascript:goCategoryList(&quot;C001002500050012&quot;);', target: '_self'},
							{title: '접착제', url: 'javascript:goCategoryList(&quot;C001002500050008&quot;);', target: '_self'},
							{title: '일반공구', url: 'javascript:goCategoryList(&quot;C001002500050009&quot;);', target: '_self'},
							{title: '전동공구', url: 'javascript:goCategoryList(&quot;C001002500050010&quot;);', target: '_self'},
							{title: '자물쇠/철물', url: 'javascript:goCategoryList(&quot;C001002500050011&quot;);', target: '_self'}
						]
					},
					{
						title: '건전지/조명/전구', url: 'javascript:goCategoryList(&quot;C00100250006&SITELOC=LL033&quot;);', target: '_self',
						subMenu: [
							{title: 'AA건전지', url: 'javascript:goCategoryList(&quot;C001002500060001&quot;);', target: '_self'},
							{title: 'AAA건전지', url: 'javascript:goCategoryList(&quot;C001002500060002&quot;);', target: '_self'},
							{title: '충전지/특수건전지', url: 'javascript:goCategoryList(&quot;C001002500060003&quot;);', target: '_self'},
							{title: '인버터스탠드', url: 'javascript:goCategoryList(&quot;C001002500060004&quot;);', target: '_self'},
							{title: '장식스탠드', url: 'javascript:goCategoryList(&quot;C001002500060005&quot;);', target: '_self'},
							{title: '등기구', url: 'javascript:goCategoryList(&quot;C001002500060006&quot;);', target: '_self'},
							{title: '형광등', url: 'javascript:goCategoryList(&quot;C001002500060007&quot;);', target: '_self'},
							{title: '컴팩트 전구', url: 'javascript:goCategoryList(&quot;C001002500060008&quot;);', target: '_self'},
							{title: '취침등', url: 'javascript:goCategoryList(&quot;C001002500060009&quot;);', target: '_self'},
							{title: '후레쉬/랜턴', url: 'javascript:goCategoryList(&quot;C001002500060010&quot;);', target: '_self'}
						]
					},
					{
						title: '원예/꽃배달', url: 'javascript:goCategoryList(&quot;C00100250007&SITELOC=LL034&quot;);', target: '_self',
						subMenu: [
							{title: '꽃배달', url: 'javascript:goCategoryList(&quot;C001002500070001&quot;);', target: '_self'},
							{title: '화분', url: 'javascript:goCategoryList(&quot;C001002500070002&quot;);', target: '_self'},
							{title: '화분받침', url: 'javascript:goCategoryList(&quot;C001002500070003&quot;);', target: '_self'},
							{title: '원예공구', url: 'javascript:goCategoryList(&quot;C001002500070004&quot;);', target: '_self'},
							{title: '원예소품', url: 'javascript:goCategoryList(&quot;C001002500070005&quot;);', target: '_self'},
							{title: '영양제', url: 'javascript:goCategoryList(&quot;C001002500070006&quot;);', target: '_self'},
							{title: '조화', url: 'javascript:goCategoryList(&quot;C001002500070007&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '주방/청소용품', url: 'javascript:goCategoryList(&quot;C0010026&SITELOC=LL035&quot;);', target: '_self',
				subMenu: [
					{
						title: '그릇/수저', url: 'javascript:goCategoryList(&quot;C00100260001&SITELOC=LL036&quot;);', target: '_self',
						subMenu: [
							{title: '수저/수저통', url: 'javascript:goCategoryList(&quot;C001002600010001&quot;);', target: '_self'},
							{title: '아동용수저', url: 'javascript:goCategoryList(&quot;C001002600010002&quot;);', target: '_self'},
							{title: '티스푼/포크/나이프', url: 'javascript:goCategoryList(&quot;C001002600010003&quot;);', target: '_self'},
							{title: '공기', url: 'javascript:goCategoryList(&quot;C001002600010004&quot;);', target: '_self'},
							{title: '대접/면기', url: 'javascript:goCategoryList(&quot;C001002600010005&quot;);', target: '_self'},
							{title: '접시', url: 'javascript:goCategoryList(&quot;C001002600010006&quot;);', target: '_self'},
							{title: '볼/종지', url: 'javascript:goCategoryList(&quot;C001002600010007&quot;);', target: '_self'},
							{title: '찬기', url: 'javascript:goCategoryList(&quot;C001002600010008&quot;);', target: '_self'},
							{title: '브랜드도자기', url: 'javascript:goCategoryList(&quot;C001002600010009&quot;);', target: '_self'},
							{title: '유아식기', url: 'javascript:goCategoryList(&quot;C001002600010010&quot;);', target: '_self'}
						]
					},
					{
						title: '컵/용품', url: 'javascript:goCategoryList(&quot;C00100260002&SITELOC=LL037&quot;);', target: '_self',
						subMenu: [
							{title: '커피잔', url: 'javascript:goCategoryList(&quot;C001002600020001&quot;);', target: '_self'},
							{title: '여과지/드리퍼/포트', url: 'javascript:goCategoryList(&quot;C001002600020002&quot;);', target: '_self'},
							{title: '유리잔', url: 'javascript:goCategoryList(&quot;C001002600020003&quot;);', target: '_self'},
							{title: '머그잔', url: 'javascript:goCategoryList(&quot;C001002600020004&quot;);', target: '_self'},
							{title: '와인잔', url: 'javascript:goCategoryList(&quot;C001002600020005&quot;);', target: '_self'},
							{title: '와인스크류/오프너', url: 'javascript:goCategoryList(&quot;C001002600020006&quot;);', target: '_self'},
							{title: '아동용컵', url: 'javascript:goCategoryList(&quot;C001002600020007&quot;);', target: '_self'}
						]
					},
					{
						title: '조리기구', url: 'javascript:goCategoryList(&quot;C00100260003&SITELOC=LL038&quot;);', target: '_self',
						subMenu: [
							{title: '후라이팬(미니~24cm)', url: 'javascript:goCategoryList(&quot;C001002600030001&quot;);', target: '_self'},
							{title: '후라이팬(26~32cm)', url: 'javascript:goCategoryList(&quot;C001002600030002&quot;);', target: '_self'},
							{title: '구이팬/궁중팬/양면팬', url: 'javascript:goCategoryList(&quot;C001002600030003&quot;);', target: '_self'},
							{title: '편수냄비', url: 'javascript:goCategoryList(&quot;C001002600030004&quot;);', target: '_self'},
							{title: '양수냄비', url: 'javascript:goCategoryList(&quot;C001002600030005&quot;);', target: '_self'},
							{title: '전골냄비', url: 'javascript:goCategoryList(&quot;C001002600030006&quot;);', target: '_self'},
							{title: '뚝배기', url: 'javascript:goCategoryList(&quot;C001002600030007&quot;);', target: '_self'},
							{title: '압력솥', url: 'javascript:goCategoryList(&quot;C001002600030008&quot;);', target: '_self'},
							{title: '곰솥/들통', url: 'javascript:goCategoryList(&quot;C001002600030009&quot;);', target: '_self'},
							{title: '주전자', url: 'javascript:goCategoryList(&quot;C001002600030010&quot;);', target: '_self'}
						]
					},
					{
						title: '조리도구', url: 'javascript:goCategoryList(&quot;C00100260004&SITELOC=LL039&quot;);', target: '_self',
						subMenu: [
							{title: '국자', url: 'javascript:goCategoryList(&quot;C001002600040001&quot;);', target: '_self'},
							{title: '뒤지개', url: 'javascript:goCategoryList(&quot;C001002600040002&quot;);', target: '_self'},
							{title: '요리스푼/집게/기타', url: 'javascript:goCategoryList(&quot;C001002600040003&quot;);', target: '_self'},
							{title: '믹싱볼/양푼', url: 'javascript:goCategoryList(&quot;C001002600040004&quot;);', target: '_self'},
							{title: '주방가위', url: 'javascript:goCategoryList(&quot;C001002600040005&quot;);', target: '_self'},
							{title: '식/과도', url: 'javascript:goCategoryList(&quot;C001002600040006&quot;);', target: '_self'},
							{title: '채칼/감자칼', url: 'javascript:goCategoryList(&quot;C001002600040007&quot;);', target: '_self'},
							{title: '도마', url: 'javascript:goCategoryList(&quot;C001002600040008&quot;);', target: '_self'},
							{title: '목기', url: 'javascript:goCategoryList(&quot;C001002600040009&quot;);', target: '_self'},
							{title: '제빵용품', url: 'javascript:goCategoryList(&quot;C001002600040010&quot;);', target: '_self'},
							{title: '쟁반', url: 'javascript:goCategoryList(&quot;C001002600040011&quot;);', target: '_self'},
							{title: '채반/바구니', url: 'javascript:goCategoryList(&quot;C001002600040012&quot;);', target: '_self'}
						]
					},
					{
						title: '밀폐/보관용기', url: 'javascript:goCategoryList(&quot;C00100260005&SITELOC=LL040&quot;);', target: '_self',
						subMenu: [
							{title: '락앤락', url: 'javascript:goCategoryList(&quot;C001002600050001&quot;);', target: '_self'},
							{title: '글라스락', url: 'javascript:goCategoryList(&quot;C001002600050002&quot;);', target: '_self'},
							{title: '지퍼락', url: 'javascript:goCategoryList(&quot;C001002600050003&quot;);', target: '_self'},
							{title: '밀폐용기', url: 'javascript:goCategoryList(&quot;C001002600050004&quot;);', target: '_self'},
							{title: '양념통/소스병', url: 'javascript:goCategoryList(&quot;C001002600050005&quot;);', target: '_self'},
							{title: '저장용기', url: 'javascript:goCategoryList(&quot;C001002600050010&quot;);', target: '_self'},
							{title: '물병', url: 'javascript:goCategoryList(&quot;C001002600050006&quot;);', target: '_self'},
							{title: '아동물병', url: 'javascript:goCategoryList(&quot;C001002600050008&quot;);', target: '_self'},
							{title: '도시락/찬합', url: 'javascript:goCategoryList(&quot;C001002600050007&quot;);', target: '_self'},
							{title: '보온/보냉병', url: 'javascript:goCategoryList(&quot;C001002600050009&quot;);', target: '_self'}
						]
					},
					{
						title: '주방정리용품', url: 'javascript:goCategoryList(&quot;C00100260006&SITELOC=LL041&quot;);', target: '_self',
						subMenu: [
							{title: '주방선반', url: 'javascript:goCategoryList(&quot;C001002600060001&quot;);', target: '_self'},
							{title: '씽크대소품', url: 'javascript:goCategoryList(&quot;C001002600060002&quot;);', target: '_self'},
							{title: '식탁매트', url: 'javascript:goCategoryList(&quot;C001002600060003&quot;);', target: '_self'},
							{title: '수세미', url: 'javascript:goCategoryList(&quot;C001002600060004&quot;);', target: '_self'},
							{title: '행주', url: 'javascript:goCategoryList(&quot;C001002600060005&quot;);', target: '_self'},
							{title: '고무장갑', url: 'javascript:goCategoryList(&quot;C001002600060006&quot;);', target: '_self'},
							{title: '씽크매트/다용도매트', url: 'javascript:goCategoryList(&quot;C001002600060007&quot;);', target: '_self'}
						]
					},
					{
						title: '일회용품/소모품', url: 'javascript:goCategoryList(&quot;C00100260007&SITELOC=LL042&quot;);', target: '_self',
						subMenu: [
							{title: '호일', url: 'javascript:goCategoryList(&quot;C001002600070001&quot;);', target: '_self'},
							{title: '랩', url: 'javascript:goCategoryList(&quot;C001002600070002&quot;);', target: '_self'},
							{title: '지퍼백', url: 'javascript:goCategoryList(&quot;C001002600070003&quot;);', target: '_self'},
							{title: '비닐백', url: 'javascript:goCategoryList(&quot;C001002600070004&quot;);', target: '_self'},
							{title: '비닐장갑', url: 'javascript:goCategoryList(&quot;C001002600070005&quot;);', target: '_self'},
							{title: '종이컵', url: 'javascript:goCategoryList(&quot;C001002600070006&quot;);', target: '_self'},
							{title: '일회용품', url: 'javascript:goCategoryList(&quot;C001002600070007&quot;);', target: '_self'},
							{title: '일회용젓가락/수저', url: 'javascript:goCategoryList(&quot;C001002600070008&quot;);', target: '_self'},
							{title: '기타잡화', url: 'javascript:goCategoryList(&quot;C001002600070009&quot;);', target: '_self'},
							{title: '계절/나들이용품', url: 'javascript:goCategoryList(&quot;C001002600070010&quot;);', target: '_self'}
						]
					},
					{
						title: '청소용품', url: 'javascript:goCategoryList(&quot;C00100260008&SITELOC=LL043&quot;);', target: '_self',
						subMenu: [
							{title: '휴지통', url: 'javascript:goCategoryList(&quot;C001002600080001&quot;);', target: '_self'},
							{title: '밀대청소기', url: 'javascript:goCategoryList(&quot;C001002600080002&quot;);', target: '_self'},
							{title: '걸레/청소포', url: 'javascript:goCategoryList(&quot;C001002600080003&quot;);', target: '_self'},
							{title: '청소용솔/브러쉬', url: 'javascript:goCategoryList(&quot;C001002600080004&quot;);', target: '_self'},
							{title: '테이프크리너', url: 'javascript:goCategoryList(&quot;C001002600080005&quot;);', target: '_self'},
							{title: '종량제봉투', url: 'javascript:goCategoryList(&quot;C001002600080006&quot;);', target: '_self'},
							{title: '기타청소용품', url: 'javascript:goCategoryList(&quot;C001002600080007&quot;);', target: '_self'}
						]
					},
					{
						title: '세탁용품', url: 'javascript:goCategoryList(&quot;C00100260009&SITELOC=LL044&quot;);', target: '_self',
						subMenu: [
							{title: '세탁건조대', url: 'javascript:goCategoryList(&quot;C001002600090001&quot;);', target: '_self'},
							{title: '옷걸이', url: 'javascript:goCategoryList(&quot;C001002600090002&quot;);', target: '_self'},
							{title: '다리미판', url: 'javascript:goCategoryList(&quot;C001002600090003&quot;);', target: '_self'},
							{title: '세탁바구니', url: 'javascript:goCategoryList(&quot;C001002600090004&quot;);', target: '_self'},
							{title: '세탁망', url: 'javascript:goCategoryList(&quot;C001002600090005&quot;);', target: '_self'},
							{title: '빨래판/빨래집게', url: 'javascript:goCategoryList(&quot;C001002600090006&quot;);', target: '_self'}
						]
					},
					{
						title: '욕실용품', url: 'javascript:goCategoryList(&quot;C00100260010&SITELOC=LL045&quot;);', target: '_self',
						subMenu: [
							{title: '타월', url: 'javascript:goCategoryList(&quot;C001002600100001&quot;);', target: '_self'},
							{title: '샤워타월', url: 'javascript:goCategoryList(&quot;C001002600100012&quot;);', target: '_self'},
							{title: '매트', url: 'javascript:goCategoryList(&quot;C001002600100002&quot;);', target: '_self'},
							{title: '욕실장/선반', url: 'javascript:goCategoryList(&quot;C001002600100003&quot;);', target: '_self'},
							{title: '변기커버', url: 'javascript:goCategoryList(&quot;C001002600100004&quot;);', target: '_self'},
							{title: '욕실화', url: 'javascript:goCategoryList(&quot;C001002600100005&quot;);', target: '_self'},
							{title: '발판', url: 'javascript:goCategoryList(&quot;C001002600100006&quot;);', target: '_self'},
							{title: '휴지걸이/흡착용품', url: 'javascript:goCategoryList(&quot;C001002600100007&quot;);', target: '_self'},
							{title: '수도용품', url: 'javascript:goCategoryList(&quot;C001002600100008&quot;);', target: '_self'},
							{title: '대야/바가지', url: 'javascript:goCategoryList(&quot;C001002600100009&quot;);', target: '_self'},
							{title: '양치컵/비누받침', url: 'javascript:goCategoryList(&quot;C001002600100010&quot;);', target: '_self'},
							{title: '샤워커튼', url: 'javascript:goCategoryList(&quot;C001002600100011&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '문구/사무/자동차', url: 'javascript:goCategoryList(&quot;C0010027&SITELOC=LL046&quot;);', target: '_self',
				subMenu: [
					{
						title: '미술용품', url: 'javascript:goCategoryList(&quot;C00100270001&SITELOC=LL047&quot;);', target: '_self',
						subMenu: [
							{title: '스케치북', url: 'javascript:goCategoryList(&quot;C001002700010001&quot;);', target: '_self'},
							{title: '색종이', url: 'javascript:goCategoryList(&quot;C001002700010002&quot;);', target: '_self'},
							{title: '미술도구류', url: 'javascript:goCategoryList(&quot;C001002700010003&quot;);', target: '_self'},
							{title: '미술재료류', url: 'javascript:goCategoryList(&quot;C001002700010004&quot;);', target: '_self'},
							{title: '물감/포스터칼라', url: 'javascript:goCategoryList(&quot;C001002700010005&quot;);', target: '_self'},
							{title: '크레파스', url: 'javascript:goCategoryList(&quot;C001002700010006&quot;);', target: '_self'},
							{title: '색연필', url: 'javascript:goCategoryList(&quot;C001002700010007&quot;);', target: '_self'},
							{title: '싸인펜', url: 'javascript:goCategoryList(&quot;C001002700010008&quot;);', target: '_self'},
							{title: '점토찰흙', url: 'javascript:goCategoryList(&quot;C001002700010009&quot;);', target: '_self'},
							{title: '서예도구', url: 'javascript:goCategoryList(&quot;C001002700010010&quot;);', target: '_self'},
							{title: '기타교보재', url: 'javascript:goCategoryList(&quot;C001002700010011&quot;);', target: '_self'}
						]
					},
					{
						title: '악기', url: 'javascript:goCategoryList(&quot;C00100270002&SITELOC=LL048&quot;);', target: '_self',
						subMenu: [
							{title: '건반악기', url: 'javascript:goCategoryList(&quot;C001002700020001&quot;);', target: '_self'},
							{title: '관악기', url: 'javascript:goCategoryList(&quot;C001002700020002&quot;);', target: '_self'},
							{title: '현악기', url: 'javascript:goCategoryList(&quot;C001002700020003&quot;);', target: '_self'},
							{title: '교재용악기', url: 'javascript:goCategoryList(&quot;C001002700020004&quot;);', target: '_self'},
							{title: '악기용교보재', url: 'javascript:goCategoryList(&quot;C001002700020005&quot;);', target: '_self'},
							{title: '멜로디혼/실로폰', url: 'javascript:goCategoryList(&quot;C001002700020006&quot;);', target: '_self'},
							{title: '리듬세트/리코오더', url: 'javascript:goCategoryList(&quot;C001002700020007&quot;);', target: '_self'},
							{title: '기타', url: 'javascript:goCategoryList(&quot;C001002700020008&quot;);', target: '_self'}
						]
					},
					{
						title: '노트', url: 'javascript:goCategoryList(&quot;C00100270003&SITELOC=LL049&quot;);', target: '_self',
						subMenu: [
							{title: '초등노트', url: 'javascript:goCategoryList(&quot;C001002700030001&quot;);', target: '_self'},
							{title: '중고노트', url: 'javascript:goCategoryList(&quot;C001002700030002&quot;);', target: '_self'},
							{title: '스프링/인덱스노트', url: 'javascript:goCategoryList(&quot;C001002700030003&quot;);', target: '_self'},
							{title: '기타일반노트', url: 'javascript:goCategoryList(&quot;C001002700030004&quot;);', target: '_self'},
							{title: '수첩/메모', url: 'javascript:goCategoryList(&quot;C001002700030005&quot;);', target: '_self'}
						]
					},
					{
						title: '필기도구', url: 'javascript:goCategoryList(&quot;C00100270004&SITELOC=LL050&quot;);', target: '_self',
						subMenu: [
							{title: '연필', url: 'javascript:goCategoryList(&quot;C001002700040001&quot;);', target: '_self'},
							{title: '볼펜/사인펜', url: 'javascript:goCategoryList(&quot;C001002700040002&quot;);', target: '_self'},
							{title: '유성매직/보드마카', url: 'javascript:goCategoryList(&quot;C001002700040003&quot;);', target: '_self'},
							{title: '필통', url: 'javascript:goCategoryList(&quot;C001002700040004&quot;);', target: '_self'},
							{title: '연필깎이', url: 'javascript:goCategoryList(&quot;C001002700040005&quot;);', target: '_self'},
							{title: '샤프/샤프심', url: 'javascript:goCategoryList(&quot;C001002700040006&quot;);', target: '_self'},
							{title: '지우개/수정액', url: 'javascript:goCategoryList(&quot;C001002700040007&quot;);', target: '_self'}
						]
					},
					{
						title: '사무용품', url: 'javascript:goCategoryList(&quot;C00100270005&SITELOC=LL051&quot;);', target: '_self',
						subMenu: [
							{title: '물풀/고체풀', url: 'javascript:goCategoryList(&quot;C001002700050001&quot;);', target: '_self'},
							{title: '접착제/테이프', url: 'javascript:goCategoryList(&quot;C001002700050002&quot;);', target: '_self'},
							{title: '견출지/포스트잇', url: 'javascript:goCategoryList(&quot;C001002700050003&quot;);', target: '_self'},
							{title: '보드/게시판', url: 'javascript:goCategoryList(&quot;C001002700050004&quot;);', target: '_self'},
							{title: '서식지/봉투', url: 'javascript:goCategoryList(&quot;C001002700050005&quot;);', target: '_self'},
							{title: '복사지/라벨지', url: 'javascript:goCategoryList(&quot;C001002700050006&quot;);', target: '_self'},
							{title: '펀치/스템플러', url: 'javascript:goCategoryList(&quot;C001002700050007&quot;);', target: '_self'},
							{title: '칼/가위', url: 'javascript:goCategoryList(&quot;C001002700050008&quot;);', target: '_self'},
							{title: '계산기', url: 'javascript:goCategoryList(&quot;C001002700050009&quot;);', target: '_self'},
							{title: '크립/집게/핀', url: 'javascript:goCategoryList(&quot;C001002700050011&quot;);', target: '_self'},
							{title: '기타OA용품', url: 'javascript:goCategoryList(&quot;C001002700050010&quot;);', target: '_self'}
						]
					},
					{
						title: '사무정리용품', url: 'javascript:goCategoryList(&quot;C00100270006&SITELOC=LL052&quot;);', target: '_self',
						subMenu: [
							{title: '책꽂이/화일박스', url: 'javascript:goCategoryList(&quot;C001002700060001&quot;);', target: '_self'},
							{title: '독서대', url: 'javascript:goCategoryList(&quot;C001002700060002&quot;);', target: '_self'},
							{title: '서류함/서류받침', url: 'javascript:goCategoryList(&quot;C001002700060003&quot;);', target: '_self'},
							{title: '클리어화일', url: 'javascript:goCategoryList(&quot;C001002700060004&quot;);', target: '_self'},
							{title: '바인더', url: 'javascript:goCategoryList(&quot;C001002700060008&quot;);', target: '_self'},
							{title: '기타화일', url: 'javascript:goCategoryList(&quot;C001002700060005&quot;);', target: '_self'},
							{title: '앨범', url: 'javascript:goCategoryList(&quot;C001002700060006&quot;);', target: '_self'},
							{title: '기타정리용품', url: 'javascript:goCategoryList(&quot;C001002700060007&quot;);', target: '_self'}
						]
					},
					{
						title: '팬시/파티용품', url: 'javascript:goCategoryList(&quot;C00100270007&SITELOC=LL053&quot;);', target: '_self',
						subMenu: [
							{title: '풍선', url: 'javascript:goCategoryList(&quot;C001002700070001&quot;);', target: '_self'},
							{title: '불꽃놀이', url: 'javascript:goCategoryList(&quot;C001002700070002&quot;);', target: '_self'},
							{title: '기타파티소품', url: 'javascript:goCategoryList(&quot;C001002700070003&quot;);', target: '_self'},
							{title: '포장지/쇼핑백', url: 'javascript:goCategoryList(&quot;C001002700070004&quot;);', target: '_self'},
							{title: '포장용품', url: 'javascript:goCategoryList(&quot;C001002700070005&quot;);', target: '_self'},
							{title: '팬시스티커', url: 'javascript:goCategoryList(&quot;C001002700070006&quot;);', target: '_self'},
							{title: '향초', url: 'javascript:goCategoryList(&quot;C001002700070007&quot;);', target: '_self'},
							{title: '편지지', url: 'javascript:goCategoryList(&quot;C001002700070008&quot;);', target: '_self'},
							{title: '기타팬시용품', url: 'javascript:goCategoryList(&quot;C001002700070009&quot;);', target: '_self'}
						]
					},
					{
						title: '자동차용품', url: 'javascript:goCategoryList(&quot;C00100270009&SITELOC=LL055&quot;);', target: '_self',
						subMenu: [
							{title: '정비용품/와이퍼', url: 'javascript:goCategoryList(&quot;C001002700090001&quot;);', target: '_self'},
							{title: '연료첨가제/엔진오일', url: 'javascript:goCategoryList(&quot;C001002700090002&quot;);', target: '_self'},
							{title: '컴파운드/페인트', url: 'javascript:goCategoryList(&quot;C001002700090003&quot;);', target: '_self'},
							{title: '청소용품/도구', url: 'javascript:goCategoryList(&quot;C001002700090004&quot;);', target: '_self'},
							{title: '왁스/세정제', url: 'javascript:goCategoryList(&quot;C001002700090005&quot;);', target: '_self'},
							{title: '방향제', url: 'javascript:goCategoryList(&quot;C001002700090006&quot;);', target: '_self'},
							{title: '시트/쿠션', url: 'javascript:goCategoryList(&quot;C001002700090007&quot;);', target: '_self'},
							{title: '수납/핸드폰소품', url: 'javascript:goCategoryList(&quot;C001002700090008&quot;);', target: '_self'},
							{title: '핸들커버/파워핸들', url: 'javascript:goCategoryList(&quot;C001002700090009&quot;);', target: '_self'},
							{title: '룸미러/보조미러', url: 'javascript:goCategoryList(&quot;C001002700090010&quot;);', target: '_self'},
							{title: '기타악세사리', url: 'javascript:goCategoryList(&quot;C001002700090011&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '애완용품', url: '/indexPet.do?SITELOC=LL056', target: '_self',
				subMenu: [
					{
						title: '애견식품', url: 'javascript:goCategorySpecList(&quot;C0230001&SITELOC=LL057&quot;);', target: '_self',
						subMenu: [
							{title: '브랜드사료', url: 'javascript:goCategorySpecList(&quot;C02300010001&quot;);', target: '_self'},
							{title: '연령/기능별사료', url: 'javascript:goCategorySpecList(&quot;C02300010002&quot;);', target: '_self'},
							{title: '간식/영양제', url: 'javascript:goCategorySpecList(&quot;C02300010003&quot;);', target: '_self'}
						]
					},
					{
						title: '애견용품', url: 'javascript:goCategorySpecList(&quot;C0230002&SITELOC=LL058&quot;);', target: '_self',
						subMenu: [
							{title: '목욕용품', url: 'javascript:goCategorySpecList(&quot;C02300020001&quot;);', target: '_self'},
							{title: '미용용품', url: 'javascript:goCategorySpecList(&quot;C02300020002&quot;);', target: '_self'},
							{title: '배변용품', url: 'javascript:goCategorySpecList(&quot;C02300020003&quot;);', target: '_self'},
							{title: '애견줄', url: 'javascript:goCategorySpecList(&quot;C02300020004&quot;);', target: '_self'},
							{title: '의류/액세서리', url: 'javascript:goCategorySpecList(&quot;C02300020005&quot;);', target: '_self'},
							{title: '장난감/식기', url: 'javascript:goCategorySpecList(&quot;C02300020006&quot;);', target: '_self'},
							{title: '하우스/이동장', url: 'javascript:goCategorySpecList(&quot;C02300020007&quot;);', target: '_self'}
						]
					},
					{
						title: '고양이식품', url: 'javascript:goCategorySpecList(&quot;C0230003&SITELOC=LL059&quot;);', target: '_self',
						subMenu: [
							{title: '브랜드사료', url: 'javascript:goCategorySpecList(&quot;C02300030001&quot;);', target: '_self'},
							{title: '연령/기능별사료', url: 'javascript:goCategorySpecList(&quot;C02300030002&quot;);', target: '_self'},
							{title: '캔/파우치', url: 'javascript:goCategorySpecList(&quot;C02300030003&quot;);', target: '_self'},
							{title: '간식/영양제', url: 'javascript:goCategorySpecList(&quot;C02300030004&quot;);', target: '_self'}
						]
					},
					{
						title: '고양이용품', url: 'javascript:goCategorySpecList(&quot;C0230004&SITELOC=LL060&quot;);', target: '_self',
						subMenu: [
							{title: '모래', url: 'javascript:goCategorySpecList(&quot;C02300040001&quot;);', target: '_self'},
							{title: '화장실', url: 'javascript:goCategorySpecList(&quot;C02300040002&quot;);', target: '_self'},
							{title: '장난감/캣닙', url: 'javascript:goCategorySpecList(&quot;C02300040003&quot;);', target: '_self'},
							{title: '스크래쳐/캣타워', url: 'javascript:goCategorySpecList(&quot;C02300040004&quot;);', target: '_self'},
							{title: '목욕/미용', url: 'javascript:goCategorySpecList(&quot;C02300040005&quot;);', target: '_self'},
							{title: '하우스/캐리어', url: 'javascript:goCategorySpecList(&quot;C02300040006&quot;);', target: '_self'}
						]
					},
					{
						title: '수족관/기타동물', url: 'javascript:goCategorySpecList(&quot;C0230005&SITELOC=LL061&quot;);', target: '_self',
						subMenu: [
							{title: '관상어', url: 'javascript:goCategorySpecList(&quot;C02300050001&quot;);', target: '_self'},
							{title: '관상조', url: 'javascript:goCategorySpecList(&quot;C02300050002&quot;);', target: '_self'},
							{title: '애완곤충용품', url: 'javascript:goCategorySpecList(&quot;C02300050003&quot;);', target: '_self'},
							{title: '애완소동물', url: 'javascript:goCategorySpecList(&quot;C02300050004&quot;);', target: '_self'},
							{title: '기타용품', url: 'javascript:goCategorySpecList(&quot;C02300050005&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '패션의류 / 언더웨어', url: 'javascript:goCategoryList(&quot;C0010028&SITELOC=LL062&quot;);', target: '_self',
				subMenu: [
					{
						title: '남성의류', url: 'javascript:goCategoryList(&quot;C00100280001&SITELOC=LL063&quot;);', target: '_self',
						subMenu: [
							{title: '남성자켓', url: 'javascript:goCategoryList(&quot;C001002800010007&quot;);', target: '_self'},
							{title: '남성점퍼', url: 'javascript:goCategoryList(&quot;C001002800010003&quot;);', target: '_self'},
							{title: '남성카디건/조끼', url: 'javascript:goCategoryList(&quot;C001002800010005&quot;);', target: '_self'},
							{title: '남성니트', url: 'javascript:goCategoryList(&quot;C001002800010006&quot;);', target: '_self'},
							{title: '남성티셔츠', url: 'javascript:goCategoryList(&quot;C001002800010001&quot;);', target: '_self'},
							{title: '남성셔츠', url: 'javascript:goCategoryList(&quot;C001002800010002&quot;);', target: '_self'},
							{title: '남성바지', url: 'javascript:goCategoryList(&quot;C001002800010004&quot;);', target: '_self'}
						]
					},
					{
						title: '여성의류', url: 'javascript:goCategoryList(&quot;C00100280002&SITELOC=LL064&quot;);', target: '_self',
						subMenu: [
							{title: '여성자켓', url: 'javascript:goCategoryList(&quot;C001002800020003&quot;);', target: '_self'},
							{title: '여성점퍼', url: 'javascript:goCategoryList(&quot;C001002800020009&quot;);', target: '_self'},
							{title: '여성카디건/조끼', url: 'javascript:goCategoryList(&quot;C001002800020006&quot;);', target: '_self'},
							{title: '여성니트', url: 'javascript:goCategoryList(&quot;C001002800020007&quot;);', target: '_self'},
							{title: '여성티셔츠', url: 'javascript:goCategoryList(&quot;C001002800020001&quot;);', target: '_self'},
							{title: '여성셔츠/블라우스', url: 'javascript:goCategoryList(&quot;C001002800020008&quot;);', target: '_self'},
							{title: '여성원피스', url: 'javascript:goCategoryList(&quot;C001002800020002&quot;);', target: '_self'},
							{title: '여성스커트', url: 'javascript:goCategoryList(&quot;C001002800020010&quot;);', target: '_self'},
							{title: '여성바지', url: 'javascript:goCategoryList(&quot;C001002800020004&quot;);', target: '_self'},
							{title: '임부복', url: 'javascript:goCategoryList(&quot;C001002800020005&quot;);', target: '_self'}
						]
					},
					{
						title: '아동의류', url: 'javascript:goCategoryList(&quot;C00100280003&SITELOC=LL065&quot;);', target: '_self',
						subMenu: [
							{title: '남아동자켓/점퍼', url: 'javascript:goCategoryList(&quot;C001002800030001&quot;);', target: '_self'},
							{title: '남아동티셔츠/후드', url: 'javascript:goCategoryList(&quot;C001002800030006&quot;);', target: '_self'},
							{title: '남아동셔츠', url: 'javascript:goCategoryList(&quot;C001002800030008&quot;);', target: '_self'},
							{title: '남아동바지', url: 'javascript:goCategoryList(&quot;C001002800030002&quot;);', target: '_self'},
							{title: '여아동자켓/점퍼', url: 'javascript:goCategoryList(&quot;C001002800030003&quot;);', target: '_self'},
							{title: '여아동티셔츠/후드', url: 'javascript:goCategoryList(&quot;C001002800030007&quot;);', target: '_self'},
							{title: '여아동셔츠', url: 'javascript:goCategoryList(&quot;C001002800030009&quot;);', target: '_self'},
							{title: '여아원피스', url: 'javascript:goCategoryList(&quot;C001002800030004&quot;);', target: '_self'},
							{title: '여아바지/스커트', url: 'javascript:goCategoryList(&quot;C001002800030005&quot;);', target: '_self'}
						]
					},
					{
						title: '남성언더웨어', url: 'javascript:goCategoryList(&quot;C00100280004&SITELOC=LL066&quot;);', target: '_self',
						subMenu: [
							{title: '남성트렁크', url: 'javascript:goCategoryList(&quot;C001002800040001&quot;);', target: '_self'},
							{title: '남성삼각팬티', url: 'javascript:goCategoryList(&quot;C001002800040002&quot;);', target: '_self'},
							{title: '남성드로즈팬티', url: 'javascript:goCategoryList(&quot;C001002800040003&quot;);', target: '_self'},
							{title: '남성런닝/내의', url: 'javascript:goCategoryList(&quot;C001002800040004&quot;);', target: '_self'},
							{title: '남성잠옷/이지웨어', url: 'javascript:goCategoryList(&quot;C001002800040005&quot;);', target: '_self'}
						]
					},
					{
						title: '여성언더웨어', url: 'javascript:goCategoryList(&quot;C00100280005&SITELOC=LL067&quot;);', target: '_self',
						subMenu: [
							{title: '여성브라&세트', url: 'javascript:goCategoryList(&quot;C001002800050005&quot;);', target: '_self'},
							{title: '여성팬티', url: 'javascript:goCategoryList(&quot;C001002800050001&quot;);', target: '_self'},
							{title: '여성브라', url: 'javascript:goCategoryList(&quot;C001002800050002&quot;);', target: '_self'},
							{title: '여성런닝/내의', url: 'javascript:goCategoryList(&quot;C001002800050003&quot;);', target: '_self'},
							{title: '여성거들/보정쉐이퍼', url: 'javascript:goCategoryList(&quot;C001002800050006&quot;);', target: '_self'},
							{title: '여성잠옷/이지웨어', url: 'javascript:goCategoryList(&quot;C001002800050004&quot;);', target: '_self'},
							{title: '임부용속옷', url: 'javascript:goCategoryList(&quot;C001002800050007&quot;);', target: '_self'}
						]
					},
					{
						title: '아동언더웨어', url: 'javascript:goCategoryList(&quot;C00100280006&SITELOC=LL068&quot;);', target: '_self',
						subMenu: [
							{title: '남아동팬티', url: 'javascript:goCategoryList(&quot;C001002800060001&quot;);', target: '_self'},
							{title: '남아동런닝', url: 'javascript:goCategoryList(&quot;C001002800060002&quot;);', target: '_self'},
							{title: '남아동내의', url: 'javascript:goCategoryList(&quot;C001002800060005&quot;);', target: '_self'},
							{title: '여아동팬티', url: 'javascript:goCategoryList(&quot;C001002800060003&quot;);', target: '_self'},
							{title: '여아동런닝', url: 'javascript:goCategoryList(&quot;C001002800060004&quot;);', target: '_self'},
							{title: '여아동브라', url: 'javascript:goCategoryList(&quot;C001002800060007&quot;);', target: '_self'},
							{title: '여아동내의', url: 'javascript:goCategoryList(&quot;C001002800060006&quot;);', target: '_self'}
						]
					},
					{
						title: '양말/스타킹/레깅스', url: 'javascript:goCategoryList(&quot;C00100280007&SITELOC=LL069&quot;);', target: '_self',
						subMenu: [
							{title: '남성정장/캐쥬얼양말', url: 'javascript:goCategoryList(&quot;C001002800070001&quot;);', target: '_self'},
							{title: '남성스포츠양말', url: 'javascript:goCategoryList(&quot;C001002800070002&quot;);', target: '_self'},
							{title: '남성스니커즈양말', url: 'javascript:goCategoryList(&quot;C001002800070006&quot;);', target: '_self'},
							{title: '여성정장/캐쥬얼양말', url: 'javascript:goCategoryList(&quot;C001002800070007&quot;);', target: '_self'},
							{title: '여성스포츠양말', url: 'javascript:goCategoryList(&quot;C001002800070003&quot;);', target: '_self'},
							{title: '여성스니커즈양말', url: 'javascript:goCategoryList(&quot;C001002800070008&quot;);', target: '_self'},
							{title: '스타킹/레깅스/타이즈', url: 'javascript:goCategoryList(&quot;C001002800070005&quot;);', target: '_self'},
							{title: '아동양말/타이즈', url: 'javascript:goCategoryList(&quot;C001002800070004&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '신발/잡화', url: 'javascript:goCategoryList(&quot;C0010029&SITELOC=LL070&quot;);', target: '_self',
				subMenu: [
					{
						title: '신발', url: 'javascript:goCategoryList(&quot;C00100290001&SITELOC=LL071&quot;);', target: '_self',
						subMenu: [
							{title: '남성구두', url: 'javascript:goCategoryList(&quot;C001002900010001&quot;);', target: '_self'},
							{title: '여성구두', url: 'javascript:goCategoryList(&quot;C001002900010002&quot;);', target: '_self'},
							{title: '남성운동화', url: 'javascript:goCategoryList(&quot;C001002900010003&quot;);', target: '_self'},
							{title: '여성운동화', url: 'javascript:goCategoryList(&quot;C001002900010004&quot;);', target: '_self'},
							{title: '아동화', url: 'javascript:goCategoryList(&quot;C001002900010005&quot;);', target: '_self'},
							{title: '슬리퍼', url: 'javascript:goCategoryList(&quot;C001002900010006&quot;);', target: '_self'},
							{title: '구두용품', url: 'javascript:goCategoryList(&quot;C001002900010007&quot;);', target: '_self'}
						]
					},
					{
						title: '지갑/벨트', url: 'javascript:goCategoryList(&quot;C00100290005&SITELOC=LL072&quot;);', target: '_self',
						subMenu: [
							{title: '남성지갑', url: 'javascript:goCategoryList(&quot;C001002900050001&quot;);', target: '_self'},
							{title: '여성지갑', url: 'javascript:goCategoryList(&quot;C001002900050002&quot;);', target: '_self'},
							{title: '남성벨트', url: 'javascript:goCategoryList(&quot;C001002900050003&quot;);', target: '_self'},
							{title: '여성벨트', url: 'javascript:goCategoryList(&quot;C001002900050004&quot;);', target: '_self'}
						]
					},
					{
						title: '여행가방', url: 'javascript:goCategoryList(&quot;C00100290003&SITELOC=LL073&quot;);', target: '_self',
						subMenu: [
							{title: '기내용소프트케이스', url: 'javascript:goCategoryList(&quot;C001002900030001&quot;);', target: '_self'},
							{title: '기내용하드케이스', url: 'javascript:goCategoryList(&quot;C001002900030002&quot;);', target: '_self'},
							{title: '수화물용소프트케이스', url: 'javascript:goCategoryList(&quot;C001002900030003&quot;);', target: '_self'},
							{title: '수화물용하드케이스', url: 'javascript:goCategoryList(&quot;C001002900030004&quot;);', target: '_self'},
							{title: '여행소품', url: 'javascript:goCategoryList(&quot;C001002900030005&quot;);', target: '_self'}
						]
					},
					{
						title: '핸드백/가방', url: 'javascript:goCategoryList(&quot;C00100290004&SITELOC=LL074&quot;);', target: '_self',
						subMenu: [
							{title: '토드백', url: 'javascript:goCategoryList(&quot;C001002900040001&quot;);', target: '_self'},
							{title: '숄더백', url: 'javascript:goCategoryList(&quot;C001002900040002&quot;);', target: '_self'},
							{title: '크로스백', url: 'javascript:goCategoryList(&quot;C001002900040003&quot;);', target: '_self'},
							{title: '캐주얼백/백팩', url: 'javascript:goCategoryList(&quot;C001002900040004&quot;);', target: '_self'},
							{title: '서류가방/맨즈백', url: 'javascript:goCategoryList(&quot;C001002900040005&quot;);', target: '_self'},
							{title: '아동가방', url: 'javascript:goCategoryList(&quot;C001002900040006&quot;);', target: '_self'}
						]
					},
					{
						title: '패션악세서리/시즌잡화/우산', url: 'javascript:goCategoryList(&quot;C00100290002&SITELOC=LL075&quot;);', target: '_self',
						subMenu: [
							{title: '시계', url: 'javascript:goCategoryList(&quot;C001002900020003&quot;);', target: '_self'},
							{title: '선글라스/안경', url: 'javascript:goCategoryList(&quot;C001002900020002&quot;);', target: '_self'},
							{title: '모자', url: 'javascript:goCategoryList(&quot;C001002900020001&quot;);', target: '_self'},
							{title: '장갑', url: 'javascript:goCategoryList(&quot;C001002900020004&quot;);', target: '_self'},
							{title: '머플러/스카프', url: 'javascript:goCategoryList(&quot;C001002900020005&quot;);', target: '_self'},
							{title: '넥타이', url: 'javascript:goCategoryList(&quot;C001002900020006&quot;);', target: '_self'},
							{title: '우산/우의', url: 'javascript:goCategoryList(&quot;C001002900020007&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '스포츠/레저', url: 'javascript:goCategoryList(&quot;C0010030&SITELOC=LL076&quot;);', target: '_self',
				subMenu: [
					{
						title: '헬스기구/운동용품', url: 'javascript:goCategoryList(&quot;C00100300001&SITELOC=LL077&quot;);', target: '_self',
						subMenu: [
							{title: '런닝머신/실내사이클', url: 'javascript:goCategoryList(&quot;C001003000010001&quot;);', target: '_self'},
							{title: '아령/덤벨', url: 'javascript:goCategoryList(&quot;C001003000010002&quot;);', target: '_self'},
							{title: '줄넘기/짐볼/요가', url: 'javascript:goCategoryList(&quot;C001003000010003&quot;);', target: '_self'},
							{title: '훌라우프', url: 'javascript:goCategoryList(&quot;C001003000010004&quot;);', target: '_self'},
							{title: '체중계', url: 'javascript:goCategoryList(&quot;C001003000010005&quot;);', target: '_self'},
							{title: '헬스장갑/보호대', url: 'javascript:goCategoryList(&quot;C001003000010006&quot;);', target: '_self'},
							{title: '기타운동용품', url: 'javascript:goCategoryList(&quot;C001003000010007&quot;);', target: '_self'},
							{title: '요가복/트레이닝복', url: 'javascript:goCategoryList(&quot;C001003000010008&quot;);', target: '_self'}
						]
					},
					{
						title: '자전거', url: 'javascript:goCategoryList(&quot;C00100300002&SITELOC=LL078&quot;);', target: '_self',
						subMenu: [
							{title: '자전거', url: 'javascript:goCategoryList(&quot;C001003000020001&quot;);', target: '_self'},
							{title: '자전거부품/튜닝용품', url: 'javascript:goCategoryList(&quot;C001003000020002&quot;);', target: '_self'},
							{title: '자전거잠금/거치대/기타용품', url: 'javascript:goCategoryList(&quot;C001003000020003&quot;);', target: '_self'},
							{title: '헬멧/보호구/장갑/토시', url: 'javascript:goCategoryList(&quot;C001003000020005&quot;);', target: '_self'},
							{title: '자전거의류', url: 'javascript:goCategoryList(&quot;C001003000020006&quot;);', target: '_self'}
						]
					},
					{
						title: '등산', url: 'javascript:goCategoryList(&quot;C00100300003&SITELOC=LL079&quot;);', target: '_self',
						subMenu: [
							{title: '등산가방', url: 'javascript:goCategoryList(&quot;C001003000030001&quot;);', target: '_self'},
							{title: '등산화', url: 'javascript:goCategoryList(&quot;C001003000030003&quot;);', target: '_self'},
							{title: '등산스틱', url: 'javascript:goCategoryList(&quot;C001003000030004&quot;);', target: '_self'},
							{title: '등산모자', url: 'javascript:goCategoryList(&quot;C001003000030002&quot;);', target: '_self'},
							{title: '등산장갑/기타용품', url: 'javascript:goCategoryList(&quot;C001003000030005&quot;);', target: '_self'},
							{title: '남성등산자켓/조끼', url: 'javascript:goCategoryList(&quot;C001003000030006&quot;);', target: '_self'},
							{title: '남성등산티셔츠', url: 'javascript:goCategoryList(&quot;C001003000030010&quot;);', target: '_self'},
							{title: '남성등산바지', url: 'javascript:goCategoryList(&quot;C001003000030007&quot;);', target: '_self'},
							{title: '여성등산자켓/조끼', url: 'javascript:goCategoryList(&quot;C001003000030008&quot;);', target: '_self'},
							{title: '여성등산티셔츠', url: 'javascript:goCategoryList(&quot;C001003000030011&quot;);', target: '_self'},
							{title: '여성등산바지', url: 'javascript:goCategoryList(&quot;C001003000030009&quot;);', target: '_self'}
						]
					},
					{
						title: '캠핑', url: 'javascript:goCategoryList(&quot;C00100300004&SITELOC=LL080&quot;);', target: '_self',
						subMenu: [
							{title: '캠핑텐트/그늘막/소품', url: 'javascript:goCategoryList(&quot;C001003000040001&quot;);', target: '_self'},
							{title: '캠핑침낭/침대/매트', url: 'javascript:goCategoryList(&quot;C001003000040002&quot;);', target: '_self'},
							{title: '캠핑테이블', url: 'javascript:goCategoryList(&quot;C001003000040004&quot;);', target: '_self'},
							{title: '캠핑의자/야외용품', url: 'javascript:goCategoryList(&quot;C001003000040005&quot;);', target: '_self'},
							{title: '캠핑버너/그릴/스토치', url: 'javascript:goCategoryList(&quot;C001003000040006&quot;);', target: '_self'},
							{title: '캠핑코펠/취사도구', url: 'javascript:goCategoryList(&quot;C001003000040007&quot;);', target: '_self'},
							{title: '캠핑랜턴/램프/연료', url: 'javascript:goCategoryList(&quot;C001003000040003&quot;);', target: '_self'},
							{title: '캠핑기타용품', url: 'javascript:goCategoryList(&quot;C001003000040008&quot;);', target: '_self'}
						]
					},
					{
						title: '낚시', url: 'javascript:goCategoryList(&quot;C00100300005&SITELOC=LL081&quot;);', target: '_self',
						subMenu: [
							{title: '낚시대', url: 'javascript:goCategoryList(&quot;C001003000050001&quot;);', target: '_self'},
							{title: '낚시릴', url: 'javascript:goCategoryList(&quot;C001003000050002&quot;);', target: '_self'},
							{title: '낚시줄/가방/의자/용품', url: 'javascript:goCategoryList(&quot;C001003000050003&quot;);', target: '_self'},
							{title: '낚시조끼/모자/신발', url: 'javascript:goCategoryList(&quot;C001003000050004&quot;);', target: '_self'}
						]
					},
					{
						title: '야구/축구', url: 'javascript:goCategoryList(&quot;C00100300006&SITELOC=LL082&quot;);', target: '_self',
						subMenu: [
							{title: '야구글러브', url: 'javascript:goCategoryList(&quot;C001003000060001&quot;);', target: '_self'},
							{title: '야구배트', url: 'javascript:goCategoryList(&quot;C001003000060002&quot;);', target: '_self'},
							{title: '야구공', url: 'javascript:goCategoryList(&quot;C001003000060003&quot;);', target: '_self'},
							{title: '야구기타용품', url: 'javascript:goCategoryList(&quot;C001003000060005&quot;);', target: '_self'},
							{title: '축구공', url: 'javascript:goCategoryList(&quot;C001003000060006&quot;);', target: '_self'},
							{title: '축구화', url: 'javascript:goCategoryList(&quot;C001003000060007&quot;);', target: '_self'},
							{title: '축구기타용품', url: 'javascript:goCategoryList(&quot;C001003000060008&quot;);', target: '_self'}
						]
					},
					{
						title: '농구/배구/탁구/배드민턴/테니스', url: 'javascript:goCategoryList(&quot;C00100300007&SITELOC=LL083&quot;);', target: '_self',
						subMenu: [
							{title: '농구', url: 'javascript:goCategoryList(&quot;C001003000070001&quot;);', target: '_self'},
							{title: '배구', url: 'javascript:goCategoryList(&quot;C001003000070002&quot;);', target: '_self'},
							{title: '탁구', url: 'javascript:goCategoryList(&quot;C001003000070003&quot;);', target: '_self'},
							{title: '테니스', url: 'javascript:goCategoryList(&quot;C001003000070004&quot;);', target: '_self'},
							{title: '배드민턴', url: 'javascript:goCategoryList(&quot;C001003000070005&quot;);', target: '_self'}
						]
					},
					{
						title: '골프', url: 'javascript:goCategoryList(&quot;C00100300008&SITELOC=LL084&quot;);', target: '_self',
						subMenu: [
							{title: '풀세트', url: 'javascript:goCategoryList(&quot;C001003000080002&quot;);', target: '_self'},
							{title: '드라이버', url: 'javascript:goCategoryList(&quot;C001003000080003&quot;);', target: '_self'},
							{title: '아이언', url: 'javascript:goCategoryList(&quot;C001003000080004&quot;);', target: '_self'},
							{title: '우드', url: 'javascript:goCategoryList(&quot;C001003000080005&quot;);', target: '_self'},
							{title: '유틸/하이브리드', url: 'javascript:goCategoryList(&quot;C001003000080006&quot;);', target: '_self'},
							{title: '퍼터', url: 'javascript:goCategoryList(&quot;C001003000080007&quot;);', target: '_self'},
							{title: '웨지/치퍼', url: 'javascript:goCategoryList(&quot;C001003000080008&quot;);', target: '_self'},
							{title: '골프공', url: 'javascript:goCategoryList(&quot;C001003000080009&quot;);', target: '_self'},
							{title: '골프장갑/모자', url: 'javascript:goCategoryList(&quot;C001003000080010&quot;);', target: '_self'},
							{title: '골프화', url: 'javascript:goCategoryList(&quot;C001003000080011&quot;);', target: '_self'},
							{title: '골프백/커버', url: 'javascript:goCategoryList(&quot;C001003000080012&quot;);', target: '_self'},
							{title: '골프연습용품', url: 'javascript:goCategoryList(&quot;C001003000080013&quot;);', target: '_self'},
							{title: '골프티/골프우산/기타용품', url: 'javascript:goCategoryList(&quot;C001003000080014&quot;);', target: '_self'},
							{title: '골프의류상의', url: 'javascript:goCategoryList(&quot;C001003000080015&quot;);', target: '_self'},
							{title: '골프의류하의', url: 'javascript:goCategoryList(&quot;C001003000080016&quot;);', target: '_self'}
						]
					},
					{
						title: '수영/스키보드', url: 'javascript:goCategoryList(&quot;C00100300009&SITELOC=LL085&quot;);', target: '_self',
						subMenu: [
							{title: '스키보드고글/장비', url: 'javascript:goCategoryList(&quot;C001003000090001&quot;);', target: '_self'},
							{title: '스키보드장갑/양말/기타', url: 'javascript:goCategoryList(&quot;C001003000090002&quot;);', target: '_self'},
							{title: '남성스키보드복', url: 'javascript:goCategoryList(&quot;C001003000090003&quot;);', target: '_self'},
							{title: '여성스키보드복', url: 'javascript:goCategoryList(&quot;C001003000090004&quot;);', target: '_self'},
							{title: '아동스키보드복', url: 'javascript:goCategoryList(&quot;C001003000090005&quot;);', target: '_self'},
							{title: '물놀이/수영용품', url: 'javascript:goCategoryList(&quot;C001003000090006&quot;);', target: '_self'},
							{title: '남성수영복', url: 'javascript:goCategoryList(&quot;C001003000090007&quot;);', target: '_self'},
							{title: '여성수영복', url: 'javascript:goCategoryList(&quot;C001003000090008&quot;);', target: '_self'},
							{title: '남아 수영복', url: 'javascript:goCategoryList(&quot;C001003000090009&quot;);', target: '_self'},
							{title: '여아 수영복', url: 'javascript:goCategoryList(&quot;C001003000090010&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '해외브랜드관', url: 'javascript:goCategoryList(&quot;C0010031&SITELOC=LL086&quot;);', target: '_self',
				subMenu: [
					{
						title: '해외브랜드핸드백/가방/지갑', url: 'javascript:goCategoryList(&quot;C00100310001&SITELOC=LL087&quot;);', target: '_self',
						subMenu: [
							{title: '구찌(GUCCI)', url: 'javascript:goCategorySpecList(&quot;C001003100010001&quot;);', target: '_self'},
							{title: '돌체앤가바나(DOLCE&GABBANA)', url: 'javascript:goCategorySpecList(&quot;C001003100010002&quot;);', target: '_self'},
							{title: '지방시(GIVENCHY)', url: 'javascript:goCategorySpecList(&quot;C001003100010003&quot;);', target: '_self'},
							{title: '끌로에(CHLOE)', url: 'javascript:goCategorySpecList(&quot;C001003100010004&quot;);', target: '_self'},
							{title: '멀버리(MULBERRY)/이브생로랑(YSL)', url: 'javascript:goCategorySpecList(&quot;C001003100010005&quot;);', target: '_self'},
							{title: '페라가모(FERRAGAMO)', url: 'javascript:goCategorySpecList(&quot;C001003100010006&quot;);', target: '_self'},
							{title: '폴스미스(PAUL SMITH)', url: 'javascript:goCategorySpecList(&quot;C001003100010007&quot;);', target: '_self'},
							{title: '보테가 베네타(bottegaveneta)', url: 'javascript:goCategorySpecList(&quot;C001003100010008&quot;);', target: '_self'},
							{title: '듀퐁(Dupont)', url: 'javascript:goCategorySpecList(&quot;C001003100010009&quot;);', target: '_self'},
							{title: '버버리(BURBERRY)', url: 'javascript:goCategorySpecList(&quot;C001003100010010&quot;);', target: '_self'},
							{title: '발리(BALLY)', url: 'javascript:goCategorySpecList(&quot;C001003100010011&quot;);', target: '_self'},
							{title: '키플링(kipling)', url: 'javascript:goCategorySpecList(&quot;C001003100010012&quot;);', target: '_self'},
							{title: '펜디(FENDI)', url: 'javascript:goCategorySpecList(&quot;C001003100010013&quot;);', target: '_self'}
						]
					},
					{
						title: '해외브랜드구두/운동화', url: 'javascript:goCategoryList(&quot;C00100310002&SITELOC=LL088&quot;);', target: '_self',
						subMenu: [
							{title: '사이컴(Sykum)', url: 'javascript:goCategorySpecList(&quot;C001003100020001&quot;);', target: '_self'},
							{title: '에고스노우(Egosnow)', url: 'javascript:goCategorySpecList(&quot;C001003100020002&quot;);', target: '_self'},
							{title: '스프리스(SPRIS)', url: 'javascript:goCategorySpecList(&quot;C001003100020003&quot;);', target: '_self'},
							{title: '허시파피(Hushpuppies)', url: 'javascript:goCategorySpecList(&quot;C001003100020004&quot;);', target: '_self'}
						]
					},
					{
						title: '해외브랜드화장품/향수', url: 'javascript:goCategoryList(&quot;C00100310003&SITELOC=LL089&quot;);', target: '_self',
						subMenu: [
							{title: '엘리자베스 아덴(Elizabeth arden)', url: 'javascript:goCategorySpecList(&quot;C001003100030001&quot;);', target: '_self'},
							{title: '올레이(Olay)', url: 'javascript:goCategorySpecList(&quot;C001003100030002&quot;);', target: '_self'},
							{title: '로레알(Loreal)', url: 'javascript:goCategorySpecList(&quot;C001003100030003&quot;);', target: '_self'},
							{title: '비오템(BIOTHERM)', url: 'javascript:goCategorySpecList(&quot;C001003100030004&quot;);', target: '_self'},
							{title: '갸스비(GASTBY)', url: 'javascript:goCategorySpecList(&quot;C001003100030005&quot;);', target: '_self'},
							{title: '오이보스(EUBOS)', url: 'javascript:goCategorySpecList(&quot;C001003100030006&quot;);', target: '_self'},
							{title: '오르비스(Orbis)', url: 'javascript:goCategorySpecList(&quot;C001003100030007&quot;);', target: '_self'},
							{title: '로베아(LOVEA)', url: 'javascript:goCategorySpecList(&quot;C001003100030008&quot;);', target: '_self'},
							{title: '지아자(ZIAJA)', url: 'javascript:goCategorySpecList(&quot;C001003100030009&quot;);', target: '_self'},
							{title: '아로마베이비(Aroma Baby)', url: 'javascript:goCategorySpecList(&quot;C001003100030010&quot;);', target: '_self'},
							{title: '코린더팜(CORINE DE FARME)', url: 'javascript:goCategorySpecList(&quot;C001003100030011&quot;);', target: '_self'},
							{title: '불가리(Bulgari)', url: 'javascript:goCategorySpecList(&quot;C001003100030012&quot;);', target: '_self'},
							{title: '버버리(Burberry)', url: 'javascript:goCategorySpecList(&quot;C001003100030013&quot;);', target: '_self'},
							{title: '캘빈클레인(Calvin Klein)', url: 'javascript:goCategorySpecList(&quot;C001003100030014&quot;);', target: '_self'},
							{title: '랑방(Lanvin)', url: 'javascript:goCategorySpecList(&quot;C001003100030015&quot;);', target: '_self'},
							{title: '폴로랄프로렌(Polo Ralph Lauren)', url: 'javascript:goCategorySpecList(&quot;C001003100030016&quot;);', target: '_self'},
							{title: '장아떼(Jeanne Arthes)', url: 'javascript:goCategorySpecList(&quot;C001003100030017&quot;);', target: '_self'},
							{title: '겐조(Kenzo)', url: 'javascript:goCategorySpecList(&quot;C001003100030018&quot;);', target: '_self'},
							{title: '베르사체/안나수이/페레가모/지미추', url: 'javascript:goCategorySpecList(&quot;C001003100030019&quot;);', target: '_self'},
							{title: '빅토리아 에그팩', url: 'javascript:goCategorySpecList(&quot;C001003100030020&quot;);', target: '_self'}
						]
					},
					{
						title: '해외브랜드패션소품/선글라스', url: 'javascript:goCategoryList(&quot;C00100310004&SITELOC=LL090&quot;);', target: '_self',
						subMenu: [
							{title: '펜디(FENDI)', url: 'javascript:goCategorySpecList(&quot;C001003100040001&quot;);', target: '_self'},
							{title: '비비안웨스트우드(Vivienne Westwood)', url: 'javascript:goCategorySpecList(&quot;C001003100040002&quot;);', target: '_self'},
							{title: '안나수이(ANNASUI)', url: 'javascript:goCategorySpecList(&quot;C001003100040003&quot;);', target: '_self'},
							{title: '구찌(GUCCI)', url: 'javascript:goCategorySpecList(&quot;C001003100040004&quot;);', target: '_self'},
							{title: '모스키노(MOSCHINO)', url: 'javascript:goCategorySpecList(&quot;C001003100040005&quot;);', target: '_self'},
							{title: '알비에로 마르티니(Alviero Martini)', url: 'javascript:goCategorySpecList(&quot;C001003100040006&quot;);', target: '_self'},
							{title: '캘빈클레인(Calvin Klein)', url: 'javascript:goCategorySpecList(&quot;C001003100040007&quot;);', target: '_self'},
							{title: '끌로에(CHLOE)', url: 'javascript:goCategorySpecList(&quot;C001003100040008&quot;);', target: '_self'},
							{title: '지방시(GIVENCHY)', url: 'javascript:goCategorySpecList(&quot;C001003100040009&quot;);', target: '_self'},
							{title: '마이클코어스(Michael Kors)', url: 'javascript:goCategorySpecList(&quot;C001003100040010&quot;);', target: '_self'},
							{title: '몽블랑(MONTBLANC)', url: 'javascript:goCategorySpecList(&quot;C001003100040011&quot;);', target: '_self'},
							{title: '스와로브스키(SWAROVSKI)', url: 'javascript:goCategorySpecList(&quot;C001003100040012&quot;);', target: '_self'},
							{title: '토즈(TODS)', url: 'javascript:goCategorySpecList(&quot;C001003100040013&quot;);', target: '_self'},
							{title: '타미힐피거(Tommy Hilfiger)', url: 'javascript:goCategorySpecList(&quot;C001003100040014&quot;);', target: '_self'},
							{title: '코치(Coach)', url: 'javascript:goCategorySpecList(&quot;C001003100040015&quot;);', target: '_self'},
							{title: '잭니클라우스(Jack Nicklaus)', url: 'javascript:goCategorySpecList(&quot;C001003100040016&quot;);', target: '_self'},
							{title: '에트로(ETRO)', url: 'javascript:goCategorySpecList(&quot;C001003100040017&quot;);', target: '_self'},
							{title: '칼 라거펠드 (Karl Lagerfeld)/기타', url: 'javascript:goCategorySpecList(&quot;C001003100040018&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '완구', url: '/indexToy.do?SITELOC=LL092', target: '_self',
				subMenu: [
					{
						title: '전자게임', url: 'javascript:goCategorySpecList(&quot;C02200010001&SITELOC=LL093&quot;);', target: '_self',
						subMenu: [
							{title: '일반전자게임', url: 'javascript:goCategorySpecList(&quot;C022000100010001&quot;);', target: '_self'},
							{title: '전자악기장난감', url: 'javascript:goCategorySpecList(&quot;C022000100010002&quot;);', target: '_self'}
						]
					},
					{
						title: '일반교육장난감', url: 'javascript:goCategorySpecList(&quot;C02200020001&SITELOC=LL094&quot;);', target: '_self',
						subMenu: [
							{title: '토마스', url: 'javascript:goCategorySpecList(&quot;C022000200010001&quot;);', target: '_self'},
							{title: '멜리사앤덕', url: 'javascript:goCategorySpecList(&quot;C022000200010002&quot;);', target: '_self'},
							{title: '목재장난감', url: 'javascript:goCategorySpecList(&quot;C022000200010003&quot;);', target: '_self'},
							{title: '처깅턴', url: 'javascript:goCategorySpecList(&quot;C022000200010004&quot;);', target: '_self'},
							{title: '로보카폴리', url: 'javascript:goCategorySpecList(&quot;C022000200010005&quot;);', target: '_self'},
							{title: '버디', url: 'javascript:goCategorySpecList(&quot;C022000200010006&quot;);', target: '_self'}
						]
					},
					{
						title: '닌텐도/비디오게임기', url: 'javascript:goCategorySpecList(&quot;C02200010002&SITELOC=LL095&quot;);', target: '_self',
						subMenu: [
							{title: 'wii', url: 'javascript:goCategorySpecList(&quot;C022000100020001&quot;);', target: '_self'},
							{title: '3ds/dsi', url: 'javascript:goCategorySpecList(&quot;C022000100020002&quot;);', target: '_self'},
							{title: 'ps3/pspvita', url: 'javascript:goCategorySpecList(&quot;C022000100020003&quot;);', target: '_self'},
							{title: 'xbox', url: 'javascript:goCategorySpecList(&quot;C022000100020004&quot;);', target: '_self'}
						]
					},
					{
						title: '닌텐도/비디오게임소프트웨어', url: 'javascript:goCategorySpecList(&quot;C02200010003&SITELOC=LL096&quot;);', target: '_self',
						subMenu: [
							{title: 'Wii 소프트웨어', url: 'javascript:goCategorySpecList(&quot;C022000100030001&quot;);', target: '_self'},
							{title: '3DS/DSi 소프트웨어', url: 'javascript:goCategorySpecList(&quot;C022000100030002&quot;);', target: '_self'},
							{title: 'PS3/PSP Vita 소프트웨어', url: 'javascript:goCategorySpecList(&quot;C022000100030003&quot;);', target: '_self'},
							{title: 'XBOX 소프트웨어', url: 'javascript:goCategorySpecList(&quot;C022000100030004&quot;);', target: '_self'}
						]
					},
					{
						title: '닌텐도/비디오게임액세서리', url: 'javascript:goCategorySpecList(&quot;C02200010004&SITELOC=LL097&quot;);', target: '_self',
						subMenu: [
							{title: 'Wii 액세서리', url: 'javascript:goCategorySpecList(&quot;C022000100040001&quot;);', target: '_self'},
							{title: '3DS/DSi 액세서리', url: 'javascript:goCategorySpecList(&quot;C022000100040002&quot;);', target: '_self'},
							{title: ' PS3/PSP Vita 액세서리', url: 'javascript:goCategorySpecList(&quot;C022000100040003&quot;);', target: '_self'},
							{title: 'XBOX 액세서리', url: 'javascript:goCategorySpecList(&quot;C022000100040004&quot;);', target: '_self'}
						]
					},
					{
						title: 'PC게임', url: 'javascript:goCategorySpecList(&quot;C02200010005&SITELOC=LL098&quot;);', target: '_self',
						subMenu: [
							{title: 'PC게임', url: 'javascript:goCategorySpecList(&quot;C022000100050001&quot;);', target: '_self'}
						]
					},
					{
						title: '전자교육장난감', url: 'javascript:goCategorySpecList(&quot;C02200020002&SITELOC=LL099&quot;);', target: '_self',
						subMenu: [
							{title: '미미월드조이업', url: 'javascript:goCategorySpecList(&quot;C022000200020001&quot;);', target: '_self'},
							{title: '립프로그', url: 'javascript:goCategorySpecList(&quot;C022000200020002&quot;);', target: '_self'},
							{title: '피아이사운드', url: 'javascript:goCategorySpecList(&quot;C022000200020003&quot;);', target: '_self'},
							{title: '퓨처북', url: 'javascript:goCategorySpecList(&quot;C022000200020004&quot;);', target: '_self'}
						]
					},
					{
						title: '레고/블록장난감', url: 'javascript:goCategorySpecList(&quot;C02200020003&SITELOC=LL100&quot;);', target: '_self',
						subMenu: [
							{title: '레고', url: 'javascript:goCategorySpecList(&quot;C022000200030001&quot;);', target: '_self'},
							{title: '메가블럭', url: 'javascript:goCategorySpecList(&quot;C022000200030002&quot;);', target: '_self'},
							{title: '플레이모빌', url: 'javascript:goCategorySpecList(&quot;C022000200030003&quot;);', target: '_self'},
							{title: '옥스포드', url: 'javascript:goCategorySpecList(&quot;C022000200030004&quot;);', target: '_self'},
							{title: '크레오', url: 'javascript:goCategorySpecList(&quot;C022000200030005&quot;);', target: '_self'},
							{title: '기타블록장난감', url: 'javascript:goCategorySpecList(&quot;C022000200030006&quot;);', target: '_self'}
						]
					},
					{
						title: '클레이/미술/과학/창작장난감', url: 'javascript:goCategorySpecList(&quot;C02200020004&SITELOC=LL101&quot;);', target: '_self',
						subMenu: [
							{title: '크레욜라', url: 'javascript:goCategorySpecList(&quot;C022000200040001&quot;);', target: '_self'},
							{title: '과학교구', url: 'javascript:goCategorySpecList(&quot;C022000200040002&quot;);', target: '_self'},
							{title: '캐릭터학용품', url: 'javascript:goCategorySpecList(&quot;C022000200040009&quot;);', target: '_self'},
							{title: '보드판/이젤', url: 'javascript:goCategorySpecList(&quot;C022000200040004&quot;);', target: '_self'},
							{title: '플레이도우', url: 'javascript:goCategorySpecList(&quot;C022000200040005&quot;);', target: '_self'},
							{title: '일반점토(클레이)', url: 'javascript:goCategorySpecList(&quot;C022000200040006&quot;);', target: '_self'},
							{title: '축소모델', url: 'javascript:goCategorySpecList(&quot;C022000200040003&quot;);', target: '_self'}
						]
					},
					{
						title: '보드/퍼즐게임', url: 'javascript:goCategorySpecList(&quot;C02200020005&SITELOC=LL102&quot;);', target: '_self',
						subMenu: [
							{title: '보드게임', url: 'javascript:goCategorySpecList(&quot;C022000200050001&quot;);', target: '_self'},
							{title: '클래식보드게임', url: 'javascript:goCategorySpecList(&quot;C022000200050002&quot;);', target: '_self'},
							{title: '퍼즐장난감', url: 'javascript:goCategorySpecList(&quot;C022000200050003&quot;);', target: '_self'}
						]
					},
					{
						title: '캐릭터장난감', url: 'javascript:goCategorySpecList(&quot;C02200030001&SITELOC=LL103&quot;);', target: '_self',
						subMenu: [
							{title: '스파이더맨/어벤져스', url: 'javascript:goCategorySpecList(&quot;C022000300010016&quot;);', target: '_self'},
							{title: '메탈베이블레이드', url: 'javascript:goCategorySpecList(&quot;C022000300010002&quot;);', target: '_self'},
							{title: '베이4D', url: 'javascript:goCategorySpecList(&quot;C022000300010015&quot;);', target: '_self'},
							{title: '바쿠간BG', url: 'javascript:goCategorySpecList(&quot;C022000300010014&quot;);', target: '_self'},
							{title: '바쿠간2', url: 'javascript:goCategorySpecList(&quot;C022000300010013&quot;);', target: '_self'},
							{title: '바쿠간', url: 'javascript:goCategorySpecList(&quot;C022000300010009&quot;);', target: '_self'},
							{title: '또봇', url: 'javascript:goCategorySpecList(&quot;C022000300010003&quot;);', target: '_self'},
							{title: '블레이징틴스', url: 'javascript:goCategorySpecList(&quot;C022000300010006&quot;);', target: '_self'},
							{title: '골판지', url: 'javascript:goCategorySpecList(&quot;C022000300010008&quot;);', target: '_self'},
							{title: '파워레인저-해적전대/미라클포스', url: 'javascript:goCategorySpecList(&quot;C022000300010001&quot;);', target: '_self'},
							{title: '토이스토리', url: 'javascript:goCategorySpecList(&quot;C022000300010005&quot;);', target: '_self'},
							{title: '카스/카2', url: 'javascript:goCategorySpecList(&quot;C022000300010007&quot;);', target: '_self'},
							{title: '가면라이더', url: 'javascript:goCategorySpecList(&quot;C022000300010010&quot;);', target: '_self'},
							{title: '포켓몬스터', url: 'javascript:goCategorySpecList(&quot;C022000300010011&quot;);', target: '_self'},
							{title: '트랜스포머', url: 'javascript:goCategorySpecList(&quot;C022000300010004&quot;);', target: '_self'},
							{title: '기타캐릭터장남감', url: 'javascript:goCategorySpecList(&quot;C022000300010012&quot;);', target: '_self'}
						]
					},
					{
						title: '자동차/기차장난감', url: 'javascript:goCategorySpecList(&quot;C02200030002&SITELOC=LL104&quot;);', target: '_self',
						subMenu: [
							{title: '토미카', url: 'javascript:goCategorySpecList(&quot;C022000300020001&quot;);', target: '_self'},
							{title: '프라레일', url: 'javascript:goCategorySpecList(&quot;C022000300020002&quot;);', target: '_self'},
							{title: '기차/기차세트', url: 'javascript:goCategorySpecList(&quot;C022000300020004&quot;);', target: '_self'},
							{title: '핫휠', url: 'javascript:goCategorySpecList(&quot;C022000300020005&quot;);', target: '_self'},
							{title: '기타자동차', url: 'javascript:goCategorySpecList(&quot;C022000300020010&quot;);', target: '_self'}
						]
					},
					{
						title: '무선조종장난감(RC)', url: 'javascript:goCategorySpecList(&quot;C02200030003&SITELOC=LL105&quot;);', target: '_self',
						subMenu: [
							{title: '실제자동차RC', url: 'javascript:goCategorySpecList(&quot;C022000300030001&quot;);', target: '_self'},
							{title: '일반자동차RC', url: 'javascript:goCategorySpecList(&quot;C022000300030002&quot;);', target: '_self'},
							{title: '무선조종헬기', url: 'javascript:goCategorySpecList(&quot;C022000300030003&quot;);', target: '_self'},
							{title: '기타무선조종장난감', url: 'javascript:goCategorySpecList(&quot;C022000300030004&quot;);', target: '_self'}
						]
					},
					{
						title: '조립식장난감/폼건', url: 'javascript:goCategorySpecList(&quot;C02200030004&SITELOC=LL106&quot;);', target: '_self',
						subMenu: [
							{title: '건담', url: 'javascript:goCategorySpecList(&quot;C022000300040001&quot;);', target: '_self'},
							{title: '프라모델', url: 'javascript:goCategorySpecList(&quot;C022000300040002&quot;);', target: '_self'},
							{title: '기타조립식장난감', url: 'javascript:goCategorySpecList(&quot;C022000300040003&quot;);', target: '_self'},
							{title: '너프', url: 'javascript:goCategorySpecList(&quot;C022000300040004&quot;);', target: '_self'},
							{title: '비비탄건/기타완구', url: 'javascript:goCategorySpecList(&quot;C022000300040005&quot;);', target: '_self'}
						]
					},
					{
						title: '실바니안패밀리/수집인형/공작놀이', url: 'javascript:goCategorySpecList(&quot;C02200040001&SITELOC=LL107&quot;);', target: '_self',
						subMenu: [
							{title: '실바니안패밀리', url: 'javascript:goCategorySpecList(&quot;C022000400010001&quot;);', target: '_self'},
							{title: '랄라룹시', url: 'javascript:goCategorySpecList(&quot;C022000400010002&quot;);', target: '_self'},
							{title: '뚱이', url: 'javascript:goCategorySpecList(&quot;C022000400010003&quot;);', target: '_self'},
							{title: '엔젤이', url: 'javascript:goCategorySpecList(&quot;C022000400010004&quot;);', target: '_self'},
							{title: '기타수집인형', url: 'javascript:goCategorySpecList(&quot;C022000400010005&quot;);', target: '_self'},
							{title: '기타공작놀이', url: 'javascript:goCategorySpecList(&quot;C022000400010006&quot;);', target: '_self'}
						]
					},
					{
						title: '똘똘이/달님이/콩순이/아기인형', url: 'javascript:goCategorySpecList(&quot;C02200040003&SITELOC=LL108&quot;);', target: '_self',
						subMenu: [
							{title: '똘똘이', url: 'javascript:goCategorySpecList(&quot;C022000400030001&quot;);', target: '_self'},
							{title: '달님이', url: 'javascript:goCategorySpecList(&quot;C022000400030002&quot;);', target: '_self'},
							{title: '콩순이', url: 'javascript:goCategorySpecList(&quot;C022000400030003&quot;);', target: '_self'},
							{title: '베이비얼라이브', url: 'javascript:goCategorySpecList(&quot;C022000400030004&quot;);', target: '_self'},
							{title: '베렝구어', url: 'javascript:goCategorySpecList(&quot;C022000400030005&quot;);', target: '_self'},
							{title: '기타아기인형', url: 'javascript:goCategorySpecList(&quot;C022000400030006&quot;);', target: '_self'}
						]
					},
					{
						title: '미미/바비/쥬쥬/패션인형/패션소품', url: 'javascript:goCategorySpecList(&quot;C02200040002&SITELOC=LL109&quot;);', target: '_self',
						subMenu: [
							{title: '미미/리틀미미', url: 'javascript:goCategorySpecList(&quot;C022000400020001&quot;);', target: '_self'},
							{title: '바비', url: 'javascript:goCategorySpecList(&quot;C022000400020002&quot;);', target: '_self'},
							{title: '디즈니', url: 'javascript:goCategorySpecList(&quot;C022000400020003&quot;);', target: '_self'},
							{title: '쥬쥬', url: 'javascript:goCategorySpecList(&quot;C022000400020004&quot;);', target: '_self'},
							{title: '챠밍걸스', url: 'javascript:goCategorySpecList(&quot;C022000400020005&quot;);', target: '_self'},
							{title: '헬로키티', url: 'javascript:goCategorySpecList(&quot;C022000400020006&quot;);', target: '_self'},
							{title: '기타패션인형', url: 'javascript:goCategorySpecList(&quot;C022000400020007&quot;);', target: '_self'},
							{title: '기타패션소품', url: 'javascript:goCategorySpecList(&quot;C022000400020008&quot;);', target: '_self'}
						]
					},
					{
						title: '역할놀이/봉제인형', url: 'javascript:goCategorySpecList(&quot;C02200040004&SITELOC=LL110&quot;);', target: '_self',
						subMenu: [
							{title: '주방놀이', url: 'javascript:goCategorySpecList(&quot;C022000400040001&quot;);', target: '_self'},
							{title: '소꿉놀이', url: 'javascript:goCategorySpecList(&quot;C022000400040002&quot;);', target: '_self'},
							{title: '기타역할놀이', url: 'javascript:goCategorySpecList(&quot;C022000400040008&quot;);', target: '_self'},
							{title: '앵그리버드', url: 'javascript:goCategorySpecList(&quot;C022000400040003&quot;);', target: '_self'},
							{title: '뽀로로인형', url: 'javascript:goCategorySpecList(&quot;C022000400040004&quot;);', target: '_self'},
							{title: '캐릭터인형', url: 'javascript:goCategorySpecList(&quot;C022000400040005&quot;);', target: '_self'},
							{title: '동물인형', url: 'javascript:goCategorySpecList(&quot;C022000400040006&quot;);', target: '_self'},
							{title: '작동인형', url: 'javascript:goCategorySpecList(&quot;C022000400040007&quot;);', target: '_self'}
						]
					},
					{
						title: '영유아장난감', url: 'javascript:goCategorySpecList(&quot;C02200050001&SITELOC=LL111&quot;);', target: '_self',
						subMenu: [
							{title: '피셔프라이스', url: 'javascript:goCategorySpecList(&quot;C022000500010001&quot;);', target: '_self'},
							{title: '리틀타익스', url: 'javascript:goCategorySpecList(&quot;C022000500010002&quot;);', target: '_self'},
							{title: '브이텍', url: 'javascript:goCategorySpecList(&quot;C022000500010003&quot;);', target: '_self'},
							{title: '플레이스쿨', url: 'javascript:goCategorySpecList(&quot;C022000500010004&quot;);', target: '_self'},
							{title: '맨하탄토이즈', url: 'javascript:goCategorySpecList(&quot;C022000500010005&quot;);', target: '_self'},
							{title: '치코', url: 'javascript:goCategorySpecList(&quot;C022000500010006&quot;);', target: '_self'},
							{title: '디즈니', url: 'javascript:goCategorySpecList(&quot;C022000500010007&quot;);', target: '_self'},
							{title: '톨로(TOLO)', url: 'javascript:goCategorySpecList(&quot;C022000500010008&quot;);', target: '_self'},
							{title: '라마즈', url: 'javascript:goCategorySpecList(&quot;C022000500010010&quot;);', target: '_self'},
							{title: '플레이그로', url: 'javascript:goCategorySpecList(&quot;C022000500010011&quot;);', target: '_self'},
							{title: '투모로우', url: 'javascript:goCategorySpecList(&quot;C022000500010012&quot;);', target: '_self'},
							{title: '케이스키즈', url: 'javascript:goCategorySpecList(&quot;C022000500010013&quot;);', target: '_self'},
							{title: '브라이트스타트', url: 'javascript:goCategorySpecList(&quot;C022000500010016&quot;);', target: '_self'},
							{title: '짐보리', url: 'javascript:goCategorySpecList(&quot;C022000500010017&quot;);', target: '_self'},
							{title: '기타브랜드장난감', url: 'javascript:goCategorySpecList(&quot;C022000500010015&quot;);', target: '_self'}
						]
					},
					{
						title: '캐릭터장난감', url: 'javascript:goCategorySpecList(&quot;C02200050002&SITELOC=LL112&quot;);', target: '_self',
						subMenu: [
							{title: '뽀로로', url: 'javascript:goCategorySpecList(&quot;C022000500020001&quot;);', target: '_self'},
							{title: '타요', url: 'javascript:goCategorySpecList(&quot;C022000500020002&quot;);', target: '_self'},
							{title: '로보카폴리', url: 'javascript:goCategorySpecList(&quot;C022000500020003&quot;);', target: '_self'},
							{title: '토마스', url: 'javascript:goCategorySpecList(&quot;C022000500020004&quot;);', target: '_self'},
							{title: '코코몽', url: 'javascript:goCategorySpecList(&quot;C022000500020005&quot;);', target: '_self'},
							{title: '기타캐릭터완구', url: 'javascript:goCategorySpecList(&quot;C022000500020006&quot;);', target: '_self'}
						]
					},
					{
						title: '기타유아장난감', url: 'javascript:goCategorySpecList(&quot;C02200050004&SITELOC=LL113&quot;);', target: '_self',
						subMenu: [
							{title: '기타유아장난감', url: 'javascript:goCategorySpecList(&quot;C022000500040001&quot;);', target: '_self'}
						]
					},
					{
						title: '볼풀/플레이하우스', url: 'javascript:goCategorySpecList(&quot;C02200070001&SITELOC=LL114&quot;);', target: '_self',
						subMenu: [
							{title: '볼풀/볼텐트', url: 'javascript:goCategorySpecList(&quot;C022000700010001&quot;);', target: '_self'},
							{title: '놀이집/플레이세트', url: 'javascript:goCategorySpecList(&quot;C022000700010004&quot;);', target: '_self'}
						]
					},
					{
						title: '승용완구', url: 'javascript:goCategorySpecList(&quot;C02200070006&SITELOC=LL115&quot;);', target: '_self',
						subMenu: [
							{title: '자전거', url: 'javascript:goCategorySpecList(&quot;C022000700060001&quot;);', target: '_self'},
							{title: '킥보드/씽씽이', url: 'javascript:goCategorySpecList(&quot;C022000700060002&quot;);', target: '_self'},
							{title: '붕붕카/지붕차', url: 'javascript:goCategorySpecList(&quot;C022000700060003&quot;);', target: '_self'},
							{title: '전동자동차/오토바이', url: 'javascript:goCategorySpecList(&quot;C022000700060004&quot;);', target: '_self'},
							{title: '웨곤', url: 'javascript:goCategorySpecList(&quot;C022000700060005&quot;);', target: '_self'},
							{title: '시소/흔들말', url: 'javascript:goCategorySpecList(&quot;C022000700060006&quot;);', target: '_self'},
							{title: '그네', url: 'javascript:goCategorySpecList(&quot;C022000700060007&quot;);', target: '_self'},
							{title: '놀이터/체육관', url: 'javascript:goCategorySpecList(&quot;C022000700060008&quot;);', target: '_self'},
							{title: '미끄럼틀', url: 'javascript:goCategorySpecList(&quot;C022000700060009&quot;);', target: '_self'}
						]
					},
					{
						title: '스포츠장난감', url: 'javascript:goCategorySpecList(&quot;C02200070002&SITELOC=LL116&quot;);', target: '_self',
						subMenu: [
							{title: '스포츠용품', url: 'javascript:goCategorySpecList(&quot;C022000700020001&quot;);', target: '_self'},
							{title: '스포츠장난감', url: 'javascript:goCategorySpecList(&quot;C022000700020002&quot;);', target: '_self'},
							{title: '농구대', url: 'javascript:goCategorySpecList(&quot;C022000700020004&quot;);', target: '_self'},
							{title: '야구/공놀이', url: 'javascript:goCategorySpecList(&quot;C022000700020003&quot;);', target: '_self'}
						]
					},
					{
						title: '비눗방울/파티용품', url: 'javascript:goCategorySpecList(&quot;C02200070005&SITELOC=LL117&quot;);', target: '_self',
						subMenu: [
							{title: '비눗방울', url: 'javascript:goCategorySpecList(&quot;C022000700050001&quot;);', target: '_self'},
							{title: '할로윈', url: 'javascript:goCategorySpecList(&quot;C022000700030001&quot;);', target: '_self'},
							{title: '파티용품', url: 'javascript:goCategorySpecList(&quot;C022000700030002&quot;);', target: '_self'}
						]
					},
					{
						title: '스킨케어/목욕/위생용품', url: 'javascript:goCategorySpecList(&quot;C02200060001&SITELOC=LL118&quot;);', target: '_self',
						subMenu: [
							{title: '비누/샴푸/바스', url: 'javascript:goCategorySpecList(&quot;C022000600010001&quot;);', target: '_self'},
							{title: '바디케어(크림/오일/로션)', url: 'javascript:goCategorySpecList(&quot;C022000600010002&quot;);', target: '_self'},
							{title: '세면대/욕조', url: 'javascript:goCategorySpecList(&quot;C022000600010003&quot;);', target: '_self'},
							{title: '목욕완구', url: 'javascript:goCategorySpecList(&quot;C022000600010004&quot;);', target: '_self'},
							{title: '기타목욕용품(스펀지/샴푸캡)', url: 'javascript:goCategorySpecList(&quot;C022000600010005&quot;);', target: '_self'},
							{title: '변기', url: 'javascript:goCategorySpecList(&quot;C022000600010006&quot;);', target: '_self'},
							{title: '칫솔/치약', url: 'javascript:goCategorySpecList(&quot;C022000600010007&quot;);', target: '_self'},
							{title: '구강/위생티슈', url: 'javascript:goCategorySpecList(&quot;C022000600010008&quot;);', target: '_self'},
							{title: '기타위생용품', url: 'javascript:goCategorySpecList(&quot;C022000600010009&quot;);', target: '_self'}
						]
					}
				]
			},
			{
				title: '가전', url: '/indexDig.do?SITELOC=LL119', target: '_self',
				subMenu: [
					{
						title: '카메라/캠코더', url: 'javascript:goCategorySpecList(&quot;C02100010001&SITELOC=LL120&quot;);', target: '_self',
						subMenu: [
							{title: 'DSLR카메라', url: 'javascript:goCategorySpecList(&quot;C021000100010001&quot;);', target: '_self'},
							{title: '컴팩트카메라', url: 'javascript:goCategorySpecList(&quot;C021000100010002&quot;);', target: '_self'},
							{title: '하이브리드카메라', url: 'javascript:goCategorySpecList(&quot;C021000100010003&quot;);', target: '_self'},
							{title: '인스탁스/토이카메라', url: 'javascript:goCategorySpecList(&quot;C021000100010004&quot;);', target: '_self'},
							{title: '캠코더', url: 'javascript:goCategorySpecList(&quot;C021000100010005&quot;);', target: '_self'},
							{title: 'SONY', url: 'javascript:goCategorySpecList(&quot;C021000100010008&quot;);', target: '_self'},
							{title: 'NIKON', url: 'javascript:goCategorySpecList(&quot;C021000100010007&quot;);', target: '_self'},
							{title: 'CANON', url: 'javascript:goCategorySpecList(&quot;C021000100010006&quot;);', target: '_self'}
						]
					},
					{
						title: '카메라/캠코더 악세서리', url: 'javascript:goCategorySpecList(&quot;C02100010002&SITELOC=LL121&quot;);', target: '_self',
						subMenu: [
							{title: '삼각대', url: 'javascript:goCategorySpecList(&quot;C021000100020001&quot;);', target: '_self'},
							{title: '가방', url: 'javascript:goCategorySpecList(&quot;C021000100020002&quot;);', target: '_self'},
							{title: 'SD/CF메모리카드', url: 'javascript:goCategorySpecList(&quot;C021000100020003&quot;);', target: '_self'},
							{title: '플래쉬', url: 'javascript:goCategorySpecList(&quot;C021000100020004&quot;);', target: '_self'},
							{title: '렌즈', url: 'javascript:goCategorySpecList(&quot;C021000100020005&quot;);', target: '_self'},
							{title: '카메라소품', url: 'javascript:goCategorySpecList(&quot;C021000100020006&quot;);', target: '_self'},
							{title: '쌍안경/망원경', url: 'javascript:goCategorySpecList(&quot;C021000100020007&quot;);', target: '_self'},
							{title: '캠코더소품', url: 'javascript:goCategorySpecList(&quot;C021000100020008&quot;);', target: '_self'}
						]
					},
					{
						title: '컴퓨터', url: 'javascript:goCategorySpecList(&quot;C02100020001&SITELOC=LL122&quot;);', target: '_self',
						subMenu: [
							{title: '데스크탑/일체형PC', url: 'javascript:goCategorySpecList(&quot;C021000200010001&quot;);', target: '_self'},
							{title: '애플-MAC', url: 'javascript:goCategorySpecList(&quot;C021000200010002&quot;);', target: '_self'},
							{title: '데스크탑-삼성/LG', url: 'javascript:goCategorySpecList(&quot;C021000200010003&quot;);', target: '_self'},
							{title: '데스크탑-HP', url: 'javascript:goCategorySpecList(&quot;C021000200010004&quot;);', target: '_self'},
							{title: '데스크탑-LENOVO', url: 'javascript:goCategorySpecList(&quot;C021000200010005&quot;);', target: '_self'},
							{title: '데스크탑-DELL', url: 'javascript:goCategorySpecList(&quot;C021000200010007&quot;);', target: '_self'},
							{title: '데스크탑-ACER', url: 'javascript:goCategorySpecList(&quot;C021000200010008&quot;);', target: '_self'}
						]
					},
					{
						title: '노트북/태블릿', url: 'javascript:goCategorySpecList(&quot;C02100020009&SITELOC=LL123&quot;);', target: '_self',
						subMenu: [
							{title: '노트북/테블릿', url: 'javascript:goCategorySpecList(&quot;C021000200090001&quot;);', target: '_self'},
							{title: '노트북-애플', url: 'javascript:goCategorySpecList(&quot;C021000200090002&quot;);', target: '_self'},
							{title: '노트북-삼성/LG', url: 'javascript:goCategorySpecList(&quot;C021000200090003&quot;);', target: '_self'},
							{title: '노트북-HP', url: 'javascript:goCategorySpecList(&quot;C021000200090004&quot;);', target: '_self'},
							{title: '노트북-LENOVO', url: 'javascript:goCategorySpecList(&quot;C021000200090005&quot;);', target: '_self'},
							{title: '노트북-ASUS', url: 'javascript:goCategorySpecList(&quot;C021000200090006&quot;);', target: '_self'},
							{title: '노트북-DELL', url: 'javascript:goCategorySpecList(&quot;C021000200090007&quot;);', target: '_self'},
							{title: '노트북-도시바', url: 'javascript:goCategorySpecList(&quot;C021000200090008&quot;);', target: '_self'},
							{title: '노트북-MSI', url: 'javascript:goCategorySpecList(&quot;C021000200090009&quot;);', target: '_self'},
							{title: '노트북-VAIO', url: 'javascript:goCategorySpecList(&quot;C021000200090010&quot;);', target: '_self'}
						]
					},
					{
						title: '모니터/복합기/프린터', url: 'javascript:goCategorySpecList(&quot;C02100020003&SITELOC=LL124&quot;);', target: '_self',
						subMenu: [
							{title: '모니터', url: 'javascript:goCategorySpecList(&quot;C021000200030001&quot;);', target: '_self'},
							{title: 'HMD', url: 'javascript:goCategorySpecList(&quot;C021000200030006&quot;);', target: '_self'},
							{title: '프린터', url: 'javascript:goCategorySpecList(&quot;C021000200030002&quot;);', target: '_self'},
							{title: '복합기', url: 'javascript:goCategorySpecList(&quot;C021000200030003&quot;);', target: '_self'},
							{title: '잉크', url: 'javascript:goCategorySpecList(&quot;C021000200030004&quot;);', target: '_self'},
							{title: '토너', url: 'javascript:goCategorySpecList(&quot;C021000200030005&quot;);', target: '_self'},
							{title: '세절기', url: 'javascript:goCategorySpecList(&quot;C021000200030007&quot;);', target: '_self'}
						]
					},
					{
						title: '키보드/마우스', url: 'javascript:goCategorySpecList(&quot;C02100020004&SITELOC=LL125&quot;);', target: '_self',
						subMenu: [
							{title: '키보드+마우스세트', url: 'javascript:goCategorySpecList(&quot;C021000200040001&quot;);', target: '_self'},
							{title: '유선키보드', url: 'javascript:goCategorySpecList(&quot;C021000200040002&quot;);', target: '_self'},
							{title: '무선키보드', url: 'javascript:goCategorySpecList(&quot;C021000200040003&quot;);', target: '_self'},
							{title: '유선마우스', url: 'javascript:goCategorySpecList(&quot;C021000200040004&quot;);', target: '_self'},
							{title: '무선마우스', url: 'javascript:goCategorySpecList(&quot;C021000200040005&quot;);', target: '_self'},
							{title: '블루투스마우스', url: 'javascript:goCategorySpecList(&quot;C021000200040006&quot;);', target: '_self'},
							{title: '마우스패드', url: 'javascript:goCategorySpecList(&quot;C021000200040007&quot;);', target: '_self'}
						]
					},
					{
						title: 'USB/외장하드/공CD', url: 'javascript:goCategorySpecList(&quot;C02100020005&SITELOC=LL126&quot;);', target: '_self',
						subMenu: [
							{title: 'USB', url: 'javascript:goCategorySpecList(&quot;C021000200050001&quot;);', target: '_self'},
							{title: '외장하드', url: 'javascript:goCategorySpecList(&quot;C021000200050002&quot;);', target: '_self'},
							{title: '공CD', url: 'javascript:goCategorySpecList(&quot;C021000200050003&quot;);', target: '_self'}
						]
					},
					{
						title: '공유기/네트워크', url: 'javascript:goCategorySpecList(&quot;C02100020006&SITELOC=LL127&quot;);', target: '_self',
						subMenu: [
							{title: '공유기', url: 'javascript:goCategorySpecList(&quot;C021000200060001&quot;);', target: '_self'},
							{title: '랜카드', url: 'javascript:goCategorySpecList(&quot;C021000200060002&quot;);', target: '_self'},
							{title: '허브', url: 'javascript:goCategorySpecList(&quot;C021000200060003&quot;);', target: '_self'},
							{title: '케이블', url: 'javascript:goCategorySpecList(&quot;C021000200060004&quot;);', target: '_self'},
							{title: '멀티탭', url: 'javascript:goCategorySpecList(&quot;C021000200060005&quot;);', target: '_self'}
						]
					},
					{
						title: '스피커/헤드셋/이어셋', url: 'javascript:goCategorySpecList(&quot;C02100020007&SITELOC=LL128&quot;);', target: '_self',
						subMenu: [
							{title: '스피커', url: 'javascript:goCategorySpecList(&quot;C021000200070001&quot;);', target: '_self'},
							{title: '도킹스피커', url: 'javascript:goCategorySpecList(&quot;C021000200070004&quot;);', target: '_self'},
							{title: '헤드셋', url: 'javascript:goCategorySpecList(&quot;C021000200070002&quot;);', target: '_self'},
							{title: '이어셋', url: 'javascript:goCategorySpecList(&quot;C021000200070003&quot;);', target: '_self'}
						]
					},
					{
						title: '노트북주변용품', url: 'javascript:goCategorySpecList(&quot;C02100020008&SITELOC=LL129&quot;);', target: '_self',
						subMenu: [
							{title: '노트북용가방/파우치', url: 'javascript:goCategorySpecList(&quot;C021000200080001&quot;);', target: '_self'},
							{title: '보안기(액정보호)', url: 'javascript:goCategorySpecList(&quot;C021000200080002&quot;);', target: '_self'}
						]
					},
					{
						title: '컴퓨터주변기기', url: 'javascript:goCategorySpecList(&quot;C02100020002&SITELOC=LL130&quot;);', target: '_self',
						subMenu: [
							{title: '카드리더기', url: 'javascript:goCategorySpecList(&quot;C021000200020001&quot;);', target: '_self'},
							{title: '화상카메라', url: 'javascript:goCategorySpecList(&quot;C021000200020019&quot;);', target: '_self'},
							{title: '보안기', url: 'javascript:goCategorySpecList(&quot;C021000200020020&quot;);', target: '_self'},
							{title: '컴퓨터소품', url: 'javascript:goCategorySpecList(&quot;C021000200020021&quot;);', target: '_self'}
						]
					},
					{
						title: '네비게이션/하이패스', url: 'javascript:goCategorySpecList(&quot;C02100030001&SITELOC=LL131&quot;);', target: '_self',
						subMenu: [
							{title: '네비게이션', url: 'javascript:goCategorySpecList(&quot;C021000300010001&quot;);', target: '_self'},
							{title: '하이패스/블랙박스', url: 'javascript:goCategorySpecList(&quot;C021000300010002&quot;);', target: '_self'}
						]
					},
					{
						title: 'MP3/PMP/전자사전', url: 'javascript:goCategorySpecList(&quot;C02100030002&SITELOC=LL132&quot;);', target: '_self',
						subMenu: [
							{title: 'MP3', url: 'javascript:goCategorySpecList(&quot;C021000300020001&quot;);', target: '_self'},
							{title: 'PMP', url: 'javascript:goCategorySpecList(&quot;C021000300020002&quot;);', target: '_self'},
							{title: '어학학습기/전자사전', url: 'javascript:goCategorySpecList(&quot;C021000300020003&quot;);', target: '_self'},
							{title: '아이팟', url: 'javascript:goCategorySpecList(&quot;C021000300020004&quot;);', target: '_self'}
						]
					},
					{
						title: '오디오/라디오/이어폰', url: 'javascript:goCategorySpecList(&quot;C02100030003&SITELOC=LL133&quot;);', target: '_self',
						subMenu: [
							{title: '라디오/녹음기', url: 'javascript:goCategorySpecList(&quot;C021000300030001&quot;);', target: '_self'},
							{title: '이어폰', url: 'javascript:goCategorySpecList(&quot;C021000300030002&quot;);', target: '_self'},
							{title: '헤드폰', url: 'javascript:goCategorySpecList(&quot;C021000300030003&quot;);', target: '_self'},
							{title: '블루투스', url: 'javascript:goCategorySpecList(&quot;C021000300030004&quot;);', target: '_self'},
							{title: '오디오/카세트', url: 'javascript:goCategorySpecList(&quot;C021000300030005&quot;);', target: '_self'},
							{title: '전자악기', url: 'javascript:goCategorySpecList(&quot;C021000300030006&quot;);', target: '_self'}
						]
					},
					{
						title: '비디오게임기/게임', url: 'javascript:goCategorySpecList(&quot;C02100030004&SITELOC=LL134&quot;);', target: '_self',
						subMenu: [
							{title: 'Wii', url: 'javascript:goCategorySpecList(&quot;C021000300040001&quot;);', target: '_self'},
							{title: '3DS/DSi', url: 'javascript:goCategorySpecList(&quot;C021000300040002&quot;);', target: '_self'},
							{title: 'PS3/PSP Vita', url: 'javascript:goCategorySpecList(&quot;C021000300040003&quot;);', target: '_self'},
							{title: 'XBOX', url: 'javascript:goCategorySpecList(&quot;C021000300040004&quot;);', target: '_self'},
							{title: 'Wii 소프트웨어', url: 'javascript:goCategorySpecList(&quot;C021000300040005&quot;);', target: '_self'},
							{title: '3DS/DSi 소프트웨어', url: 'javascript:goCategorySpecList(&quot;C021000300040006&quot;);', target: '_self'},
							{title: 'PS3/PSP Vita 소프트웨어', url: 'javascript:goCategorySpecList(&quot;C021000300040007&quot;);', target: '_self'},
							{title: 'XBOX 소프트웨어', url: 'javascript:goCategorySpecList(&quot;C021000300040008&quot;);', target: '_self'},
							{title: 'Wii 액세서리', url: 'javascript:goCategorySpecList(&quot;C021000300040009&quot;);', target: '_self'},
							{title: '3DS/DSi 액세서리', url: 'javascript:goCategorySpecList(&quot;C021000300040010&quot;);', target: '_self'},
							{title: 'PS3/PSP Vita 액세서리', url: 'javascript:goCategorySpecList(&quot;C021000300040011&quot;);', target: '_self'},
							{title: 'XBOX 액세서리', url: 'javascript:goCategorySpecList(&quot;C021000300040012&quot;);', target: '_self'},
							{title: 'PC게임', url: 'javascript:goCategorySpecList(&quot;C021000300040013&quot;);', target: '_self'}
						]
					},
					{
						title: '갤럭시탭 악세서리', url: 'javascript:goCategorySpecList(&quot;C02100040001&SITELOC=LL135&quot;);', target: '_self',
						subMenu: [
							{title: '갤럭시탭케이스', url: 'javascript:goCategorySpecList(&quot;C021000400010002&quot;);', target: '_self'},
							{title: '갤럭시탭보호필름', url: 'javascript:goCategorySpecList(&quot;C021000400010003&quot;);', target: '_self'}
						]
					},
					{
						title: '아이패드 악세서리', url: 'javascript:goCategorySpecList(&quot;C02100040002&SITELOC=LL136&quot;);', target: '_self',
						subMenu: [
							{title: '아이패드케이스', url: 'javascript:goCategorySpecList(&quot;C021000400020002&quot;);', target: '_self'},
							{title: '아이패드보호필름', url: 'javascript:goCategorySpecList(&quot;C021000400020003&quot;);', target: '_self'}
						]
					},
					{
						title: '갤럭시S 악세서리', url: 'javascript:goCategorySpecList(&quot;C02100040003&SITELOC=LL137&quot;);', target: '_self',
						subMenu: [
							{title: '갤럭시S III LTE 케이스', url: 'javascript:goCategorySpecList(&quot;C021000400030005&quot;);', target: '_self'},
							{title: '갤럭시S III 3G 케이스', url: 'javascript:goCategorySpecList(&quot;C021000400030004&quot;);', target: '_self'},
							{title: '갤럭시S케이스', url: 'javascript:goCategorySpecList(&quot;C021000400030002&quot;);', target: '_self'},
							{title: '캘럭시S보호필름', url: 'javascript:goCategorySpecList(&quot;C021000400030003&quot;);', target: '_self'}
						]
					},
					{
						title: '아이폰 악세서리', url: 'javascript:goCategorySpecList(&quot;C02100040004&SITELOC=LL138&quot;);', target: '_self',
						subMenu: [
							{title: '아이폰케이스', url: 'javascript:goCategorySpecList(&quot;C021000400040002&quot;);', target: '_self'},
							{title: '아이폰보호필름', url: 'javascript:goCategorySpecList(&quot;C021000400040003&quot;);', target: '_self'}
						]
					},
					{
						title: '갤럭시노트 악세서리', url: 'javascript:goCategorySpecList(&quot;C02100040008&SITELOC=LL139&quot;);', target: '_self',
						subMenu: [
							{title: '갤럭시노트케이스', url: 'javascript:goCategorySpecList(&quot;C021000400080002&quot;);', target: '_self'},
							{title: '갤럭시노트보호필름', url: 'javascript:goCategorySpecList(&quot;C021000400080003&quot;);', target: '_self'}
						]
					},
					{
						title: '기타휴대폰 악세서리', url: 'javascript:goCategorySpecList(&quot;C02100040005&SITELOC=LL140&quot;);', target: '_self',
						subMenu: [
							{title: '휴대폰케이스', url: 'javascript:goCategorySpecList(&quot;C021000400050002&quot;);', target: '_self'},
							{title: '휴대폰보호필름', url: 'javascript:goCategorySpecList(&quot;C021000400050003&quot;);', target: '_self'}
						]
					},
					{
						title: '스트랩/블루투스/기타', url: 'javascript:goCategorySpecList(&quot;C02100040006&SITELOC=LL141&quot;);', target: '_self',
						subMenu: [
							{title: '스트랩', url: 'javascript:goCategorySpecList(&quot;C021000400060001&quot;);', target: '_self'},
							{title: '블루투스', url: 'javascript:goCategorySpecList(&quot;C021000400060002&quot;);', target: '_self'},
							{title: '도킹', url: 'javascript:goCategorySpecList(&quot;C021000400060003&quot;);', target: '_self'},
							{title: '거치대/악세서리', url: 'javascript:goCategorySpecList(&quot;C021000400060004&quot;);', target: '_self'},
							{title: '테블릿 PC 키보드/기타', url: 'javascript:goCategorySpecList(&quot;C021000400060005&quot;);', target: '_self'}
						]
					},
					{
						title: '이어폰/충전기', url: 'javascript:goCategorySpecList(&quot;C02100040007&SITELOC=LL142&quot;);', target: '_self',
						subMenu: [
							{title: '이어폰', url: 'javascript:goCategorySpecList(&quot;C021000400070001&quot;);', target: '_self'},
							{title: '헤드폰', url: 'javascript:goCategorySpecList(&quot;C021000400070002&quot;);', target: '_self'},
							{title: '충전기/케이블', url: 'javascript:goCategorySpecList(&quot;C021000400070003&quot;);', target: '_self'}
						]
					},
					{
						title: '밥솥', url: 'javascript:goCategorySpecList(&quot;C02100050009&SITELOC=LL143&quot;);', target: '_self',
						subMenu: [
							{title: '압력밥솥', url: 'javascript:goCategorySpecList(&quot;C021000500090001&quot;);', target: '_self'},
							{title: 'IH압력밥솥', url: 'javascript:goCategorySpecList(&quot;C021000500090002&quot;);', target: '_self'}
						]
					},
					{
						title: '가스/오븐/전자레인지', url: 'javascript:goCategorySpecList(&quot;C02100050012&SITELOC=LL144&quot;);', target: '_self',
						subMenu: [
							{title: '가스레인지', url: 'javascript:goCategorySpecList(&quot;C021000500120001&quot;);', target: '_self'},
							{title: '가스오븐레인지', url: 'javascript:goCategorySpecList(&quot;C021000500120002&quot;);', target: '_self'},
							{title: '전자레인지', url: 'javascript:goCategorySpecList(&quot;C021000500120003&quot;);', target: '_self'},
							{title: '전기레인지', url: 'javascript:goCategorySpecList(&quot;C021000500120004&quot;);', target: '_self'},
							{title: '광파오븐레인지', url: 'javascript:goCategorySpecList(&quot;C021000500120005&quot;);', target: '_self'}
						]
					},
					{
						title: '커피메이커/주전자', url: 'javascript:goCategorySpecList(&quot;C02100050010&SITELOC=LL145&quot;);', target: '_self',
						subMenu: [
							{title: '커피메이커', url: 'javascript:goCategorySpecList(&quot;C021000500100001&quot;);', target: '_self'},
							{title: '커피머신', url: 'javascript:goCategorySpecList(&quot;C021000500100002&quot;);', target: '_self'},
							{title: '주전자-전기포트/라면포트', url: 'javascript:goCategorySpecList(&quot;C021000500100003&quot;);', target: '_self'}
						]
					},
					{
						title: '녹즙기/믹서기', url: 'javascript:goCategorySpecList(&quot;C02100050011&SITELOC=LL146&quot;);', target: '_self',
						subMenu: [
							{title: '녹즙기', url: 'javascript:goCategorySpecList(&quot;C021000500110002&quot;);', target: '_self'},
							{title: '믹서기', url: 'javascript:goCategorySpecList(&quot;C021000500110003&quot;);', target: '_self'},
							{title: '핸드블랜더', url: 'javascript:goCategorySpecList(&quot;C021000500110004&quot;);', target: '_self'},
							{title: '약탕기/중탕기', url: 'javascript:goCategorySpecList(&quot;C021000500110001&quot;);', target: '_self'}
						]
					},
					{
						title: '주방가전', url: 'javascript:goCategorySpecList(&quot;C02100050002&SITELOC=LL147&quot;);', target: '_self',
						subMenu: [
							{title: '토스터기', url: 'javascript:goCategorySpecList(&quot;C021000500020003&quot;);', target: '_self'},
							{title: '제빵기/쿠커', url: 'javascript:goCategorySpecList(&quot;C021000500020008&quot;);', target: '_self'},
							{title: '전기팬/그릴', url: 'javascript:goCategorySpecList(&quot;C021000500020009&quot;);', target: '_self'},
							{title: '건조기/식기세척기', url: 'javascript:goCategorySpecList(&quot;C021000500020012&quot;);', target: '_self'}
						]
					},
					{
						title: '면도기', url: 'javascript:goCategorySpecList(&quot;C02100050008&SITELOC=LL148&quot;);', target: '_self',
						subMenu: [
							{title: '면도기', url: 'javascript:goCategorySpecList(&quot;C021000500080001&quot;);', target: '_self'},
							{title: '면도기악세서리', url: 'javascript:goCategorySpecList(&quot;C021000500080002&quot;);', target: '_self'}
						]
					},
					{
						title: '드라이어/고데기/피부미용', url: 'javascript:goCategorySpecList(&quot;C02100050007&SITELOC=LL149&quot;);', target: '_self',
						subMenu: [
							{title: '드라이어', url: 'javascript:goCategorySpecList(&quot;C021000500070001&quot;);', target: '_self'},
							{title: '고데기', url: 'javascript:goCategorySpecList(&quot;C021000500070002&quot;);', target: '_self'},
							{title: '피부미용', url: 'javascript:goCategorySpecList(&quot;C021000500070003&quot;);', target: '_self'}
						]
					},
					{
						title: '공기청정기/청소기', url: 'javascript:goCategorySpecList(&quot;C02100050006&SITELOC=LL150&quot;);', target: '_self',
						subMenu: [
							{title: '공기청정기', url: 'javascript:goCategorySpecList(&quot;C021000500060001&quot;);', target: '_self'},
							{title: '일반형청소기', url: 'javascript:goCategorySpecList(&quot;C021000500060002&quot;);', target: '_self'},
							{title: '로봇청소기', url: 'javascript:goCategorySpecList(&quot;C021000500060003&quot;);', target: '_self'},
							{title: '핸디형청소기', url: 'javascript:goCategorySpecList(&quot;C021000500060004&quot;);', target: '_self'},
							{title: '침구청소기', url: 'javascript:goCategorySpecList(&quot;C021000500060005&quot;);', target: '_self'},
							{title: '업소용청소기', url: 'javascript:goCategorySpecList(&quot;C021000500060006&quot;);', target: '_self'},
							{title: '스팀청소기', url: 'javascript:goCategorySpecList(&quot;C021000500060009&quot;);', target: '_self'},
							{title: '청소기소품', url: 'javascript:goCategorySpecList(&quot;C021000500060010&quot;);', target: '_self'},
							{title: '제균기', url: 'javascript:goCategorySpecList(&quot;C021000500060007&quot;);', target: '_self'},
							{title: '에어워셔', url: 'javascript:goCategorySpecList(&quot;C021000500060008&quot;);', target: '_self'}
						]
					},
					{
						title: '생활가전', url: 'javascript:goCategorySpecList(&quot;C02100050001&SITELOC=LL151&quot;);', target: '_self',
						subMenu: [
							{title: '다리미/미싱', url: 'javascript:goCategorySpecList(&quot;C021000500010003&quot;);', target: '_self'},
							{title: '체온계/전동칫솔/전자담배', url: 'javascript:goCategorySpecList(&quot;C021000500010008&quot;);', target: '_self'},
							{title: '유선/유무선전화기', url: 'javascript:goCategorySpecList(&quot;C021000500010009&quot;);', target: '_self'},
							{title: '온수기', url: 'javascript:goCategorySpecList(&quot;C021000500010010&quot;);', target: '_self'},
							{title: '비데', url: 'javascript:goCategorySpecList(&quot;C021000500010011&quot;);', target: '_self'}
						]
					},
					{
						title: '건강가전', url: 'javascript:goCategorySpecList(&quot;C02100050005&SITELOC=LL152&quot;);', target: '_self',
						subMenu: [
							{title: '안마의자', url: 'javascript:goCategorySpecList(&quot;C021000500050001&quot;);', target: '_self'},
							{title: '안마기/마사지기', url: 'javascript:goCategorySpecList(&quot;C021000500050002&quot;);', target: '_self'},
							{title: '찜질기/찜질팩/매트', url: 'javascript:goCategorySpecList(&quot;C021000500050003&quot;);', target: '_self'},
							{title: '건강측정용품', url: 'javascript:goCategorySpecList(&quot;C021000500050004&quot;);', target: '_self'},
							{title: '발관리용품', url: 'javascript:goCategorySpecList(&quot;C021000500050005&quot;);', target: '_self'},
							{title: '실버보행보조용품', url: 'javascript:goCategorySpecList(&quot;C021000500050006&quot;);', target: '_self'},
							{title: '건강용품', url: 'javascript:goCategorySpecList(&quot;C021000500050007&quot;);', target: '_self'}
						]
					},
					{
						title: '난방가전', url: 'javascript:goCategorySpecList(&quot;C02100050004&SITELOC=LL153&quot;);', target: '_self',
						subMenu: [
							{title: '히터기', url: 'javascript:goCategorySpecList(&quot;C021000500040001&quot;);', target: '_self'},
							{title: '전기요', url: 'javascript:goCategorySpecList(&quot;C021000500040002&quot;);', target: '_self'},
							{title: '전기장판', url: 'javascript:goCategorySpecList(&quot;C021000500040003&quot;);', target: '_self'},
							{title: '전기매트', url: 'javascript:goCategorySpecList(&quot;C021000500040004&quot;);', target: '_self'}
						]
					},
					{
						title: '에어컨/선풍기/제습기', url: 'javascript:goCategorySpecList(&quot;C02100050003&SITELOC=LL154&quot;);', target: '_self',
						subMenu: [
							{title: '에어컨', url: 'javascript:goCategorySpecList(&quot;C021000500030001&quot;);', target: '_self'},
							{title: '선풍기', url: 'javascript:goCategorySpecList(&quot;C021000500030002&quot;);', target: '_self'},
							{title: '냉풍기', url: 'javascript:goCategorySpecList(&quot;C021000500030003&quot;);', target: '_self'},
							{title: '에어컨-3in1', url: 'javascript:goCategorySpecList(&quot;C021000500030004&quot;);', target: '_self'},
							{title: '에어컨-2in1', url: 'javascript:goCategorySpecList(&quot;C021000500030005&quot;);', target: '_self'},
							{title: '에어컨-스탠드형', url: 'javascript:goCategorySpecList(&quot;C021000500030006&quot;);', target: '_self'},
							{title: '에어컨-벽걸이형', url: 'javascript:goCategorySpecList(&quot;C021000500030007&quot;);', target: '_self'},
							{title: '제습기', url: 'javascript:goCategorySpecList(&quot;C021000500030008&quot;);', target: '_self'}
						]
					},
					{
						title: 'TV', url: 'javascript:goCategorySpecList(&quot;C02100060001&SITELOC=LL155&quot;);', target: '_self',
						subMenu: [
							{title: 'PDPTV', url: 'javascript:goCategorySpecList(&quot;C021000600010001&quot;);', target: '_self'},
							{title: 'LCDTV', url: 'javascript:goCategorySpecList(&quot;C021000600010002&quot;);', target: '_self'},
							{title: 'LEDTV', url: 'javascript:goCategorySpecList(&quot;C021000600010003&quot;);', target: '_self'},
							{title: 'TV악세서리', url: 'javascript:goCategorySpecList(&quot;C021000600010004&quot;);', target: '_self'},
							{title: 'TV리모컨', url: 'javascript:goCategorySpecList(&quot;C021000600010005&quot;);', target: '_self'}
						]
					},
					{
						title: '냉장고/김치냉장고', url: 'javascript:goCategorySpecList(&quot;C02100060002&SITELOC=LL156&quot;);', target: '_self',
						subMenu: [
							{title: '양문형냉장고', url: 'javascript:goCategorySpecList(&quot;C021000600020001&quot;);', target: '_self'},
							{title: '냉장고', url: 'javascript:goCategorySpecList(&quot;C021000600020002&quot;);', target: '_self'},
							{title: '뚜껑씩김치냉장고', url: 'javascript:goCategorySpecList(&quot;C021000600020004&quot;);', target: '_self'},
							{title: '스탠드형김치냉장고', url: 'javascript:goCategorySpecList(&quot;C021000600020005&quot;);', target: '_self'},
							{title: '냉동고', url: 'javascript:goCategorySpecList(&quot;C021000600020006&quot;);', target: '_self'},
							{title: '와인셀러', url: 'javascript:goCategorySpecList(&quot;C021000600020007&quot;);', target: '_self'}
						]
					},
					{
						title: '세탁기', url: 'javascript:goCategorySpecList(&quot;C02100060003&SITELOC=LL157&quot;);', target: '_self',
						subMenu: [
							{title: '세탁기', url: 'javascript:goCategorySpecList(&quot;C021000600030001&quot;);', target: '_self'},
							{title: '드럼세탁기', url: 'javascript:goCategorySpecList(&quot;C021000600030002&quot;);', target: '_self'},
							{title: '의류건조기', url: 'javascript:goCategorySpecList(&quot;C021000600030003&quot;);', target: '_self'},
							{title: '의류관리기', url: 'javascript:goCategorySpecList(&quot;C021000600030004&quot;);', target: '_self'}
						]
					},
					{
						title: 'AV-음향가전', url: 'javascript:goCategorySpecList(&quot;C02100060004&SITELOC=LL158&quot;);', target: '_self',
						subMenu: [
							{title: '홈시어터', url: 'javascript:goCategorySpecList(&quot;C021000600040001&quot;);', target: '_self'},
							{title: '블루레이플레이어', url: 'javascript:goCategorySpecList(&quot;C021000600040002&quot;);', target: '_self'},
							{title: 'DVD플레이어', url: 'javascript:goCategorySpecList(&quot;C021000600040003&quot;);', target: '_self'},
							{title: '오디오', url: 'javascript:goCategorySpecList(&quot;C021000600040004&quot;);', target: '_self'}
						]
					}
				]
			}
		];
document.write("<script type='text/javascript' src='http://image.lottemart.com/css/front/ixGnb.min.js'></script>");

$(document).ready(function(){
	ixGnb.init(foodData, lifeData);
});