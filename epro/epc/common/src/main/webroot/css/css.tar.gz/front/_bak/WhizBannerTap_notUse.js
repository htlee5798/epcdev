	    (function ($) {
	        $.fn.stat = function (options) {
	            var settings = $.extend({
	                title: 'strong.title',
	                content: 'div.content',
	                bullet: 'img.bullet_img',
	                index: 0,
	                openAll: false,
	                speed: 'fast'
	            }, options),
					all_sections = this,
					header = $('div.header');
	            return this.each(function () {
	                var self = this,
						$self = $(self),
						title_text = [],
						completed = 0;
	                self.section_title = $(settings.title, $self);
	                self.content = $(settings.content, $self);
	                self.bullet = $(settings.bullet, $self);
	                self.files = $(settings.files, $self);
	                self.files.each(function () {
	                    var stat = $(settings.stat, this);
	                    stat.each(function () {
	                        var text = $(this).text();
	                        if (text) {
	                            completed++;
	                        }
	                    });
	                });

	                self.files
						.bind('mouseenter', function () {
						    $(this).addClass('hover');
						})
						.bind('mouseleave', function () {
						    $(this).removeClass('hover');
						});
	                title_text = [self.section_title.html(), ''];
	                self.section_title.html(title_text.join(''));
	                self.section_title.bind('click', function () {
	                    var dropDown = self.content;
	                    $(".content").not(dropDown).slideUp();
						$(".bullet_img").removeClass('on');
						$(settings.bullet, $self).addClass('on');

	                    self.content.slideToggle(settings.speed);

						
						self.section_title.toggle(
							function(){$(".bullet_img").removeClass('on');$(settings.bullet, $self).addClass('on');},
							function(){$(".bullet_img").removeClass('on');$(settings.bullet, $self).addClass('on');}
						);
	                });
	                if (settings.openAll || ((settings.index - 1) === all_sections.index(this))) {
	                    self.content.css('display', 'none');
	                }
	            });
	        };
	        $(document).ready(function () {
	            $('li.section').stat({ openAll: true });
	        });
	    } (jQuery));
