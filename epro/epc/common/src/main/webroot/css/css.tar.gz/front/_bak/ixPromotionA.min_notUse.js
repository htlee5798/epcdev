/**
 * ellotte - ixPromotionA
 * @package {ixPromotionA}
 * @version 20120914 (_khv)
*/
if(ixPromotionA)throw Error('[ixError] "ixPromotionA"\uac00 \uc774\ubbf8 \uc874\uc7ac\ud558\uc5ec \ucda9\ub3cc\uc774 \ubc1c\uc0dd!');var ixPromotionA=function(){return{init:function(d){ixPromotionA.Main(d)}}}();
ixPromotionA.Main=function(d){function e(a,c){f[a].style.display="none";i[a].style.display="none";f[c].style.display="block";i[c].style.display="block";b=c}var a=ixBand,l=a.$utils,g=a("ix_promotion_a").getElementsByClassName("left","div")[0],f=a(g).getElementsByTagName("div"),g=a("ix_promotion_a").getElementsByClassName("right","div")[0],i=a(g).getElementsByTagName("div"),j=f.length,h=0,b=0,k=new ixPromotionA.Navi({onOver:function(a){"mouseover"==a.type?c.stop():c.start();e(b,a.index)}}),c=new l.Timer(1E3*
d,j,{onTimer:function(){h=b;b==j-1?b=0:++b;e(h,b);k.setSelect(b)},onComplete:function(){c.reset().start()}});k.setSelect(0);e(h,b);c.start()};

/**
 * ellotte - ixPromotionA.List
 * @package {ixPromotionA}
 * @version 20120914 (_khv)
*/
ixPromotionA.List=function(j){function c(a){j.onOver.call(this,{type:a.type,index:b.index})}function k(a){h=a.currentValue;b.listEl.style.height=h+"px"}function l(a){b.listEl.style.top=a.currentValue+"px"}var a=ixBand,i=a.$utils,b=this,e,f,d,g=0,h;this.outHeight;this.overHeight;this.index;this.listEl;this.bgEl;this.posArray;this.titleImg;this.titleOverY;this.titleOutY;this.bgContain;this.leftEl;this.rightEl;this.y;this.init=function(){e=new i.TweenCore(0.6,this.outHeight,this.overHeight,{onTween:k});
f=new i.TweenCore(0.6,this.posArray[g],this.posArray[d],{onTween:l});a(this.listEl).addEvent("mouseover",c);a(this.listEl).addEvent("mouseout",c);a(this.listEl).buttonMode(!0);a(this.leftEl).addEvent("mouseover",c);a(this.leftEl).addEvent("mouseout",c);a(this.rightEl).addEvent("mouseover",c);a(this.rightEl).addEvent("mouseout",c);b.listEl.style.top=this.y+"px"};this.over=function(){d=this.index;b.bgEl.style.display="block";a(b.bgContain).addChild(b.bgEl);e.stop().setValue(null,this.overHeight).start();
f.stop();b.listEl.style.top=this.posArray[d]+"px";this.titleImg.src="http://image.lottemart.com/images/contentimg/main/uxindex/navi_text_big0"+(this.index+1)+".png";this.titleImg.style.top=this.titleOverY+"px"};this.out=function(a){g=d;d=a;e.stop().setValue(null,this.outHeight).start();f.stop().setValue(this.posArray[g],this.posArray[d]).start();this.titleImg.src="http://image.lottemart.com/images/contentimg/main/uxindex/navi_text_small0"+(this.index+1)+".png";this.titleImg.style.top=this.titleOutY+"px"}};

/**
 * ellotte - ixPromotionA.Navi
 * @package {ixPromotionA}
 * @version 20120914 (_khv)
*/
ixPromotionA.Navi=function(q){function r(a){"mouseover"==a.type&&s.setSelect(a.index);q.onOver.call(this,{type:a.type,index:a.index})}for(var a=ixBand,s=this,d=a("ix_promotion_a").getElement(),e=a(d).getElementsByClassName("title_wrap","ul")[0],h=a(e).getElementsByTagName("li"),e=a(e).getElementsByTagName("img"),m=a(d).getElementsByClassName("bg","div")[0],t=a(m).getElementsByTagName("p"),i=a(d).getElementsByClassName("left","div")[0],i=a(i).getElementsByTagName("div"),j=a(d).getElementsByClassName("right",
"div")[0],j=a(j).getElementsByTagName("div"),u=a(d).getElementsByClassName("topBar","img")[0],k=h.length,n=-1,d=parseFloat(a(h[0]).getStyle("height")),a=parseFloat(a(e[0]).getStyle("top")),l=[],c=0;c<k;++c){var b=new ixPromotionA.List({onOver:r});b.outHeight=d;b.overHeight=135;b.index=c;b.listEl=h[c];b.bgEl=t[c];for(var v=b,f=c,o=0,p=[],g=0;g<k;++g)0<f&&(o=g<f?d*(f-1)+135:d*f),p[g]=o;v.posArray=p;b.titleImg=e[c];b.titleOverY=43;b.titleOutY=a;b.bgContain=m;b.y=d*c;b.leftEl=i[c];b.rightEl=j[c];b.init();
l[c]=b}this.setSelect=function(a){if(a!=n){for(var b=0;b<k;++b)a==b?l[b].over():l[b].out(a);u.style.display=0==a?"none":"block";n=a}}};
