/**
 * lotteMart - ixWhizBanner
 * @package {ixWhizBanner}
 * @version 20121018 (2j5)
 * @modify 20121031 (_khv)
*/
if(ixWhizBanner)throw Error('[ixError] "ixWhizBanner"\uac00 \uc774\ubbf8 \uc874\uc7ac\ud558\uc5ec \ucda9\ub3cc\uc774 \ubc1c\uc0dd!');
var ixWhizBanner=function(){function q(a){a.values.tweenTarget.style.height=a.currentValue+"px"}function r(){h=b(d).height()}function s(a){n(a.currentTarget._idx)}function n(a){-1<e&&e!=a&&(i[e].stop().seekTo(0),j[e].className="off",f[e]=!1);f[a]?(j[a].className="off",f[a]=!1):(j[a].className="on",f[a]=!0);i[a].stop().toggle();e=a}var b=ixBand,k=b.$utils,d=b("floatdiv").getElement(),t=b(d).getElementsByClassName("section","li"),j=[],o=[],p,i=[],g=b().documentHeight(),h=b(d).height(),u=[370,235,235,
220],l,e=-1,f=[];b(d).getElementsByClassName("title version-1","strong")[0];b(d).getElementsByClassName("title version-2","strong")[0];b(d).getElementsByClassName("title version-3","strong")[0];b(d).getElementsByClassName("title version-4","strong")[0];l=o.length;var c;for(c=0;c<l;++c){var m=o[c];m._idx=c;b(m).getElementsByTagName("img")[0];f[c]=!1;i[c]=new k.TweenCore(0.25,31,u[c],{onTween:q,onSeekComplete:r,ease:k.ease.quadInOut},{tweenTarget:t[c]});b(m).addEvent("click",s)}b(window).addEvent("resize",
function(){g=b().documentHeight()});p=new k.TweenCore(0.4,0,0,{onTween:function(a){d.style.top=a.currentValue+"px"}});b(window).addEvent("scroll",function(){var a=b().documentScrollY(),c=0;262<a?(c=a-262,g<a+h-10&&(c=g-h-280)):c=0;p.stop().setValue(null,c).start()});return{defaultOpen:function(a){-1<a&&a<l&&n(a)},update:function(){g=b().documentHeight()}}}();
