/**
 * lotteMart - ixWhizBanner
 * @package {ixWhizBanner}
 * @version 20121018 (2j5)
*/
if(ixWhizBanner)throw Error('[ixError] "ixWhizBanner"\uac00 \uc774\ubbf8 \uc874\uc7ac\ud558\uc5ec \ucda9\ub3cc\uc774 \ubc1c\uc0dd!');
var ixWhizBanner=function(){function q(a){a.values.tweenTarget.style.height=a.currentValue+"px"}function r(){i=b(d).height()}function s(a){o(a.currentTarget._idx)}function o(a){-1<e&&e!=a&&(j[e].stop().seekTo(0),h[e].className="off",g[e]=!1);g[a]?(h[a].className="off",g[a]=!1):(h[a].className="on",g[a]=!0);j[a].stop().toggle();e=a}var b=ixBand,k=b.$utils,d=b("floatdiv").getElement(),t=b(d).getElementsByClassName("section","li"),h=[],f=[],p,j=[],l=b().documentHeight(),i=b(d).height(),u=[370,235,235,
220],m,e=-1,g=[];f[0]=b(d).getElementsByClassName("title version-1","strong")[0];f[1]=b(d).getElementsByClassName("title version-2","strong")[0];f[2]=b(d).getElementsByClassName("title version-3","strong")[0];f[3]=b(d).getElementsByClassName("title version-4","strong")[0];m=f.length;var c;for(c=0;c<m;++c){var n=f[c];n._idx=c;h[c]=b(n).getElementsByTagName("img")[0];g[c]=!1;j[c]=new k.TweenCore(0.25,31,u[c],{onTween:q,onSeekComplete:r,ease:k.ease.quadInOut},{tweenTarget:t[c]});b(n).addEvent("click",
s)}b(window).addEvent("resize",function(){l=b().documentHeight()});p=new k.TweenCore(0.4,0,0,{onTween:function(a){d.style.top=a.currentValue+"px"}});b(window).addEvent("scroll",function(){var a=b().documentScrollY(),c=0;262<a?(c=a-262,l<a+i-10&&(c=l-i-280)):c=0;p.stop().setValue(null,c).start()});return{defaultOpen:function(a){-1<a&&a<m&&o(a)}}}();
