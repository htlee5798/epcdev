/**
 * lotteMart - ixGnb
 * @package {ixGnb}
 * @version 20121017 (_khv)
*/
if(ixGnb)throw Error('[ixError] "ixGnb"\uac00 \uc774\ubbf8 \uc874\uc7ac\ud558\uc5ec \ucda9\ub3cc\uc774 \ubc1c\uc0dd!');
var ixGnb={Main:function(h,i){function o(c){g=c.currentTarget._idx;"mouseover"==c.type&&(1==g?j.init():k.init());"none"==_foodDep2.style.display&&(_foodDep3.style.display="none");"none"==_lifeDep2.style.display&&(_lifeDep3.style.display="none");l(c.type,g);m({widDep2:0,widDep3:0})}function p(c){g=c.currentTarget._idx;q(c.type,g)}function r(c){2>g&&l(c.type,g)}function l(c,a){"mouseover"==c?(s.stop(),e[a].style.top="-56px",t(c,a),console.log("main     ",c,a)):(e[a].style.top="0px",s.reset().start())}
function q(c,a){"mouseover"==c?(e[a].style.top="-56px",2==a&&(_otherOutTimer.stop(),u(c,a))):(e[a].style.top="0px",2==a&&_otherOutTimer.reset().start())}function t(c,a){var b=0==a?k.subHeight:j.subHeight;"mouseover"==c?(0==a?(_foodDepth.style.display="block",_lifeDepth.style.display="none",j.init(),_foodBanner.style.height=b+"px"):(_foodDepth.style.display="none",_lifeDepth.style.display="block",k.init(),_lifeBanner.style.height=b+"px"),v.stop().setValue(null,b,{open:!1}).start()):v.stop().setValue(null,
0,{open:!0}).start();"none"==_foodDep2.style.display&&(_foodDep3.style.display="none");"none"==_lifeDep2.style.display&&(_lifeDep3.style.display="none")}function u(a,b){"mouseover"==a?_otherCont[b-2]&&(w.stop().setValue(null,A,{open:!1}).start(),_otherCont[b-2].style.display="block"):w.stop().setValue(null,0,{open:!0}).start()}function x(a){l(a.type,a.parentIdx)}function m(a){a=y+a.widDep2+a.widDep3;z.stop().setValue(null,a).start()}var a=ixBand,b=a.$utils,n=b.ease,d=a("ixGnbId").getElement(),f=a(d).getElementsByClassName("depth",
"div")[0];a(d).getElementsByClassName("menu","ul");var e=$("ul.menu > li > a > img");_foodCont=a(d).getElementsByClassName("depth1Contain","div")[0];_lifeCont=a(d).getElementsByClassName("depth1Contain","div")[1];_foodDep2=a(d).getElementsByClassName("depth2Contain","div")[0];_lifeDep2=a(d).getElementsByClassName("depth2Contain","div")[1];_foodDep3=a(d).getElementsByClassName("depth3Contain","div")[0];_lifeDep3=a(d).getElementsByClassName("depth3Contain","div")[1];_foodDepth=a(f).getElementsByClassName("foodContain",
"div")[0];_lifeDepth=a(f).getElementsByClassName("lifeContain","div")[0];_foodBanner=a(f).getElementsByClassName("extra","div")[0];_lifeBanner=a(f).getElementsByClassName("extra","div")[1];_boxCont=a(f).getElementsByClassName("quick-links","div")[0];_otherCont=a(d).getElementsByClassName("uxOther","div");var g,d=a(_foodBanner).width();a(_lifeBanner).width();var y=a(_foodCont).width()+d,A=parseFloat(a(_otherCont[0]).getStyle("height")),k=new ixGnb.Sub(h,_foodCont,0,{onOver:x,setWid:m}),j=new ixGnb.Sub(i,
_lifeCont,1,{onOver:x,setWid:m}),d=new ixGnb.Other(_otherCont,2,{onOver:function(a){q(a.type,a.parentIdx)}}),s=new b.Timer(100,1,{onTimer:function(){t("out")}});_otherOutTimer=new b.Timer(100,1,{onTimer:function(){u("out",2)}});for(var v=new b.TweenCore(0.2,0,1,{onTween:function(a){f.style.height=a.currentValue+"px"},onComplete:function(a){a.values.open&&z.stop().setValue(null,y).start()},ease:n.quadInOut()}),z=new b.TweenCore(0.2,0,1,{onTween:function(a){f.style.width=a.currentValue+"px"},ease:n.quadInOut()}),
w=new b.TweenCore(0.2,0,1,{onTween:function(a){_otherCont[0].style.height=a.currentValue+"px"},ease:n.quadInOut()}),b=0;2>b;++b)a(e[b]).addEvent("mouseover",o),a(e[b]).addEvent("mouseout",o),e[b]._idx=b;d.init();for(b=2;9>b;++b)a(e[b]).addEvent("mouseover",p),a(e[b]).addEvent("mouseout",p),e[b]._idx=b;a(f).addEvent("mouseover",r);a(f).addEvent("mouseout",r)},init:function(h,i){ixGnb.Main(h,i)}};

/**
 * lotteMart - ixGnb.Scroller
 * @package {ixGnb}
 * @version 20121002 (2j5)
*/
ixGnb.Scroller=function(){function m(a){c=0<a.delta?c+b.wheelGap:c-b.wheelGap;c=d(c);b.scrollTarget.style.top=c+"px";a.preventDefault()}function d(a){0<=a?(a=0,h("down")):a<j?(a=j,h("up")):h("all");return a}function h(a){var c="none",e="none",d=0,f=b.scrollHeight;"up"==a?(d=b.iconHeight,f-=b.iconHeight,c="block"):"down"==a?(f-=b.iconHeight,e="block"):"all"==a&&(e=c="block",d=b.iconHeight,f-=2*b.iconHeight);b.upArrow.style.display=c;b.downArrow.style.display=e;b.container.style.marginTop=d+"px";b.container.style.height=
f+"px";i=f}function n(a){var g=0,e=i;"up"==a?(g=d(c+-e),i<e&&(g+=b.wheelGap)):(g=d(c- -e),i<e&&(g-=b.wheelGap));return g}var k=ixBand,o=k.$utils,b=this,l,c=0,i,j;this.upArrow;this.downArrow;this.container;this.scrollTarget;this.wheelGap;this.scrollHeight;this.contentHeight;this.iconHeight;this.listLength;l=new o.TweenCore(0.3,0,1,{onTween:function(a){b.scrollTarget.style.top=a.currentValue+"px";c=a.currentValue}});this.init=function(){this.contentHeight>this.scrollHeight&&(j=this.scrollHeight-this.contentHeight-
this.wheelGap,c=d(0),b.scrollTarget.style.top="0px",k(this.container).addEvent("mousewheel",m))};this.disable=function(){this.contentHeight>this.scrollHeight&&(h(""),k(this.container).removeEvent("mousewheel",m))};this.scrollUp=function(){var a=n("down");l.stop().setValue(c,a).start()};this.scrollDown=function(){var a=n("up");l.stop().setValue(c,a).start()}};

/**
 * lotteMart - ixGnb.Sub
 * @package {ixGnb.Sub}
 * @version 20121012 (_khv)
*/
ixGnb.Sub=function(q,r,u,s){function h(a){var b=a.currentTarget==k?0:1;switch(a.type){case "mouseover":0==b?v.className="over":w.className="over";break;case "mouseout":0==b?v.className="out":w.className="out";break;case "click":0==b?d[c].scroller.scrollUp():d[c].scroller.scrollDown()}}function i(a){var b=a.currentTarget==l?0:1;if(-1<c)switch(a.type){case "mouseover":0==b?x.className="over":y.className="over";break;case "mouseout":0==b?x.className="out":y.className="out";break;case "click":d[c].arrowDep3ClickHandler(b,
z)}}function A(a){s.onOver.call(this,{type:a.type,parentIdx:u})}function C(a){z=a.idx;s.setWid.call(this,{widDep2:208,widDep3:a.wid})}var a=ixBand,m=r.parentNode,g=a(m).getElementsByClassName("depth2Contain","div")[0],e=a(m).getElementsByClassName("depth3Contain","div")[0],k=a(g).getElementsByClassName("scroll_up","div")[0],n=a(g).getElementsByClassName("scroll_down","div")[0],v=a(g).getElementsByTagName("img")[0],w=a(g).getElementsByTagName("img")[1],l=a(e).getElementsByClassName("scroll_up","div")[0],
o=a(e).getElementsByClassName("scroll_down","div")[0],x=a(e).getElementsByTagName("img")[0],y=a(e).getElementsByTagName("img")[1],f,B=q.length,c=-1,d=[],j,z,D=parseFloat(a(g).getStyle("width"));this.subHeight;e=document.createElement("ul");e.className="listCont";for(var t="",b=0;b<B;++b)var p=q[b],t=t+('<li class="idx_'+b+'"><a href="'+p.url+'">'+p.title+"</a></li>");a(e).addEvent("mouseover",function(a){f&&(f.style.color="#787878",f.style.background="#ffffff");f=a.target;"A"==a.target.tagName?"mouseover"==
a.type&&((f.style.color="#ffffff",f.style.background="#c9c7c8",-1<c&&(d[c].out(),j=0),c=a.target.parentNode.className.substring(4),0<d[c].dep2Length)?(d[c].over(),j=D):(d[c].out(),j=0)):(-1<c&&d[c].out(),j=0);s.setWid.call(this,{widDep2:j,widDep3:0})});a(m).addEvent("mouseover",A);a(m).addEvent("mouseout",A);e.innerHTML=t;a(r).addChild(e,0);this.subHeight=a(r).height();for(b=0;b<B;++b)p=q[b],d[b]=new ixGnb.SubDepth2(p.subMenu,g,b,u,this.subHeight,{setWid:C});a(k).addEvent("mouseover",h);a(k).addEvent("mouseout",
h);a(k).addEvent("click",h);a(k).buttonMode(!0);a(n).addEvent("mouseover",h);a(n).addEvent("mouseout",h);a(n).addEvent("click",h);a(n).buttonMode(!0);a(l).addEvent("mouseover",i);a(l).addEvent("mouseout",i);a(l).addEvent("click",i);a(l).buttonMode(!0);a(o).addEvent("mouseover",i);a(o).addEvent("mouseout",i);a(o).addEvent("click",i);a(o).buttonMode(!0);this.init=function(){g.style.display="none";j=0;f&&(f.style.color="#787878",f.style.background="#ffffff")}};

/**
 * lotteMart - ixGnb.Other
 * @package {ixGnb.Other}
 * @version 20121011 (_khv)
*/
ixGnb.Other=function(a,d,e){function b(a){e.onOver.call(this,{type:a.type,parentIdx:d})}var c=ixBand;c(a[0]).addEvent("mouseover",b);c(a[0]).addEvent("mouseout",b);this.init=function(){a[0].style.height="0px"}};

/**
 * lotteMart - ixGnb.SubDepth2
 * @package {ixGnb.SubDepth2}
 * @version 20121011 (_khv)
*/
ixGnb.SubDepth2=function(l,f,o,s,m,t){function u(a){g&&(g.style.color="#838383",g.style.background="none");g=a.target;"A"==a.target.tagName?"mouseover"==a.type&&((g.style.color="#ffffff",g.style.background="#a4a2a3",c.style.display="block",f.style.display="block",-1<d&&(h[d].out(),j=0),d=a.target.parentNode.className.substring(4),0<h[d].dep3Length)?(h[d].over(),j=v):(h[d].out(),j=0)):(-1<d&&h[d].out(),j=0);t.setWid.call(this,{wid:j,idx:d})}var b=ixBand,a=this,d=-1,g;this.dep2Length;this.scroller;
var k=f.parentNode;b(k).getElementsByClassName("depth1Contain","div");var o=b(k).getElementsByClassName("depth2Contain","div")[0],k=b(k).getElementsByClassName("depth3Contain","div")[0],c,p,q,r,h=[],j,v=parseFloat(b(k).getStyle("width"));if(l){c=document.createElement("div");c.className="ulContain";var i='<ul class="listCont">';a.dep2Length=l.length;var e;for(e=0;e<a.dep2Length;++e)var n=l[e],i=i+('<li class="idx_'+e+'"><a href="'+n.url+'">'+n.title+"</a></li>");i+="</ul>";b(c).addEvent("mouseover",
u);c.innerHTML=i;b(f).addChild(c,0);f.style.height=m+"px";i=parseFloat(b(o).getStyle("padding-top"));c.style.height=m-i+"px";o.style.height=m-i+"px";for(e=0;e<a.dep2Length;++e)n=l[e],h[e]=new ixGnb.SubDepth3(n.subMenu,k,e,s,m);p=b(c).getElementsByClassName("listCont","ul")[0];q=b(f).getElementsByClassName("scroll_up","div")[0];r=b(f).getElementsByClassName("scroll_down","div")[0];b(f).getElementsByTagName("img")}this.over=function(){l&&(c.style.display="block",f.style.display="block",a.scroller||
(a.scroller=new ixGnb.Scroller,a.scroller.upArrow=q,a.scroller.downArrow=r,a.scroller.container=c,a.scroller.scrollTarget=p,a.scroller.contentHeight=parseFloat(b(p).height()),a.scroller.scrollHeight=b(c).height(),a.scroller.iconHeight=22,a.scroller.wheelGap=24),a.scroller.init())};this.out=function(){c.style.display="none";f.style.display="none";a.scroller.disable();-1<d&&(h[d].out(),j=0);g&&(g.style.color="#838383",g.style.background="none")};this.arrowDep3ClickHandler=function(a,b){0==a?h[b].scrollerDep3.scrollUp():
h[b].scrollerDep3.scrollDown()}};

/**
 * lotteMart - ixGnb.SubDepth3
 * @package {ixGnb.SubDepth3}
 * @version 20121011 (_khv)
*/
ixGnb.SubDepth3=function(h,d,b,g,j){function n(a){e&&(e.style.color="#7d7d7d",e.style.background="none");var b=e=a.target;"A"==b.tagName&&(e.style.color="#ffffff",e.style.background="#6e6e6e",a.target.parentNode.className.substring(4),"mouseover"==a.type&&(b.className="mover",c.style.display="block",d.style.display="block"))}var f=ixBand,a=this;this.dep3Length;this.scrollerDep3;var c,e,i,k,l;if(h){c=document.createElement("div");c.className="ulContain";b='<ul class="listCont">';a.dep3Length=h.length;
for(g=0;g<a.dep3Length;++g)var m=h[g],b=b+('<li class="idx_'+g+'"><a href="'+m.url+'">'+m.title+"</a></li>");b+="</ul>";f(c).addEvent("mouseover",n);c.innerHTML=b;f(d).addChild(c,0);b=parseFloat(f(d).getStyle("padding-top"));c.style.height=j-b+"px";d.style.height=j-b+"px";i=f(c).getElementsByClassName("listCont","ul")[0];k=f(d).getElementsByClassName("scroll_up","div")[0];l=f(d).getElementsByClassName("scroll_down","div")[0];f(d).getElementsByTagName("img")}this.over=function(){h&&(c.style.display=
"block",d.style.display="block",a.scrollerDep3||(a.scrollerDep3=new ixGnb.Scroller,a.scrollerDep3.upArrow=k,a.scrollerDep3.downArrow=l,a.scrollerDep3.container=c,a.scrollerDep3.scrollTarget=i,a.scrollerDep3.contentHeight=parseFloat(f(i).height()),a.scrollerDep3.scrollHeight=f(c).height(),a.scrollerDep3.iconHeight=22,a.scrollerDep3.wheelGap=24),a.scrollerDep3.init())};this.out=function(){e&&(e.style.color="#7d7d7d",e.style.background="none");a.scrollerDep3.disable();c.style.display="none";d.style.display=
"none"}};
